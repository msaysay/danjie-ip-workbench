"""Narrow observable question guards; not a general semantic classifier."""
import re

CUSTOMER_GROUPS = {
    'buyer': {'buyer', 'payer', 'decision_maker', 'user', 'roles'},
    'task': {'task', 'need', 'needs', 'operation_concern'},
    'trigger': {'trigger', 'timing'},
    'concern': {'concern', 'concerns', 'objection', 'objections',
                'followup_concern', 'operation_concern', 'refund_concern'},
    'alternatives': {'alternatives', 'alternative'},
    'criteria': {'criteria', 'purchase_criteria'},
}


def customer_groups(slot):
    if not slot.startswith('customer.'):
        return set()
    name = slot.partition('.')[2]
    return {group for group, aliases in CUSTOMER_GROUPS.items() if name in aliases}


def check_question(text, slot, stage, covered, skipped):
    # Catch visibly bundled requests, including the actual P1/P2/P3/P8 failures.
    if text.count('？') + text.count('?') > 1:
        raise ValueError('一次只问一个问题，不把多问合并计数')
    interrogative = r'什么|怎么|如何|哪|谁|多少|是否|能不能|有没有|可否|能否|吗'
    clauses = re.split(r'[，,；;。？！?!、\n]', text)
    if sum(bool(re.search(interrogative, clause)) for clause in clauses) > 1:
        raise ValueError('本题含多个待答缺口，请只保留其中一个')
    if re.search(r'(?:再|顺便|同时)(?:说|讲|问|举|介绍)|举一个|举个例', text) and re.search(interrogative, text):
        raise ValueError('不要在问题后追加举例或另一项任务')
    if slot.startswith('customer.') or stage == 'customer':
        # No free-form customer.scenario/entry slots that can disguise known needs.
        allowed = {'customer.' + group for group in CUSTOMER_GROUPS}
        if slot not in allowed or stage != 'customer':
            raise ValueError('客户侧只用六类规范槽；本人介入和处理动作归本人维度')
        wanted = customer_groups(slot)
        known = set().union(*(customer_groups(s) for s in covered + skipped))
        if wanted & known:
            raise ValueError('客群卡或原答已有这一类信息，不换问法重问')
