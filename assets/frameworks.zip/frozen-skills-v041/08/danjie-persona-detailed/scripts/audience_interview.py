#!/usr/bin/env python3
"""Bind an upstream read/review to one durable interview; no language generation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
from interview import load_state
from check_quotes import read_json, unrestricted_leaves


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_binding(context_path, review_path):
    context = read_json(context_path)
    review = read_json(review_path)
    source = Path(context['source_path']).resolve(strict=True)
    digest = sha(source)
    text = source.read_bytes().decode('utf-8-sig')
    if (context.get('schema') != 'persona-audience-read-1.0'
            or context.get('source_sha256') != digest
            or context.get('source_bytes') != source.stat().st_size
            or context.get('original_text') != text):
        raise ValueError('upstream_changed')
    if (review.get('card_match') != 'matched'
            or review.get('source_sha256') != digest
            or review.get('mode') not in ('real', 'fictional_demo')):
        raise ValueError('unreviewed_or_mismatch')
    # This is an AI source review, not an invented confirmation by the student.
    if review.get('reviewer') != 'assistant_source_review':
        raise ValueError('invalid_review_origin')
    if source.suffix.lower() == '.json':
        raw = read_json(source)
        public = [v for _, v in unrestricted_leaves(raw)]
        mode = raw.get('mode')
        if mode in ('real', 'fictional_demo') and mode != review['mode']:
            raise ValueError('mode_conflict')
    else:
        public = [text]
        if '虚构' in text and review['mode'] == 'real':
            raise ValueError('fictional_cannot_be_real')
    slots = []
    coverage = review.get('coverage')
    if not isinstance(coverage, list):
        raise ValueError('missing_coverage_review')
    for entry in coverage:
        if not isinstance(entry, dict) or entry.get('status') not in ('reported', 'candidate', 'unknown'):
            raise ValueError('invalid_coverage_status')
        if entry['status'] != 'reported':
            continue
        slot, quote = entry.get('slot'), entry.get('quote')
        if (not isinstance(slot, str) or not slot.strip()
                or not isinstance(quote, str) or not quote.strip()
                or not any(quote in leaf for leaf in public)):
            raise ValueError('unsupported_coverage')
        if slot not in slots:
            slots.append(slot)
    return review, slots, {
        'schema': 'audience-interview-binding-1.0',
        'source_path': str(source), 'source_sha256': digest,
        'context_path': str(context_path.resolve()), 'context_sha256': sha(context_path),
        'review_path': str(review_path.resolve()), 'review_sha256': sha(review_path),
        'mode': review['mode'], 'covered_slots': slots,
        'semantic_identity_and_entailment': 'assistant_review_not_independently_proven',
    }


def invoke(state, request):
    return subprocess.run([sys.executable, str(HERE / 'student_interview.py'),
                           '--state', str(state), '--request', str(request)],
                          capture_output=True, text=True, timeout=40)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--context', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--state', type=Path, required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--prepare', action='store_true')
    group.add_argument('--request', type=Path)
    args = parser.parse_args()
    try:
        review, slots, binding = read_binding(args.context, args.review)
        lock = args.state.with_name(args.state.name + '.audience-binding.json')
        journal = args.state.with_name(args.state.name + '.events.jsonl')
        existing = load_state(args.state, journal)
        newly_bound = False
        if lock.exists():
            if read_json(lock) != binding:
                raise ValueError('different_upstream_for_same_interview')
        elif not args.prepare:
            raise ValueError('prepare_required_before_interview')
        else:
            if existing is not None and (existing['mode'] != review['mode']
                                          or existing['pending'] is not None
                                          or existing['completed']):
                raise ValueError('answer_acquisition_question_before_binding')
            lock.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                json.dump(binding, handle, ensure_ascii=False, indent=2)
            newly_bound = True
        if args.prepare:
            if existing is not None and existing['question_count'] and not newly_bound:
                if existing['mode'] != review['mode'] or not set(slots).issubset(existing['covered_slots']):
                    raise ValueError('prepare_mismatch_on_resume')
                return 0  # Idempotent; never resets existing answers or counters.
            operations = [{'op': 'init', 'mode': review['mode']}]
            if slots:
                operations.append({'op': 'cover', 'slots': slots})
            for index, operation in enumerate(operations):
                request = lock.with_name(lock.name + '.prepare-' + str(index) + '.json')
                if request.exists() and read_json(request) != operation:
                    raise ValueError('prepare_request_conflict')
                if not request.exists():
                    fd = os.open(request, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                    with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                        json.dump(operation, handle, ensure_ascii=False)
                result = invoke(args.state, request)
                if result.returncode:
                    raise ValueError('prepare_not_completed')
            return 0
        existing = load_state(args.state, journal)
        if existing is None or existing['mode'] != review['mode'] or not set(slots).issubset(existing['covered_slots']):
            raise ValueError('prepare_incomplete')
        request = read_json(args.request)
        if request.get('op') == 'cover':
            raise ValueError('upstream_coverage_only_from_bound_review')
        result = invoke(args.state, args.request)
        # Preserve the existing wrapper's question/error and actual exit code.
        sys.stdout.write(result.stdout)
        sys.stderr.write(result.stderr)
        return result.returncode
    except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired):
        sys.stderr.write('客群资料与本轮采访尚未衔接确认，请先核对原卡和当前记录，不要重复提交回答。\n')
        return 4


if __name__ == '__main__':
    raise SystemExit(main())
