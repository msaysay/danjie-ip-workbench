#!/usr/bin/env python3
"""Use existing Pillow; forward render arguments (--sources/--source-manifest) unchanged."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

def choose():
    candidates=[[sys.executable]]
    for command in ('python3','python'):
        found=shutil.which(command)
        if found:candidates.append([found])
    if sys.platform=='darwin' and Path('/usr/bin/python3').is_file():candidates.append(['/usr/bin/python3'])
    if sys.platform=='win32' and shutil.which('py'):candidates.append([shutil.which('py'),'-3'])
    unique=[];seen=set();report=[]
    for cmd in candidates:
        key=tuple(cmd)
        if key not in seen:unique.append(cmd);seen.add(key)
    for cmd in unique:
        try:
            r=subprocess.run(cmd+['-c','import sys; import PIL; print(sys.executable)'],capture_output=True,text=True,timeout=12)
            report.append({'command':cmd,'pillow_available':r.returncode==0})
            if r.returncode==0:return cmd,report
        except (OSError,subprocess.TimeoutExpired) as exc:report.append({'command':cmd,'pillow_available':False,'error':str(exc)})
    return None,report

if __name__=='__main__':
    chosen,checks=choose()
    if sys.argv[1:]==['--check']:
        print(json.dumps({'render_python':chosen,'checks':checks,'installed_nothing':True},ensure_ascii=False));sys.exit(0 if chosen else 4)
    if not chosen:
        print(json.dumps({'warning':'现有Python未找到Pillow，继续保留HTML；不能声称PNG成功','checks':checks},ensure_ascii=False),file=sys.stderr)
        chosen=[sys.executable]
    renderer=Path(__file__).with_name('render.py')
    sys.exit(subprocess.run(chosen+[str(renderer)]+sys.argv[1:]).returncode)
