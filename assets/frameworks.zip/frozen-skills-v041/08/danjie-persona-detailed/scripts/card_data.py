"""Shared presentation data for the standalone detailed persona card."""

FOOTER_FIELDS=(('confirmed_facts','已确认事实'),('pending_evidence','待补证据'),('public_boundaries','公开边界'))
FACTS_CAPTION='本人或已有资料已明确；不代表独立核验。'


def footer_columns(data):
    columns=[]
    for field,title in FOOTER_FIELDS:
        values=data.get(field)
        if not isinstance(values,list) or not values:values=['待补充']
        columns.append((field,title,values))
    return columns


def detail_lines(primary,detail):
    """Only omit identical complete lines; retain every other original assertion."""
    main_lines={line.strip() for line in str(primary).splitlines() if line.strip()}
    main_lines.add(str(primary).strip())
    result=[];seen=set()
    for line in str(detail).splitlines():
        value=line.strip()
        if not value or value in main_lines or value in seen:continue
        result.append(value);seen.add(value)
    return result


def display_detail(primary,detail):
    return '\n'.join(detail_lines(primary,detail))
