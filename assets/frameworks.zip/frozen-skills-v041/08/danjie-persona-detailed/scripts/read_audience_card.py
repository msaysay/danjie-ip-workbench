#!/usr/bin/env python3
"""Read an explicitly supplied upstream card; never discover or regenerate one."""
import argparse
import hashlib
import json
import os
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--card', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    source = Path(args.card).expanduser().resolve(strict=True)
    destination = Path(args.out).expanduser().absolute()
    if source.suffix.lower() not in {'.json', '.md', '.txt'}:
        raise ValueError('需要可读取的JSON、Markdown或文本原卡；图片需另核转录。')
    raw = source.read_bytes()
    content = raw.decode('utf-8-sig')
    if not content.strip():
        raise ValueError('原卡内容为空。')
    # Parsing proves format only. Identity, meaning and disclosure need source review.
    if source.suffix.lower() == '.json':
        parsed = json.loads(content)
        if not isinstance(parsed, dict):
            raise ValueError('JSON原卡必须是对象。')
    record = {
        'schema': 'persona-audience-read-1.0',
        'source_path': str(source),
        'source_sha256': hashlib.sha256(raw).hexdigest(),
        'source_bytes': len(raw),
        'source_format': source.suffix.lower()[1:],
        'original_text': content,
        'identity_binding': 'pending_source_review',
        'coverage': 'not_automatically_inferred',
        'use': 'backend_context_only_not_new_fact_or_student_attachment',
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Refuse overwrites, including a repeated invocation or a symlink target.
    fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as handle:
        json.dump(record, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
    print('已读取原卡；须核对所属业务及事实状态，再决定哪些问题可以跳过。')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, UnicodeError):
        raise SystemExit('未完成原卡读取，请核对文件及格式；未开始人设采访。')
