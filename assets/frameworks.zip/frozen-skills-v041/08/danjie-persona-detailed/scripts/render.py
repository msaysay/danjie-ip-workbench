#!/usr/bin/env python3
"""Validate provenance/structure and render the fixed persona card offline."""
import argparse
import base64
import html
import hashlib
import io
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

from card_data import FACTS_CAPTION, footer_columns, detail_lines, display_detail

TITLE='蛋解六维人设卡'
IDS=['identity','customer','judgment','relationship','evidence','action']
TITLES=['现实身份','客户场景','专业判断','人格关系','信任证据','内容动作']
BASIS={'reported':'资料/本人陈述','recollection':'本人回忆','self_judgment':'本人判断','planned':'计划/希望','suggested':'AI建议·待试拍','unknown':'待补充','mixed':'含不同状态·见说明'}
ASSETS=Path(__file__).resolve().parents[1]/'assets'

def escape(value): return html.escape(str(value),quote=True)
def dump(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

FORBIDDEN_ROOT_FIELDS=('customer_profile','customer_origin','customer_source','response_links')
BINDING_METADATA={'available','profile_id','profile_version','source_name','source_id','source_version'}


def contains_customer_card(value):
    if isinstance(value,dict):
        if 'raw_customer_card' in value:return True
        if 'profile_id' in value and 'dimensions' in value and ('pairs' in value or 'customer_type' in value):return True
        return any(contains_customer_card(item) for item in value.values())
    if isinstance(value,list):return any(contains_customer_card(item) for item in value)
    if isinstance(value,str) and value.lstrip().startswith('{'):
        try:
            parsed=json.loads(value)
            if isinstance(parsed,dict):return contains_customer_card(parsed)
        except (ValueError,RecursionError):pass
    return False


def validate(d):
    errors=[]
    def err(text):errors.append(text)
    if not isinstance(d,dict):return {'structural_valid':False,'errors':['根对象不是对象'],'semantic_verified':False}
    def text(obj,key,where):
        if not isinstance(obj.get(key),str) or not obj[key].strip():err(where+'.'+key+'须为非空字符串')
    for key in FORBIDDEN_ROOT_FIELDS:
        if key in d:err('详细独立版禁止旧融合根字段：'+key)
    if contains_customer_card(d):err('详细独立版不接收或导出完整目标客群卡，不能藏在metadata内')
    for key in ('persona_id','display_name','business','summary'):text(d,key,'root')
    if d.get('schema_version')!='1.0':err('schema_version须为1.0')
    if type(d.get('persona_version')) is not int or d['persona_version']<1:err('persona_version须为正整数')
    if d.get('mode') not in ('real','fictional_demo'):err('mode无效')
    if d.get('status') not in ('prefilled','interviewed','incomplete'):err('status无效')
    questions=d.get('issued_questions',[])
    if not isinstance(questions,list):err('issued_questions须为数组');questions=[]
    count=d.get('question_count')
    if type(count) is not int or not 0<=count<=24 or count!=len(questions):err('实际题数须等于已发问条数且不超过24')
    for index,q in enumerate(questions):
        if not isinstance(q,dict):err('题目须为对象');continue
        if q.get('id')!='P'+str(index+1):err('问题ID须从P1连续')
        if q.get('stage') not in IDS:err('题目stage须为六维ID之一，无分段预算')
        for key in ('text','slot'):text(q,key,'question')
    state=d.get('interview_state')
    if state is not None:
        if not isinstance(state,dict):err('interview_state须为对象');state={}
        if not isinstance(state.get('covered_slots'),list) or type(state.get('completed')) is not bool:err('采访摘要字段不完整')
    if d.get('status')=='interviewed' and not questions:err('interviewed必须有实际问答')
    if questions and d.get('status')=='prefilled':err('有实际发问不能标0问预填流程')
    binding=d.get('audience_binding')
    if binding is not None:
        if not isinstance(binding,dict):err('audience_binding只允许轻量来源元数据')
        elif any(key not in BINDING_METADATA or isinstance(value,(dict,list)) for key,value in binding.items()):err('audience_binding仅容来源ID、版本及名称等metadata，不能含完整卡或客户资料')
    for key in ('public_boundaries','unknowns'):
        if not isinstance(d.get(key),list) or any(not isinstance(x,str) or not x.strip() for x in d[key]):err(key+'须为非空文字数组')
    for key in ('confirmed_facts','pending_evidence'):
        if key in d and (not isinstance(d[key],list) or any(not isinstance(x,str) or not x.strip() for x in d[key])):err(key+'须为非空文字数组')
    if 'upstream_cards' in d and not isinstance(d['upstream_cards'],list):err('upstream_cards须为数组')
    sources=d.get('sources',[]);known=set()
    if not isinstance(sources,list):err('sources须为数组');sources=[]
    for source in sources:
        if not isinstance(source,dict):err('来源须为对象');continue
        for key in ('id','answer','origin'):text(source,key,'source')
        sid=source.get('id','')
        if not isinstance(sid,str) or not re.fullmatch(r'(P[1-9][0-9]*|A[1-9][0-9]*)',sid):err('来源ID须为Pn或An');continue
        if sid in known:err('来源ID重复')
        known.add(sid)
        if sid.startswith('P') and sid not in {q.get('id') for q in questions if isinstance(q,dict)}:err('回答引用未发出的题目')
        if d.get('mode')=='fictional_demo':
            if source.get('kind')!='simulation':err('模拟来源必须全部simulation')
        elif source.get('kind') not in ('user_statement','provided_material'):err('真实卡来源类型错误')
    def item(value,where):
        if not isinstance(value,dict):err(where+'须为对象');return
        text(value,'detail',where)
        if value.get('basis') not in BASIS:err(where+'状态无效')
        refs=value.get('source_ids')
        if not isinstance(refs,list) or any(not isinstance(ref,str) or ref not in known for ref in refs):err(where+'来源不存在')
        elif value.get('basis')!='unknown' and not refs:err(where+'非未知内容需要来源')
    dims=d.get('dimensions',[])
    if not isinstance(dims,list) or len(dims)!=6:err('须为6维');dims=[]
    line_counts=[]
    for index,value in enumerate(dims):
        item(value,'dimension')
        if not isinstance(value,dict):continue
        if value.get('id')!=IDS[index] or value.get('title')!=TITLES[index]:err('六维ID/标题/顺序错误')
        text(value,'main','dimension')
        if not isinstance(value.get('short'),list) or len(value['short'])!=2 or any(not isinstance(v,str) or not v.strip() for v in value['short']):err('图上须为两条非空短句')
        line_counts.append(len(detail_lines(value.get('main',''),value.get('detail',''))))
    for key,limit in (('evidence_records',6),('content_actions',4)):
        seq=d.get(key)
        if not isinstance(seq,list) or len(seq)>limit:err(key+'数组/数量错误');continue
        for value in seq:
            item(value,key)
            if isinstance(value,dict):text(value,'title',key)
    return {'structural_valid':not errors,'semantic_verified':False,'errors':errors,
            'warnings':['结构与逐字来源检查不证明语义、本人确认或资料真实性；明细不足时保留缺口，不补造细节。'],
            'question_count':count,'detail_line_counts':line_counts}


def verify_interview(d,state_path,source_paths,manifest_path):
    errors=[]
    if state_path is None:return {'valid':False,'errors':['实际采访须传--interview-state，不能用手填短摘要替代真实记录']}
    try:
        from interview import validate_state
        actual=json.loads(state_path.read_text(encoding='utf-8-sig'),object_pairs_hook=no_dupes)
        actual=validate_state(actual)
        if actual.get('state_schema')!='persona-detailed-1.0':errors.append('采访记录不是persona-detailed-1.0')
        for key in ('mode','question_count','issued_questions'):
            if actual.get(key)!=d.get(key):errors.append('采访记录与成卡不一致：'+key)
        if d.get('question_count',0)>0:
            if not actual.get('completed') or actual.get('pending') is not None or actual.get('current_stage')!='complete' or actual.get('next_slot') is not None:errors.append('实际采访尚未完整结束')
        resolved=state_path.resolve()
        if resolved not in {Path(path).resolve() for path in source_paths}:errors.append('实际最终state必须同时列入显式--sources')
        manifest=json.loads(manifest_path.read_text(encoding='utf-8-sig'),object_pairs_hook=no_dupes) if manifest_path else {}
        digest=hashlib.sha256(state_path.read_bytes()).hexdigest()
        if not any(entry.get('path')==str(resolved) and entry.get('sha256')==digest for entry in manifest.get('sources',[]) if isinstance(entry,dict)):errors.append('实际最终state须以同路径同sha256在冻结清单中')
        actual_sources={source['id']:source for source in actual.get('sources',[]) if isinstance(source,dict) and 'id' in source}
        for source in d.get('sources',[]):
            sid=source.get('id','') if isinstance(source,dict) else ''
            if not isinstance(sid,str) or not sid.startswith('P'):continue
            original=actual_sources.get(sid)
            if not original or original.get('answer')!=source.get('answer') or original.get('kind')!=source.get('kind'):errors.append('Pn来源不等于实际记录中的原答：'+sid);continue
            if original.get('restricted') is not False or original.get('response')=='skipped':errors.append('Pn来源属于受限或跳过记录，不能进入交付：'+sid)
            if 'stage' in source and source['stage']!=original.get('stage'):errors.append('Pn来源stage与实际记录不一致：'+sid)
        return {'valid':not errors,'errors':errors,'state_schema':actual.get('state_schema'),'question_count':actual.get('question_count'),'completed':actual.get('completed'),'state_sha256':digest,'semantic_verified':False}
    except (OSError,ValueError,TypeError,KeyError,ImportError) as exc:
        return {'valid':False,'errors':['实际采访校验失败：'+str(exc)],'semantic_verified':False}


def wrap_diagram_text(value,capacity):
    result=[];current='';units=0
    for c in value:
        w=.64 if c.isascii() else 1
        if c=='\n' or (current and units+w>capacity):
            result.append(current);current='';units=0
            if c=='\n':continue
        current+=c;units+=w
    return result+[current] if current else result or ['']

def diagram(data):
    # Same fixed radial geometry as the 0.4.4 customer card, no scores.
    axes=[]
    for i,d in enumerate(data['dimensions']):
        axes.append((d,[line for v in d['short'] for line in wrap_diagram_text(v,18 if i in (0,3) else 9.6)]))
    top=max(0,len(axes[0][1])-2)*32
    side=max(0,max(len(axes[i][1]) for i in (1,2,4,5))-4)*32
    cy=320+top+side/2
    points=[(500,150+top),(647,235+top),(647,405+top+side),(500,490+top+side),(353,405+top+side),(353,235+top)]
    bottom=558+top+side; height=max(660+top+side,bottom+70+(len(axes[3][1])-1)*32)
    places=[(500,37,'middle'),(752,200+top,'start'),(752,370+top+side,'start'),(500,bottom,'middle'),(248,370+top+side,'end'),(248,200+top,'end')]
    labels=[]
    for (d,lines),(x,y,a) in zip(axes,places):
        labels.append('<g><text class="model-label" x="%s" y="%s" text-anchor="%s">%s</text>%s</g>'%(x,y,a,escape(d['title']),''.join('<text class="model-value" x="%s" y="%s" text-anchor="%s">%s</text>'%(x,y+36+n*32,a,escape(v)) for n,v in enumerate(lines))))
    names=wrap_diagram_text(data['display_name'],6.8)
    fs=27
    while len(names)*(fs+9)>122 and fs>14:
        fs-=1;names=wrap_diagram_text(data['display_name'],180/fs)
    first=cy+1-(len(names)-2)*(fs+9)/2
    hub='<circle cx="500" cy="%s" r="100" fill="#111914" stroke="#9a8047"/><text class="model-center-kicker" x="500" y="%s" text-anchor="middle">我的六维人设</text>%s'%(cy,first-42,''.join('<text class="model-center-text" style="font-size:%spx" x="500" y="%s" text-anchor="middle">%s</text>'%(fs,first+n*(fs+9),escape(v)) for n,v in enumerate(names)))
    return '<svg class="model-radial" viewBox="0 0 1000 %s" role="img" aria-label="六维人设描述图，不打分"><polygon class="model-outer" points="%s"/><g class="model-structure">%s</g>%s%s</svg>'%(height,' '.join('%s,%s'%p for p in points),''.join('<line x1="500" y1="%s" x2="%s" y2="%s"/>'%(cy,x,y) for x,y in points),hub,''.join(labels))

def label(d):
    if d['mode']=='fictional_demo':return '虚构测试 · 非真人案例'
    return '部分信息待补充' if d['status']=='incomplete' else ''

def safe_display_name(value):
    # Remove path separators, control/format characters and cross-platform reserved names.
    import unicodedata
    cleaned=''.join(c for c in str(value) if unicodedata.category(c)[0]!='C')
    cleaned=re.sub(r'[<>:"/\\|?*]', '-', cleaned).strip(' .-')
    cleaned=re.sub(r'\s+', '-', cleaned)[:60].rstrip(' .-') or '称呼待补充'
    while len(cleaned.encode('utf-8'))>120:cleaned=cleaned[:-1]
    if re.fullmatch(r'(?i:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?',cleaned):cleaned='称呼-'+cleaned
    return cleaned


def detail_html(primary,detail):
    values=detail_lines(primary,detail)
    return '<ul class="detail-lines">'+''.join('<li>'+escape(value)+'</li>' for value in values)+'</ul>' if values else ''


def render_html(d,image=None):
    css=(ASSETS/'style.css').read_text(encoding='utf-8').replace('__TEXTURE__','data:image/png;base64,'+base64.b64encode((ASSETS/'texture.png').read_bytes()).decode())
    cards=''.join('<article class="dimension"><h3><i>%02d</i>%s</h3><div class="main">%s</div>%s<span class="basis-tag">%s</span></article>'%(i+1,escape(x['title']),escape(x['main']),detail_html(x['main'],x['detail']),BASIS[x['basis']]) for i,x in enumerate(d['dimensions']))
    columns=[]
    for key,title,values in footer_columns(d):
        caption='<p class="footer-caption">'+FACTS_CAPTION+'</p>' if key=='confirmed_facts' else ''
        items=''.join('<li>'+escape(value)+'</li>' for value in values)
        columns.append('<article class="footer-column" data-field="'+key+'"><h3>'+title+'</h3>'+caption+'<ul>'+items+'</ul></article>')
    footer='<section class="page footer-page"><div class="footer-columns">'+''.join(columns)+'</div></section>'
    result_label=label(d)
    tag='<span class="tag">'+escape(result_label)+'</span>' if result_label else ''
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+TITLE+'</title><style>'+css+'</style></head><body><main class="report"><section class="page"><div class="top"><span class="brand">蛋解课堂</span>'+tag+'</div><h1 class="card-title">'+TITLE+'</h1><p class="card-subtitle">'+escape(d['display_name']+'｜'+d['business'])+'</p><div class="heading"><h2>01 六维梳理，看清你是谁</h2></div><div class="six">'+cards+'</div><figure class="profile-model"><h3>六维人设，一眼看清</h3>'+diagram(d)+'<figcaption class="model-summary"><span>一句话记忆</span>'+escape(d['summary'])+'</figcaption></figure></section>'+footer+'</main></body></html>'

def markdown(d):
    lines=['# '+TITLE,'']
    if label(d):lines += [label(d),'']
    lines += [d['display_name']+'｜'+d['business'],'',d['summary']]
    for x in d['dimensions']:
        lines+=['','## '+x['title'],x['main']]
        lines+=['- '+value for value in detail_lines(x['main'],x['detail'])]
        lines+=['依据：'+BASIS[x['basis']]]
    for key,title,values in footer_columns(d):
        lines+=['','## '+title]
        if key=='confirmed_facts':lines+=[FACTS_CAPTION]
        lines+=['- '+value for value in values]
    return '\n'.join(lines)+'\n'

def student_message(d,image):
    """One plain reply derived only from the actual result; diagnostics stay in JSON."""
    title='虚构测试人设卡' if d.get('mode')=='fictional_demo' else '人设卡'
    gap='未确定的信息已保留，' if d.get('status')=='incomplete' else ''
    if image.get('png_ready'):
        if image.get('download_saved'):return title+'已整理，'+gap+'完整长图已保存。'
        if image.get('download_error'):return title+'已整理，'+gap+'长图已生成，下载保存还没完成。'
        return title+'已整理，'+gap+'可以查看完整长图。'
    return title+'已整理，'+gap+'长图暂未生成。'


def no_dupes(pairs):
    obj={}
    for k,v in pairs:
        if k in obj:raise ValueError('重复JSON键：'+k)
        obj[k]=v
    return obj

def main():
    p=argparse.ArgumentParser()
    p.add_argument('persona',type=Path)
    p.add_argument('--out',type=Path,default=Path('result'));p.add_argument('--font')
    p.add_argument('--save-downloads',action='store_true');p.add_argument('--downloads-dir',type=Path)
    p.add_argument('--interview-state',type=Path);p.add_argument('--sources',nargs='+',action='append',type=Path);p.add_argument('--source-manifest',type=Path)
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    from check_quotes import validate_quotes,flatten_sources
    sources=flatten_sources(a.sources);d={}
    try:
        d=json.loads(a.persona.read_text(encoding='utf-8-sig'),object_pairs_hook=no_dupes,parse_constant=lambda value:(_ for _ in ()).throw(ValueError('非标准JSON数值')))
        report=validate(d)
        if isinstance(d,dict) and (d.get('question_count',0)>0 or a.interview_state is not None):
            state_report=verify_interview(d,a.interview_state,sources,a.source_manifest)
            report['interview_validation']=state_report
            if not state_report['valid']:report['errors'].extend(state_report['errors'])
        report['structural_valid']=not report['errors']
    except (OSError,ValueError,TypeError) as exc:report={'structural_valid':False,'semantic_verified':False,'errors':[str(exc)]}
    quote_report=validate_quotes(d,a.persona,sources,a.source_manifest)
    dump(a.out/'quote-validation.json',quote_report)
    report['quote_guard_valid']=quote_report['quote_guard_valid']
    report['privacy_guard_valid']=quote_report.get('privacy_guard_valid',False)
    if not quote_report['quote_guard_valid']:
        report['errors'].extend('quote_guard: '+error for error in quote_report['errors']);report['structural_valid']=False
    report['student_message']='这次资料还需要核对，暂时不能生成完整人设卡。'
    report['content_ready']=bool(report.get('structural_valid') and d.get('status')!='incomplete' and all(item.get('basis')!='unknown' for item in d.get('dimensions',[]) if isinstance(item,dict)))
    dump(a.out/'validation.json',report)
    if not report['structural_valid']:print(json.dumps(report,ensure_ascii=False));return 2
    try:
        from card_image import make_scene
        from long_image import export_svg,export_png
        scene=make_scene(d,diagram(d),label(d),BASIS)
        export_svg(scene,a.out/(TITLE+'-完整长图.svg'))
    except (OSError,ValueError,ImportError) as exc:
        report['errors'].append(str(exc));report['student_message']='人设卡暂时没能生成，请稍后重试。';dump(a.out/'validation.json',report);return 3
    stem=a.out/TITLE
    png=a.out/(TITLE+'-完整长图.png')
    image={'png_ready':False,'download_saved':False,'stale_png_present':False}
    previous_png=png.is_file();png_phase='generation'
    try:
        buffer=io.BytesIO();info=export_png(scene,buffer,a.font);generated=buffer.getvalue()
        import struct
        if not generated.startswith(b'\x89PNG\r\n\x1a\n') or len(generated)<33:raise ValueError('PNG字节头校验失败')
        if struct.unpack('>II',generated[16:24])!=(info['width'],info['height']):raise ValueError('PNG长图尺寸校验失败')
        png_phase='file_write';png.write_bytes(generated)
        image.update(info,png_ready=True,png=str(png.resolve()),png_sha256=hashlib.sha256(generated).hexdigest())
    except (RuntimeError,OSError,ValueError) as exc:
        image.update(png_error=str(exc),png_failure_stage=png_phase,stale_png_present=previous_png and png.is_file())
        if image['stale_png_present']:image.update(previous_png=str(png.resolve()),previous_png_may_have_changed=png_phase=='file_write')
    if a.save_downloads and image['png_ready']:
        try:
            folder=a.downloads_dir or Path.home()/'Downloads'
            if not folder.is_dir():raise OSError('下载目录不存在，请指定已有目录')
            prefix=TITLE+'-'+safe_display_name(d['display_name'])+'-完整长图-'+datetime.now().strftime('%Y%m%d-%H%M%S');target=folder/(prefix+'.png');n=2
            while target.exists():target=folder/(prefix+'-'+str(n)+'.png');n+=1
            with png.open('rb') as source,target.open('xb') as dest:shutil.copyfileobj(source,dest)
            if png.read_bytes()!=target.read_bytes():raise OSError('下载副本字节核对失败')
            image.update(download_saved=True,saved_download=str(target.resolve()))
        except OSError as exc:image['download_error']=str(exc)
    rendered=render_html(d,image)
    stem.with_suffix('.html').write_text(rendered,encoding='utf-8');stem.with_suffix('.md').write_text(markdown(d),encoding='utf-8');dump(stem.with_suffix('.json'),d)
    report.update(long_image=image,dual_format_complete=image['png_ready'],persona_json=str(stem.with_suffix('.json').resolve()),student_message=student_message(d,image))
    dump(a.out/'validation.json',report)
    print(json.dumps({'html':str(stem.with_suffix('.html').resolve()),'persona_json':report['persona_json'],'student_message':report['student_message'],**image},ensure_ascii=False))
    if not image['png_ready']:return 4
    return 5 if a.save_downloads and not image['download_saved'] else 0

if __name__=='__main__':sys.exit(main())
