"""Compose the whole card using the customer card's layout primitives."""
import re
import xml.etree.ElementTree as ET
from long_image import Scene,wrap,GOLD,WHITE,GRAY,CYAN
from card_data import FACTS_CAPTION, footer_columns, detail_lines

def make_scene(d,svg,status,basis):
    s=Scene()
    s.text('蛋解课堂',48,62,22,GOLD,bold=True)
    if status:s.text(status,1032,62,20,GOLD,anchor='end')
    s.text('蛋解六维人设卡',48,132,42,bold=True)
    y=182
    y+=s.paragraph(d['display_name']+'｜'+d['business'],48,y,984,25,GOLD)
    y+=35
    s.line(48,y,1032,y);y+=65
    s.text('01 六维梳理，看清你是谁',48,y,34,bold=True);y+=40
    for row in range(3):
        group=d['dimensions'][row*2:row*2+2]
        heights=[]
        for item in group:
            body=detail_lines(item['main'],item['detail'])
            main_height=len(wrap(item['main'],28,418))*42
            body_height=sum(len(wrap('· '+value,23,418))*34.5+10 for value in body)
            heights.append(148+main_height+body_height)
        height=max(heights)
        for col,item in enumerate(group):
            xx=48+col*502;s.rect(xx,y,482,height)
            s.text('%02d  %s'%(row*2+col+1,item['title']),xx+24,y+43,27,GOLD,bold=True)
            main_height=s.paragraph(item['main'],xx+24,y+91,418,28,bold=True)
            yy=y+91+main_height+12
            for value in detail_lines(item['main'],item['detail']):
                yy+=s.paragraph('· '+value,xx+24,yy,418,23,GRAY)+10
            s.text(basis[item['basis']],xx+24,yy+8,19,GOLD)
        y+=height+20
    y+=40;s.text('六维人设，一眼看清',48,y,32,GOLD,bold=True);y+=30
    root=ET.fromstring(svg)
    classes={'model-label':{'size':22,'fill':GRAY},'model-value':{'size':25,'fill':WHITE,'bold':True},'model-center-kicker':{'size':18,'fill':GOLD},'model-center-text':{'size':27,'fill':WHITE,'bold':True}}
    def visit(n,inherited=None):
        tag=n.tag.split('}')[-1];a=n.attrib;styles=dict(inherited or {});styles.update(classes.get(a.get('class'),{}))
        if tag=='text':
            fs=re.search(r'font-size:([\d.]+)',a.get('style',''));size=float(fs.group(1)) if fs else styles.get('size',25)
            s.text(''.join(n.itertext()),40+float(a['x']),y+float(a['y']),size,a.get('fill',styles.get('fill',WHITE)),a.get('text-anchor','start'),styles.get('bold',False))
        elif tag=='line':s.line(40+float(a['x1']),y+float(a['y1']),40+float(a['x2']),y+float(a['y2']),'#6e6039')
        elif tag=='polygon':s.items.append(('polygon',[(40+float(v.split(',')[0]),y+float(v.split(',')[1])) for v in a['points'].split()],{'fill':None,'stroke':GOLD}))
        elif tag=='circle':s.items.append(('circle',(40+float(a['cx']),y+float(a['cy']),float(a['r'])),{'fill':a.get('fill',GOLD),'stroke':a.get('stroke')}))
        for child in n:visit(child,styles)
    visit(root);y+=float(root.attrib['viewBox'].split()[3])+25
    h=100+len(wrap(d['summary'],27,912))*40.5
    s.rect(48,y,984,h,fill='#192219',stroke=None,r=0);s.line(48,y,48,y+h,GOLD)
    s.text('一句话记忆',74,y+39,22,GOLD);s.paragraph(d['summary'],74,y+86,912,27,bold=True);y+=h+60
    # One shared footer row, independent of the backend evidence/action records.
    # Height follows the longest column; no clipping or text truncation.
    columns=footer_columns(d)
    y+=8
    s.line(48,y,1032,y);y+=32
    width,gap,pad=317.3333333333,16,20
    text_width=width-2*pad
    layouts=[]
    for key,title,values in columns:
        used=81
        if key=='confirmed_facts':
            used+=len(wrap(FACTS_CAPTION,18,text_width))*27+18
        for value in values:
            used+=len(wrap('· '+value,22,text_width))*33+16
        layouts.append(max(used+18,160))
    height=max(layouts)
    for col,(key,title,values) in enumerate(columns):
        xx=48+col*(width+gap)
        s.rect(xx,y,width,height)
        s.text(title,xx+pad,y+43,27,CYAN if key=='pending_evidence' else GOLD,bold=True)
        yy=y+81
        if key=='confirmed_facts':
            yy+=s.paragraph(FACTS_CAPTION,xx+pad,yy,text_width,18,GRAY)+18
        for value in values:
            yy+=s.paragraph('· '+value,xx+pad,yy,text_width,22,GRAY)+16
    y+=height+35
    s.height=int(y+35)
    return s
