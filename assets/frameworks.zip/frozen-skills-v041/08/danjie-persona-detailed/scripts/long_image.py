"""Fixed, data-driven long PNG export. No network or image-generation API.

PNG requires an existing Pillow installation and a local CJK font. Never install
dependencies silently. All card text is wrapped, never ellipsized or rewritten.
"""
import html
import os
import re
from pathlib import Path
import xml.etree.ElementTree as ET

GOLD='#eacf79'
WHITE='#f2f3ed'
GRAY='#aab7ad'
CYAN='#86cedb'
BG='#0d1712'
CARD='#16201a'
LINE='#35463a'


def wrap(value, size, width):
    lines, current, units = [], '', 0
    for c in str(value):
        weight = size * (0.6 if c.isascii() else 1.02)
        if c == '\n' or (current and units + weight > width):
            lines.append(current)
            current, units = '', 0
            if c == '\n':
                continue
        current += c
        units += weight
    if current:
        lines.append(current)
    return lines or ['']


class Scene:
    def __init__(self):
        self.items=[]
        self.height=0

    def rect(self,x,y,w,h,fill=CARD,stroke=LINE,r=12):
        self.items.append(('rect',(x,y,w,h),{'fill':fill,'stroke':stroke,'r':r}))

    def text(self,value,x,y,size=26,fill=WHITE,anchor='start',bold=False):
        self.items.append(('text',(x,y),{'value':str(value),'size':size,'fill':fill,'anchor':anchor,'bold':bold}))

    def paragraph(self,value,x,y,width,size=26,fill=WHITE,bold=False):
        lines=wrap(value,size,width)
        for i,line in enumerate(lines):
            self.text(line,x,y+i*size*1.5,size,fill,bold=bold)
        return len(lines)*size*1.5

    def line(self,x1,y1,x2,y2,fill=LINE):
        self.items.append(('line',(x1,y1,x2,y2),{'fill':fill}))


def export_svg(scene,path):
    e=lambda v:html.escape(str(v),quote=True)
    parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="%d" viewBox="0 0 1080 %d">'%(scene.height,scene.height),'<rect width="1080" height="100%%" fill="%s"/>'%BG,'<g font-family="PingFang SC,Microsoft YaHei,Noto Sans CJK SC,sans-serif">']
    for kind,coords,a in scene.items:
        if kind=='text':
            parts.append('<text x="%s" y="%s" fill="%s" font-size="%s" font-weight="%s" text-anchor="%s">%s</text>'%(*coords,a['fill'],a['size'],'700' if a['bold'] else '400',a['anchor'],e(a['value'])))
        elif kind=='rect':
            parts.append('<rect x="%s" y="%s" width="%s" height="%s" rx="%s" fill="%s" stroke="%s"/>'%(*coords,a['r'],a['fill'],a['stroke'] or 'none'))
        elif kind=='line':
            parts.append('<line x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s"/>'%(*coords,a['fill']))
        elif kind=='circle':
            parts.append('<circle cx="%s" cy="%s" r="%s" fill="%s" stroke="%s"/>'%(*coords,a['fill'],a['stroke'] or 'none'))
        elif kind=='polygon':
            parts.append('<polygon points="%s" fill="none" stroke="%s"/>'%(' '.join('%s,%s'%p for p in coords),a['stroke']))
    parts+=['</g></svg>']
    path.write_text(''.join(parts),encoding='utf-8')


def export_png(scene,path,font_path=None):
    if scene.height > 24000:
        raise RuntimeError('文字过长，长图超过24000像素；未裁字或冒充PNG成功。请缩短重复表述后重试。')
    try:
        from PIL import Image,ImageDraw,ImageFont,PngImagePlugin
    except ImportError as exc:
        raise RuntimeError('PNG导出需要当前Python已有Pillow；未自动安装。HTML已保留，不能声称PNG已生成。') from exc
    if font_path and not Path(font_path).is_file():
        raise RuntimeError('--font指定的中文字体文件不存在，未静默换字体。')
    candidates=[font_path,os.environ.get('DANJIE_CJK_FONT'),'/System/Library/Fonts/PingFang.ttc','/System/Library/Fonts/STHeiti Medium.ttc','C:/Windows/Fonts/msyh.ttc','C:/Windows/Fonts/simhei.ttf','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc']
    chosen=next((p for p in candidates if p and Path(p).is_file()),None)
    if not chosen:
        raise RuntimeError('PNG导出未找到中文字体；可用--font指定本机中文字体。不使用缺中文字的默认字体冒充成功。')
    im=Image.new('RGB',(1080,scene.height),BG)
    draw=ImageDraw.Draw(im)
    cache={}
    for kind,coords,a in scene.items:
        if kind=='text':
            size=round(a['size'])
            if size not in cache:
                cache[size]=ImageFont.truetype(chosen,size)
            draw.text(coords,a['value'],font=cache[size],fill=a['fill'],anchor={'start':'ls','middle':'ms','end':'rs'}[a['anchor']],stroke_width=0)
        elif kind=='rect':
            x,y,w,h=coords
            draw.rounded_rectangle((x,y,x+w,y+h),radius=a['r'],fill=a['fill'],outline=a['stroke'],width=1)
        elif kind=='line':
            draw.line(coords,fill=a['fill'],width=1)
        elif kind=='circle':
            x,y,r=coords
            draw.ellipse((x-r,y-r,x+r,y+r),fill=a['fill'],outline=a['stroke'],width=1)
        elif kind=='polygon':
            draw.line(coords+[coords[0]],fill=a['stroke'],width=1)
    meta=PngImagePlugin.PngInfo()
    meta.add_text('Title','蛋解六维人设卡')
    meta.add_text('Description','完整六维人设长图；不代表内容已获真人确认。')
    im.save(path,format='PNG',pnginfo=meta)
    return {'width':1080,'height':scene.height,'font':str(chosen),'text_elements':sum(k=='text' for k,_,_ in scene.items)}


def export_long_image(data,diagram_html,out,stem,font_path=None):
    scene=make_scene(data,diagram_html)
    svg=out/(stem+'-完整长图.svg')
    png=out/(stem+'-完整长图.png')
    export_svg(scene,svg)
    result={'svg':str(svg),'png':None,'png_ready':False}
    try:
        info=export_png(scene,png,font_path)
        result.update(info,png=str(png),png_ready=True)
    except (RuntimeError,OSError,ValueError) as exc:
        result['png_error']=str(exc)
    return result
