#!/usr/bin/env python3
"""Run the existing interview CLI once; emit only a verified student question."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid

sys.dont_write_bytecode = True
CORE_PATH = Path(__file__).resolve().with_name('interview.py')
spec = importlib.util.spec_from_file_location('_persona_interview_core', CORE_PATH)
core = importlib.util.module_from_spec(spec)
try:
    spec.loader.exec_module(core)
except (OSError, ImportError, SyntaxError):
    sys.stderr.write('暂时无法读取采访工具，请恢复后再继续。\n')
    raise SystemExit(4)

PLAIN_SKIP_PHRASES = frozenset(('不知道', '不清楚', '未提供', '暂不回答', '不想回答', '不方便说', '跳过'))
COMMON_END_PUNCTUATION = '。.!！?？；;，,、…'


class StudentParser(argparse.ArgumentParser):
    def error(self, message):
        self.exit(2, '暂时无法继续，请检查采访输入。\n')


def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def leaf_strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from leaf_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from leaf_strings(item)


def plain_unknown_skip(source):
    if source.get('response') != 'skip' or source.get('basis') != 'unknown':
        return False
    normalized = source['answer'].strip().rstrip(COMMON_END_PUNCTUATION + ' \t\r\n')
    return normalized in PLAIN_SKIP_PHRASES


def verified_receipt(machine, state):
    question = next((q for q in state['issued_questions'] if q['id'] == state['pending']), None)
    text = None
    if question is not None:
        text = ('第' + question['id'][1:] + '问｜' + core.STAGE_TITLES[question['stage']] + '\n' + question['text'])
    expected = {'question_count': state['question_count'], 'limits': state['limits'],
                'pending': state['pending'], 'current_stage': state['current_stage'],
                'completed': state['completed'], 'pending_question': question,
                'question_for_student': text}
    if not isinstance(machine, dict) or canonical(machine) != canonical(expected):
        raise ValueError('response_mismatch')
    # Never copy state, request, sources, or raw answers into a second receipt.
    # Also fail closed if a complete restricted answer/line was echoed as a
    # question. This is exact text checking, not general privacy understanding.
    public_strings = list(leaf_strings(machine))
    for source in state['sources']:
        if source['restricted'] and not plain_unknown_skip(source):
            fragments = [source['answer']] + source['answer'].splitlines()
            if any(piece.strip() and piece in text for piece in fragments for text in public_strings):
                raise ValueError('restricted_echo')
    if text is not None and state['mode'] == 'fictional_demo':
        text = '虚构示例\n' + text
    return text


def write_receipt(handle, payload):
    handle.write(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    handle.flush()
    os.fsync(handle.fileno())


def main():
    parser = StudentParser(description=__doc__)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    journal = args.state.with_name(args.state.name + '.events.jsonl')
    receipt_path = args.receipt or (args.state.parent / 'receipts' / ('interview-' + uuid.uuid4().hex + '.json'))
    reserved = {p.resolve() for p in (args.state, args.request, journal, CORE_PATH, Path(__file__))}
    receipt_file = None
    core_returned_success = False
    durable_verified = False
    try:
        if receipt_path.resolve() in reserved or not args.request.is_file():
            raise ValueError('invalid_receipt_or_input')
        receipt_path.parent.mkdir(parents=True, exist_ok=True)
        # Reserve an independent receipt before any operation can commit. Do not
        # overwrite an old receipt or consume a request twice to recover output.
        fd = os.open(str(receipt_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        receipt_file = os.fdopen(fd, 'w', encoding='utf-8')
        result = subprocess.run(
            [sys.executable, str(CORE_PATH), '--state', str(args.state), '--request', str(args.request)],
            capture_output=True, text=True, encoding='utf-8', timeout=30,
            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        payload = {'receipt_schema': 'student-interview-receipt-1.0',
                   'child_exit_code': result.returncode, 'stdout_sha256': digest(result.stdout),
                   'stderr_sha256': digest(result.stderr), 'status': 'failed', 'machine_receipt': None}
        if result.returncode != 0:
            payload['failure_code'] = 'interview_rejected'
            write_receipt(receipt_file, payload)
            parser.exit(2, '这一步没有完成，请先核对当前问题后再继续。\n')
        core_returned_success = True
        try:
            machine = json.loads(result.stdout)
            state = core.load_state(args.state, journal)
            if state is None:
                raise ValueError('missing_state')
            student_text = verified_receipt(machine, state)
        except (OSError, ValueError, KeyError, TypeError):
            payload['failure_code'] = 'unverified_response'
            write_receipt(receipt_file, payload)
            parser.exit(3, '暂时无法确认当前问题，请先恢复采访后再继续。\n')
        durable_verified = True
        payload.update(status='verified', machine_receipt=machine)
        write_receipt(receipt_file, payload)
        # A terminal answer/finish has no pending question: emit nothing, rather
        # than redisplaying the last question or inventing a processing message.
        if student_text is not None:
            print(student_text)
        return 0
    except subprocess.TimeoutExpired:
        if receipt_file is not None:
            try:
                write_receipt(receipt_file, {'receipt_schema': 'student-interview-receipt-1.0',
                                            'status': 'failed', 'failure_code': 'interview_timeout',
                                            'machine_receipt': None})
            except OSError:
                pass
        parser.exit(4, '这一步尚未完成，请先恢复采访，不要重复提交回答。\n')
    except (OSError, ValueError, TypeError):
        if durable_verified:
            parser.exit(4, '本轮记录已保存，暂时无法交付结果；请先恢复采访，不要重复提交回答。\n')
        if core_returned_success:
            parser.exit(4, '当前状态需要恢复确认，请勿重复提交回答。\n')
        parser.exit(4, '暂时无法交付当前结果，请先恢复采访后再继续。\n')
    finally:
        if receipt_file is not None:
            try:
                receipt_file.close()
            except OSError:
                pass


if __name__ == '__main__':
    raise SystemExit(main())
