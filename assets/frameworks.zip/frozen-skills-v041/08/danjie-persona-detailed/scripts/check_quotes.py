#!/usr/bin/env python3
"""Exact public quotation guard. Standard library only; no semantic inference."""
import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

UNKNOWN_LABELS = {'待补充', '待确认', '还不了解', '未知', '姓名待补充', '公司待补充', '客群资料待接入'}
LABEL_PREFIXES = ('原话：', '本人原话：', '客户原话：', '客群原话：', '资料原文：', '本人陈述：', '虚构测试：')
LABEL_SUFFIXES = ('（虚构测试）', '（虚构）', '（待本人核对）')


def no_dupes(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('重复JSON键：' + key)
        result[key] = value
    return result


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=no_dupes)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def flatten_sources(values):
    return [Path(item).resolve() for group in (values or []) for item in group]


def pointer_token(value):
    return str(value).replace('~', '~0').replace('/', '~1')


def leaves(value, locator=''):
    if isinstance(value, str):
        yield locator, value
    elif isinstance(value, dict):
        for key, item in value.items():
            yield from leaves(item, locator + '/' + pointer_token(key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from leaves(item, locator + '/' + str(index))


def restricted_objects(value, locator=''):
    """Locate explicit delivery restrictions without copying their payload to logs."""
    if isinstance(value, dict):
        if 'restricted' in value:
            yield locator or '/', value['restricted']
        for key, item in value.items():
            yield from restricted_objects(item, locator+'/'+pointer_token(key))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from restricted_objects(item, locator+'/'+str(index))


def unrestricted_leaves(value, locator='', inherited=False):
    if isinstance(value, dict):
        hidden=inherited or value.get('restricted') is True
        for key,item in value.items():
            yield from unrestricted_leaves(item,locator+'/'+pointer_token(key),hidden)
    elif isinstance(value,list):
        for index,item in enumerate(value):
            yield from unrestricted_leaves(item,locator+'/'+str(index),inherited)
    elif isinstance(value,str) and not inherited:
        yield locator,value


def restricted_payloads(value, locator='', inherited=False):
    # Schema metadata is not private assertion text. Protect every actual payload
    # leaf in an explicitly restricted subtree, including nested/custom fields.
    metadata={'id','kind','origin','basis','stage','response','source_ids','restricted',
              'schema_version','mode','status','profile_id','persona_id'}
    if isinstance(value,dict):
        hidden=inherited or value.get('restricted') is True
        for key,item in value.items():
            if hidden and key in metadata:continue
            yield from restricted_payloads(item,locator+'/'+pointer_token(key),hidden)
    elif isinstance(value,list):
        for index,item in enumerate(value):
            yield from restricted_payloads(item,locator+'/'+str(index),inherited)
    elif isinstance(value,str) and inherited and value.strip():
        yield locator,value


def mapping_keys(value,locator=''):
    if isinstance(value,dict):
        for index,(key,item) in enumerate(value.items()):
            yield locator+'/{key#'+str(index)+'}',str(key)
            yield from mapping_keys(item,locator+'/'+pointer_token(key))
    elif isinstance(value,list):
        for index,item in enumerate(value):yield from mapping_keys(item,locator+'/'+str(index))


def delivery_privacy(data, docs):
    errors=[];protected=set()
    for doc in docs:
        for _,value in doc['restricted']:
            if value.strip():protected.add(value.strip())
            protected.update(line.strip() for line in value.splitlines() if line.strip())
    def safe_field(field):
        for secret in sorted(protected,key=len,reverse=True):field=field.replace(secret,'[受限键]')
        return field
    for field,flag in restricted_objects(data):
        if flag is True:errors.append(safe_field(field)+'含显式restricted=true，受限原答不能进入完整交付')
        elif type(flag) is not bool:errors.append(safe_field(field)+'.restricted必须为布尔值')
    checked=0
    from itertools import chain
    for field,value in chain(leaves(data),mapping_keys(data)):
        checked+=1
        if any(secret in value for secret in protected):
            errors.append(safe_field(field)+'包含冻结来源的受限内容，禁止进入HTML、PNG、Markdown或JSON交付')
    return {'valid':not errors,'fields_checked':checked,'protected_payloads':len(protected),'errors':errors}


def has_fictional_mode(value):
    if isinstance(value, dict):
        return value.get('mode') == 'fictional_demo' or any(has_fictional_mode(x) for x in value.values())
    if isinstance(value, list):
        return any(has_fictional_mode(x) for x in value)
    return False


def derived_persona_markdown(raw):
    """Recognize the public card format without embedding a hidden technical tag.

    A title alone or a few interview headings are not enough. The complete six
    persona dimensions and the three fixed result columns identify this card.
    """
    headings=[]
    for line in raw.splitlines():
        match=re.match(r'^[ \t]{0,3}(#{1,6})[ \t]+(.+?)[ \t]*$',line)
        if match:
            title=re.sub(r'[ \t]+#+[ \t]*$','',match.group(2)).strip()
            headings.append((len(match.group(1)),title))
    if (1,'蛋解六维人设卡') not in headings:return False
    sections={title for level,title in headings if level==2}
    required={'现实身份','客户场景','专业判断','人格关系','信任证据','内容动作',
              '已确认事实','待补证据','公开边界'}
    return required.issubset(sections)


def source_document(path):
    if not path.is_file():
        raise ValueError('来源文件不存在：' + str(path))
    raw = path.read_text(encoding='utf-8-sig')
    if derived_persona_markdown(raw):
        raise ValueError('人设成品Markdown及其改名副本不能作为可信原答来源：' + str(path))
    if raw.lstrip().startswith('{'):
        try:
            possible_persona = json.loads(raw)
        except ValueError:
            possible_persona = None
        if isinstance(possible_persona, dict) and 'persona_id' in possible_persona and 'dimensions' in possible_persona:
            raise ValueError('人设成品或其改名副本不能作为可信原答来源：' + str(path))
    public = []
    restricted = []
    if path.suffix.lower() == '.json':
        data = read_json(path)
        if isinstance(data, dict) and 'persona_id' in data and 'dimensions' in data:
            raise ValueError('人设成品JSON不能作为可信原答来源：' + str(path))
        for field,flag in restricted_objects(data):
            if type(flag) is not bool:raise ValueError(field+'.restricted必须为布尔值')
        is_state = isinstance(data, dict) and isinstance(data.get('sources'), list) and (
            'issued_questions' in data or 'pending' in data or path.name.startswith('interview-state'))
        if is_state:
            for index, record in enumerate(data['sources']):
                if not isinstance(record, dict) or not isinstance(record.get('answer'), str):
                    continue
                pair = ('/sources/' + str(index) + '/answer', record['answer'])
                if data.get('restricted') is not True and record.get('restricted') is not True:public.append(pair)
            kind = 'interview_answers_only'
        else:
            public = list(unrestricted_leaves(data))
            kind = 'json_leaf_strings'
        restricted=list(restricted_payloads(data))
        fictional = has_fictional_mode(data)
    else:
        if '## AI交接完整数据' in raw and '"persona_id"' in raw:
            raise ValueError('人设成品Markdown不能作为可信原答来源：' + str(path))
        public = [('text', raw)]
        kind = 'raw_text'
        fictional = bool(re.search(r'(?m)^\s*mode\s*:\s*fictional_demo\s*$', raw))
    return {'path': str(path), 'sha256': sha(path), 'kind': kind, 'fictional_demo': fictional,
            'public': public, 'restricted': restricted}


def source_metadata(doc):
    return {key: doc[key] for key in ('path', 'sha256', 'kind', 'fictional_demo')} | {
        'public_string_count': len(doc['public']), 'restricted_answers_excluded': len(doc['restricted'])}


def freeze_sources(source_paths, manifest):
    paths = sorted(set(source_paths), key=str)
    if not paths:
        raise ValueError('必须显式提供--sources，不能采用persona内部的来源路径')
    docs = [source_document(path) for path in paths]
    entries = [source_metadata(doc) for doc in docs]
    if manifest.exists():
        old = read_json(manifest)
        if old.get('sources') != entries:
            raise ValueError('既有来源清单与当前来源不同；禁止覆盖冻结清单')
        return old
    result = {'schema_version': 'quote-sources-1.0',
              'prepared_at': datetime.now(timezone.utc).isoformat(), 'sources': entries,
              'note': '显式来源名单和sha256冻结；不证明来源真实或文本可公开。'}
    manifest.parent.mkdir(parents=True, exist_ok=True)
    with manifest.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2))
    return result


def public_fields(data):
    for name in ('display_name', 'business', 'summary'):
        yield '/' + name, data.get(name)
    for index, dimension in enumerate(data.get('dimensions', [])):
        if not isinstance(dimension, dict):
            continue
        for name in ('main', 'detail'):
            yield '/dimensions/' + str(index) + '/' + name, dimension.get(name)
        for number, value in enumerate(dimension.get('short', [])):
            yield '/dimensions/' + str(index) + '/short/' + str(number), value
    for name in ('evidence_records', 'content_actions'):
        for index, record in enumerate(data.get(name, [])):
            if isinstance(record, dict):
                for field in ('title', 'detail'):
                    yield '/' + name + '/' + str(index) + '/' + field, record.get(field)
    for name in ('confirmed_facts', 'pending_evidence', 'public_boundaries', 'unknowns'):
        for index, value in enumerate(data.get(name, [])):
            yield '/' + name + '/' + str(index), value


def segments(value):
    for line in value.splitlines():
        text = line.strip()
        if not text:
            continue
        for prefix in LABEL_PREFIXES:
            if text.startswith(prefix):
                text = text[len(prefix):].strip()
                break
        for suffix in LABEL_SUFFIXES:
            if text.endswith(suffix):
                text = text[:-len(suffix)].strip()
                break
        if text:
            yield text


def locate_public(doc, locator):
    for loc, value in doc['public']:
        if loc == locator:
            return value
    if locator.startswith('L') and doc['kind'] == 'raw_text':
        match = re.fullmatch(r'L([1-9][0-9]*)(?:-L?([1-9][0-9]*))?', locator)
        if match:
            start = int(match.group(1)); end = int(match.group(2) or start)
            lines = doc['public'][0][1].splitlines()
            if 1 <= start <= end <= len(lines):
                return '\n'.join(lines[start - 1:end])
    raise ValueError('locator不是允许的公开原答：' + locator)


def validate_quotes(data, persona_path, source_paths, manifest_path):
    errors = []; matches = []; docs = []; registered = []; count = 0
    report = {'quote_guard_valid': False, 'semantic_verified': False, 'privacy_semantic_verified': False,
              'warnings': ['准确子串不证明否定、时间、范围、角色或公开授权完整；这些仍须原句保留和独立审读。'],
              'errors': errors, 'field_matches': matches, 'source_manifest': str(manifest_path) if manifest_path else None}
    try:
        if not isinstance(data, dict):
            raise ValueError('persona根对象须为JSON对象')
        if not source_paths or not manifest_path:
            raise ValueError('必须显式传--sources及预先冻结的--source-manifest')
        paths = sorted(set(Path(p).resolve() for p in source_paths), key=str)
        persona_path = Path(persona_path).resolve()
        if persona_path in paths:
            raise ValueError('不能把本轮persona自身当可信来源')
        manifest_path = Path(manifest_path).resolve()
        manifest = read_json(manifest_path)
        if manifest.get('schema_version') != 'quote-sources-1.0':
            raise ValueError('来源清单版本无效')
        docs = [source_document(path) for path in paths]
        expected = [source_metadata(doc) for doc in docs]
        if manifest.get('sources') != expected:
            raise ValueError('显式来源名单或sha256与冻结清单不一致')
        if persona_path.is_file() and manifest_path.stat().st_mtime_ns > persona_path.stat().st_mtime_ns:
            raise ValueError('须先冻结来源清单，再写persona；禁止生成后补造可信来源')
        privacy=delivery_privacy(data,docs)
        report['delivery_privacy']=privacy
        report['privacy_guard_valid']=privacy['valid']
        errors.extend(privacy['errors'])
        if any(doc['fictional_demo'] for doc in docs) and data.get('mode') != 'fictional_demo':
            raise ValueError('存在fictional_demo原始来源，成卡必须保持fictional_demo')
        registry = data.get('public_quotes')
        if registry is not None and not isinstance(registry, list):
            raise ValueError('public_quotes须为数组')
        quote_ids = set()
        restricted = [text.strip() for doc in docs for _, text in doc['restricted'] if text.strip()]
        for index, quote in enumerate(registry or []):
            if not isinstance(quote, dict) or any(not isinstance(quote.get(k), str) or not quote[k].strip() for k in ('id', 'text', 'source_file', 'source_locator')):
                errors.append('public_quotes/' + str(index) + '登记字段不完整'); continue
            if quote['id'] in quote_ids:
                errors.append('public_quotes/' + str(index) + '的id重复'); continue
            quote_ids.add(quote['id'])
            candidates = [doc for doc in docs if quote['source_file'] == doc['path'] or
                          (not Path(quote['source_file']).is_absolute() and quote['source_file'] == Path(doc['path']).name)]
            if len(candidates) != 1:
                errors.append('public_quotes/' + str(index) + '来源未显式信任或文件名不唯一'); continue
            doc = candidates[0]
            try:
                original = locate_public(doc, quote['source_locator'])
                text = quote['text'].strip()
                if not text or text not in original:
                    raise ValueError('登记quote不是对应来源的准确子串')
                if any(private in text for private in restricted):
                    raise ValueError('登记quote复用了整条受限原答')
                registered.append({'id': quote['id'], 'text': text, 'source_file': doc['path'], 'source_locator': quote['source_locator']})
            except ValueError as exc:
                errors.append('public_quotes/' + str(index) + '：' + str(exc))
        restricted = [text.strip() for doc in docs for _, text in doc['restricted'] if text.strip()]
        checked = 0
        for field, value in public_fields(data):
            checked += 1
            if not isinstance(value, str) or not value.strip():
                errors.append(field + '不是非空文字'); continue
            fragments = list(segments(value))
            if not fragments:
                errors.append(field + '只有标签，没有原文断言'); continue
            for number, fragment in enumerate(fragments, 1):
                count += 1
                if any(private in fragment for private in restricted):
                    errors.append(field + '第' + str(number) + '段复用了整条受限原答'); continue
                if fragment in UNKNOWN_LABELS:
                    matches.append({'field': field, 'line': number, 'fixed_label': fragment}); continue
                hit = None
                if registry is not None:
                    for quote in registered:
                        if fragment in quote['text']:
                            hit = {k: quote[k] for k in ('id', 'source_file', 'source_locator')}; break
                else:
                    for doc in docs:
                        for locator, original in doc['public']:
                            if fragment in original:
                                hit = {'source_file': doc['path'], 'source_locator': locator}; break
                        if hit: break
                if not hit:
                    errors.append(field + '第' + str(number) + '段未找到准确公开原文；不能改词或拼接改写')
                else:
                    matches.append({'field': field, 'line': number,
                                    'fragment_sha256': hashlib.sha256(fragment.encode()).hexdigest(), **hit})
        if not checked:
            errors.append('没有可验证的公开断言字段')
        report.update(assertion_fields_checked=checked, fragments_checked=count,
                      registered_quotes=len(registered), source_files=[source_metadata(doc) for doc in docs])
    except (OSError, ValueError, TypeError, KeyError) as exc:
        errors.append(str(exc))
    report['quote_guard_valid'] = not errors
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('persona', nargs='?', type=Path)
    parser.add_argument('--sources', nargs='+', action='append', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    sources = flatten_sources(args.sources)
    try:
        if args.prepare:
            if args.persona:
                raise ValueError('冻结来源时不传persona；先冻结再生成成品')
            result = freeze_sources(sources, args.source_manifest.resolve())
            print(json.dumps({'prepared': True, 'manifest': str(args.source_manifest.resolve()), 'sources': len(result['sources'])}, ensure_ascii=False))
            return 0
        if not args.persona:
            raise ValueError('检查时须传persona.json')
        result = validate_quotes(read_json(args.persona), args.persona, sources, args.source_manifest)
    except (OSError, ValueError, TypeError) as exc:
        result = {'quote_guard_valid': False, 'semantic_verified': False, 'errors': [str(exc)]}
    report = args.report or (args.persona.parent / 'quote-validation.json' if args.persona else args.source_manifest.with_name('quote-prepare-error.json'))
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'quote_guard_valid': result['quote_guard_valid'], 'errors': len(result['errors']), 'report': str(report.resolve())}, ensure_ascii=False))
    return 0 if result['quote_guard_valid'] else 2


if __name__ == '__main__':
    sys.exit(main())
