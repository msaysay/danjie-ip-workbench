#!/usr/bin/env python3
"""One durable six-dimension persona interview; no inference or budget resets."""
import argparse
import copy
import json
import os
from pathlib import Path
from question_gate import check_question

STATE_SCHEMA = 'persona-detailed-1.0'
STAGES = ('identity', 'customer', 'judgment', 'relationship', 'evidence', 'action')
STAGE_TITLES = dict(zip(STAGES, ('现实身份', '客户场景', '专业判断', '人格关系', '信任证据', '内容动作')))
ANSWER_BASES = {'reported', 'recollection', 'self_judgment', 'planned', 'unknown'}
PROTECTED = {'question_count', 'issued_questions', 'sources', 'stage_counts', 'limits',
             'pending', 'completed', 'state_schema', 'current_stage', 'skipped_slots_history',
             'customer_origin'}


def strings(value, name, allow_empty=True):
    if not isinstance(value, list) or any(not isinstance(x, str) or not x.strip() for x in value):
        raise ValueError(name + '须为非空槽位文字组成的数组')
    result = list(dict.fromkeys(value))
    if not allow_empty and not result:
        raise ValueError(name + '不能为空')
    return result


def stage(value):
    if value not in STAGES:
        raise ValueError('stage须为identity/customer/judgment/relationship/evidence/action之一')
    return value


def fresh(request):
    if request.get('mode') not in ('real', 'fictional_demo'):
        raise ValueError('首次须明确mode=real或fictional_demo')
    return {'state_schema': STATE_SCHEMA, 'mode': request['mode'],
            'limits': {'total': 24}, 'question_count': 0,
            'issued_questions': [], 'sources': [], 'covered_slots': [], 'skipped_slots': [],
            'unknowns': [], 'completed': False, 'pending': None, 'next_slot': None,
            'current_stage': 'identity'}


def validate_state(state):
    if not isinstance(state, dict) or state.get('state_schema') != STATE_SCHEMA:
        raise ValueError('不是本详细版采访状态，不能静默迁移或重置旧题数')
    if 'customer_origin' in state or 'stage_counts' in state:
        raise ValueError('详细版没有客群入口或阶段预算，不能接入旧融合状态')
    if state.get('mode') not in ('real', 'fictional_demo'):
        raise ValueError('状态的mode无效')
    if state.get('limits') != {'total': 24}:
        raise ValueError('状态须保持24问唯一总上限，禁止改上限继续采访')
    questions = state.get('issued_questions')
    if not isinstance(questions, list) or type(state.get('question_count')) is not int or state['question_count'] != len(questions):
        raise ValueError('题数与已发问记录不符，不能归零或删历史')
    ids = set()
    for index, question in enumerate(questions, 1):
        if not isinstance(question, dict) or question.get('id') != 'P' + str(index):
            raise ValueError('问题ID须按全局P1起连续，不按阶段重新编号')
        if question.get('stage') not in STAGES or any(not isinstance(question.get(k), str) or not question[k].strip() for k in ('slot', 'text')):
            raise ValueError('已发问题缺stage/slot/text')
        ids.add(question['id'])
    if len(questions) > 24:
        raise ValueError('历史已超24问总上限，不能继续或重置')
    if type(state.get('completed')) is not bool:
        raise ValueError('completed须为布尔值')
    for field in ('covered_slots', 'skipped_slots'):
        strings(state.get(field), field)
    if not isinstance(state.get('unknowns'), list):
        raise ValueError('unknowns须为数组')
    sources = state.get('sources')
    if not isinstance(sources, list):
        raise ValueError('采访sources须为实际原答数组')
    answer_ids = set()
    expected_kind = 'simulation' if state['mode'] == 'fictional_demo' else 'user_statement'
    for answer in sources:
        if not isinstance(answer, dict) or answer.get('id') not in ids or answer.get('id') in answer_ids:
            raise ValueError('原答必须一问一记录，对应已发问题，不能另造来源')
        if answer.get('kind') != expected_kind or not isinstance(answer.get('answer'), str) or not answer['answer'].strip():
            raise ValueError('原答或模拟/真人性质与状态不符')
        q = questions[int(answer['id'][1:]) - 1]
        if answer.get('stage') != q['stage'] or type(answer.get('restricted')) is not bool:
            raise ValueError('原答stage/restricted不符')
        if answer.get('basis') not in ANSWER_BASES or answer.get('response') not in ('answer', 'skip'):
            raise ValueError('原答basis/response无效')
        answer_ids.add(answer['id'])
    pending = state.get('pending')
    if pending is not None:
        if not questions or pending != questions[-1]['id'] or pending in answer_ids or state['completed']:
            raise ValueError('pending不是当前唯一未答问题')
    expected_answers = ids - ({pending} if pending else set())
    if answer_ids != expected_answers:
        raise ValueError('原答记录不完整，不能跳过待答问题或伪报完成')
    if state.get('current_stage') not in (*STAGES, 'complete'):
        raise ValueError('current_stage无效')
    if state['completed'] != (state['current_stage'] == 'complete'):
        raise ValueError('completed须与终态complete一致')
    if state['completed'] and state.get('next_slot') is not None:
        raise ValueError('已结束状态不得保留next_slot')
    if pending and state['current_stage'] != questions[-1]['stage']:
        raise ValueError('pending问题stage与当前阶段不符')
    if state.get('next_slot') is not None and (not isinstance(state['next_slot'], str) or not state['next_slot'].strip()):
        raise ValueError('next_slot须为槽位文字或null')
    return state


def step(previous, request):
    if not isinstance(request, dict):
        raise ValueError('request须为对象')
    if PROTECTED.intersection(request):
        raise ValueError('请求不能手写覆盖脚本计数、上限或原答历史：' + ','.join(sorted(PROTECTED.intersection(request))))
    op = request.get('op')
    if previous is None and op not in ('init', 'ask'):
        raise ValueError('新采访先init或ask，不能凭空登记回答')
    state = copy.deepcopy(previous) if previous is not None else fresh(request)
    validate_state(state)
    if 'mode' in request and request['mode'] != state['mode']:
        raise ValueError('不能在同一采访中改变mode或重新领取题数预算')
    if op == 'init':
        # Idempotent only: calling init on a resumed state never clears history.
        return state
    if state['completed']:
        raise ValueError('采访已结束；后续修订成卡，不重开或重置本状态')
    if op == 'advance':
        # Both transitions run on private copies. Nothing is persisted until the
        # answer/skip AND the next ask have passed all unchanged state guards.
        allowed = {'op', 'expected_pending', 'answer', 'next_question'}
        if set(request) - allowed:
            raise ValueError('advance只接受op/expected_pending/answer/next_question，不覆盖模式或状态字段')
        if state['pending'] is None or request.get('expected_pending') != state['pending']:
            raise ValueError('advance须明确匹配当前expected_pending，重复或过期提交不记到下一题')
        reply, question = request.get('answer'), request.get('next_question')
        if not isinstance(reply, dict) or reply.get('op') not in ('answer', 'skip'):
            raise ValueError('advance.answer须为op=answer或skip的原答对象')
        reply_allowed = {'op', 'text', 'basis', 'covered_slots', 'skipped_slots', 'restricted'}
        if set(reply) - reply_allowed:
            raise ValueError('advance.answer含未允许字段，不能改模式、历史或另设next_slot')
        if not isinstance(question, dict) or set(question) != {'stage', 'slot', 'text'}:
            raise ValueError('advance.next_question须且仅含stage/slot/text')
        answered = step(state, reply)
        return step(answered, {'op': 'ask', **question})
    if op == 'cover':
        if state['pending'] is not None:
            raise ValueError('先登记当前问题的回答，再接入已知资料槽位')
        left = request.get('slots', request.get('covered_slots'))
        covered = strings(left, 'slots', allow_empty=False)
        if 'slots' in request and 'covered_slots' in request and covered != strings(request['covered_slots'], 'covered_slots'):
            raise ValueError('slots与covered_slots别名不一致')
        for slot in covered:
            if slot not in state['covered_slots']:
                state['covered_slots'].append(slot)
        if 'next_slot' in request:
            state['next_slot'] = request['next_slot']
    elif op == 'ask':
        if state['pending'] is not None:
            raise ValueError('上一问尚未回答或跳过，不能连续发问')
        if state['question_count'] >= state['limits']['total']:
            raise ValueError('已达本轮' + str(state['limits']['total']) + '次实际发问上限')
        current = stage(request.get('stage'))
        if any(not isinstance(request.get(k), str) or not request[k].strip() for k in ('slot', 'text')):
            raise ValueError('ask需要唯一slot与一个text问题')
        check_question(request['text'], request['slot'], current,
                       state['covered_slots'], state['skipped_slots'])
        if request['slot'] in state['skipped_slots']:
            raise ValueError('该槽位已跳过或拒答，不再换说法追问')
        if request['slot'] in state['covered_slots']:
            raise ValueError('该信息已有资料或原答覆盖，不重复发问；有新缺口须明确新的具体问题')
        number = state['question_count'] + 1
        sid = 'P' + str(number)
        state['issued_questions'].append({'id': sid, 'text': request['text'], 'slot': request['slot'], 'stage': current})
        state['question_count'] = number
        state.update(pending=sid, next_slot=request['slot'], current_stage=current)
    elif op in ('answer', 'skip'):
        if state['pending'] is None:
            raise ValueError('没有待回答的问题')
        if not isinstance(request.get('text'), str) or not request['text'].strip():
            raise ValueError('须保留真实原答或跳过原意，不让AI代答')
        if 'restricted' in request and type(request['restricted']) is not bool:
            raise ValueError('restricted须为布尔值')
        basis = request.get('basis', 'unknown' if op == 'skip' else 'reported')
        if basis not in ANSWER_BASES:
            raise ValueError('原答basis不接收AI候选事实；用reported/recollection/self_judgment/planned/unknown')
        extra = strings(request.get('covered_slots', []), 'covered_slots')
        skipped = strings(request.get('skipped_slots', []), 'skipped_slots')
        if skipped and op != 'skip':
            raise ValueError('skipped_slots只随skip登记')
        question = state['issued_questions'][-1]
        sid = state['pending']
        state['sources'].append({'id': sid, 'kind': 'simulation' if state['mode'] == 'fictional_demo' else 'user_statement',
                                 'answer': request['text'], 'origin': '本轮' + sid, 'stage': question['stage'],
                                 'restricted': request.get('restricted', op == 'skip'), 'basis': basis,
                                 'response': op})
        if op == 'skip':
            for slot in [question['slot']] + skipped:
                if slot not in state['skipped_slots']:
                    state['skipped_slots'].append(slot)
                    state['unknowns'].append({'slot': slot, 'reason': request['text'], 'question_id': sid})
        else:
            for slot in [question['slot']] + extra:
                if slot not in state['covered_slots']:
                    state['covered_slots'].append(slot)
        state['pending'] = None
        state['next_slot'] = request.get('next_slot')
    elif op == 'finish':
        if state['pending'] is not None:
            raise ValueError('先记录最后一问的回答或跳过，不以finish绕过')
        state.update(completed=True, next_slot=None, current_stage='complete')
    else:
        raise ValueError('op须为init/cover/ask/answer/skip/advance/finish')
    return validate_state(state)


def load_state(snapshot, journal):
    # Appending a complete checkpoint precedes the snapshot. The latest complete
    # journal object is authoritative even when a snapshot is valid but stale.
    if journal.is_file():
        for line in reversed(journal.read_text(encoding='utf-8').splitlines()):
            try:
                candidate = json.loads(line)
            except ValueError:
                continue
            if isinstance(candidate, dict) and 'question_count' in candidate:
                return validate_state(candidate)
    if snapshot.is_file():
        try:
            return validate_state(json.loads(snapshot.read_text(encoding='utf-8-sig')))
        except ValueError as exc:
            raise ValueError('状态损坏或版本不符，且无可恢复的完整本版日志：' + str(exc))
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    args = parser.parse_args()
    try:
        request = json.loads(args.request.read_text(encoding='utf-8-sig'))
        journal = args.state.with_name(args.state.name + '.events.jsonl')
        state = step(load_state(args.state, journal), request)
        args.state.parent.mkdir(parents=True, exist_ok=True)
        # No rename/replace/delete: these triggered WorkBuddy deletion approvals.
        # Keep a truncated previous append separate from the new checkpoint.
        needs_separator = False
        if journal.is_file() and journal.stat().st_size:
            with journal.open('rb') as prior:
                prior.seek(-1, os.SEEK_END)
                needs_separator = prior.read(1) != b'\n'
        with journal.open('a', encoding='utf-8') as log:
            if needs_separator:
                log.write('\n')
            log.write(json.dumps(state, ensure_ascii=False) + '\n')
            log.flush()
            os.fsync(log.fileno())
        with args.state.open('w', encoding='utf-8') as snapshot:
            snapshot.write(json.dumps(state, ensure_ascii=False, indent=2))
            snapshot.flush()
            os.fsync(snapshot.fileno())
        durable = load_state(args.state, journal)
        if durable != state:
            raise ValueError('落盘回读与本次结果不符，不能展示下一题')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.exit(2, str(exc) + '\n')
    pending_question = next((q for q in durable['issued_questions'] if q['id'] == durable['pending']), None)
    question_for_student = None
    if pending_question is not None:
        question_for_student = ('第' + pending_question['id'][1:] + '问｜' +
                                STAGE_TITLES[pending_question['stage']] + '\n' + pending_question['text'])
    print(json.dumps({'question_count': durable['question_count'],
                      'limits': durable['limits'], 'pending': durable['pending'], 'current_stage': durable['current_stage'],
                      'completed': durable['completed'], 'pending_question': pending_question,
                      'question_for_student': question_for_student}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
