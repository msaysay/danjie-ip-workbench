# 学员结果输出合同 · 0.2.3

只输出老板本人六维人设。字段示意不是人物事实。先读取已有目标客群卡，不重新生成目标客群卡，不追加客户六项与10对需求顾虑，不用--customer/--customer-origin参数。

## 前台与后台分开

学员默认只接收当前单个问题、必要补充和最终完整人设结果。后台可以读取资料、记录原答、调用工具、按规则计数、恢复状态、冻结来源、校验和真实保存，但不逐步播报这些过程。程序和问卷规则、操作模型、计数schema均不变。

最终回复默认取本次输出的`student_message`，再给完整PNG预览/附件及HTML；确有影响结果的缺口才用一句人话补充。不整段贴stdout、校验日志、异常堆栈或技术JSON。没有生成/保存成功就不称成功；用简短人话说真实结果和必要下一步。

面向人的MD、HTML、PNG和默认聊天只保留六维人设内容、环绕图/一句话、底三栏和必要事实状态。不塞source_ids、Pn/A1来源索引、文件ID/版本、来源路径/哈希、读取匹配信息、校验记录或交接JSON块。这里的文件ID不包括人物真实品牌/公司名称；不要误删业务事实。MD是同文稿，不是后台数据库导出。

证据性质以人话如“依据：本人回忆”呈现；计划、待补、一次/日常、职责范围、适用条件、材料能证明什么及不能证明什么保留。fictional_demo仍显著显示“虚构示例”；incomplete可显示“部分信息待补充”。prefilled/interviewed等内部状态不必展示，但不能把0问整理说成完整采访。

后台persona JSON、公开sources、真实state/原答、来源清单、校验、计数与保存核验仍实做并保留，依原隐私规则分开存放。结果不显示来源索引不等于取消溯源，前台不显示日志不等于校验通过。默认不附结构化JSON/技术报告；用户明确需要时再提供可安全交接的数据，受限原答/原始日志不作为公开附件。

## persona.json及实际状态

根字段沿人设schema_version="1.0"：persona_id、persona_version、mode、status、display_name、business、question_count、issued_questions、sources、dimensions、summary、evidence_records、content_actions、confirmed_facts、pending_evidence、public_boundaries、unknowns、interview_state、upstream_cards。audience_binding可省，仅保留实际已有的轻量来源元数据；不知道ID或版本不造值，也不以此建立另一张客户卡。

不写customer_profile、customer_origin、customer_source或response_links。已有客户资料只是本次原始上下文，不能替代老板本人做法或证明其能力。persona_id是本次卡的ID，不冒充上游已有ID。

mode=real或fictional_demo；输入或原始采访为虚构，结果与来源均保留fictional_demo/simulation，不升级真人。status=interviewed只用于确实发生逐题问答且本轮finish的整理，不代表外部核实或充分；0问资料整理为prefilled，关键业务/角色仍不清或提前结束为incomplete。

question_count等于真实issued_questions长度，最多24。每条问题={id,text,slot,stage}，Pn全局连续，stage=identity/customer/judgment/relationship/evidence/action；不能把未展示的问题加进历史，也不能为缩短记录删澄清。实际问答须传原始同轮--interview-state，核对模式、问题文本、次数、来源及完成状态。0问可无state；若有state也要如实为0问。

后台连续采访使用advance，将当前answer/skip与下一问ask作为一次成功检查点提交；expected_pending防过期/重复请求。question_for_student、pending_question只为成功回读后的CLI响应，不属于持久state或persona字段。模型只能展示与真实pending完全一致的已落盘题串；失败/null不能预测下一题。首次ask、最后answer/skip与finish沿原规则执行，不改24问预算或state schema。

采访state_schema=persona-detailed-1.0，limits={"total":24}，含mode、question_count、issued_questions、sources、covered_slots、skipped_slots、unknowns、pending、next_slot、current_stage、completed。无分段预算或customer_origin。persona.interview_state只作摘要，不取代原state核验。

## 六维具体内容

恰好6项，固定ID、标题和顺序：

1. identity／现实身份：真实主营、本人当前职责、本人/团队分工、相关经历。
2. customer／客户场景：实际购买/服务对象、触发时刻、顾虑原话、本人介入位置；不生成完整客户画像。
3. judgment／专业判断：实际步骤、看什么、如何有条件取舍、理由；范围和未知结果不丢。
4. relationship／人格关系：具体沟通动作与本人原声；希望形象与已发生行为分清。
5. evidence／信任证据：真实材料、能核对什么、是否展示、是否可公开、待补状态。
6. action／内容动作：实际时间、现场、表达条件、协助与公开范围；计划不升现状。

每维={id,title,main,detail,short,basis,source_ids}。main是本维核心原句，detail用换行连接有信息增量的完整原句。每维有来源才展开3—5个具体细点，不硬凑；没有足够信息可留短或unknown。short恰好两条，允许较长，不为“金句”改词。detail可与main重复，优先忠实，不编一段解释填空。

main/detail/short精准摘录可信公开原文，可忽略外层空白、明确固定状态标签，或分行连接完整片段；不能同义替换、拼改角色与否定。不得从“不是本人安装”摘“本人安装”，不得从一次经历推出日常口碑。业务、姓名、summary、证据与内容动作的业务断言也接受原话校验。

basis=reported/recollection/self_judgment/planned/suggested/unknown/mixed。非unknown须有效source_ids；unknown允许无来源并用“待补充”等固定状态。suggested只用于已有输入确实如此标记的建议，本候选不凭空造建议能力/经历/内容计划。主句与详情/短句的状态一致，不能标题确定、末尾才声明待核。

summary优先本人已提供的一句身份原话；不重拼多角色的新判断，不纳入“分开记、不编故事、只用原话”等制卡指令。

## 来源与公开边界

persona.sources每条至少{id,kind,answer,origin}，采访来源同实际Pn；已有材料用A1起并写真实位置，不伪装没有发过的Pn。一次原答覆盖多维仍只一条；来源kind与真人/模拟性质相符。保留计划、回忆、本人判断与未知，不靠source_ids把候选变事实。

可信来源只能是实际用户原答、最终本轮state或实际已有输入。persona、它的改名副本、intake、核对表、新生成摘录，以及本Skill生成的人看MD/HTML/PNG，均不能作为新的事实证据；人看MD是成品，不作原始raw来源。结构化交接只使用后台JSON，交接也不让成品自证来源。来源名单在生成persona前冻结，记录明确路径和sha256；渲染必须显式传相同--sources与--source-manifest，不接受persona自报路径作为信任来源。

显式restricted=true整条/子树排除公开可信原文。受限原答只留本地原始state/journal，不进入可交接JSON、MD、sources、附加字段、unknowns、公开边界或诊断报告，也不摘其中另一半句绕过。不要为了“记录来源”把隐私藏到后台字段。最终persona全部字符串与键名也过显式隐私门槛。此为机械门槛，不证明模型理解所有隐私含义。

保留原句仍需人工核语义：付款与拍板、共同决定与共同付款、本人和团队、组织与操作、沟通与最终负责不能换义；“未提供/没给你看”不变“没有/不能公开”。引用检查只防改词与显式受限泄漏，不能证明摘录充分、事实真实或授权完整。

## 原结构保留字段及三栏

evidence_records最多6条，content_actions最多4条，每条={title,detail,basis,source_ids}；有材料再填，空数组合法。title/detail也须准确可公开原文，不为填结构新增履历、成绩或承诺。无材料时把真实状态记相应维度，不编“案例/记录已齐全”。

confirmed_facts、pending_evidence为文字数组，各最多6条，public_boundaries为文字数组；前台对应“已确认事实/待补证据/公开边界”。已确认意为本人或实际资料明确提供，非外部核实；候选、计划、未知不进已确认。待补栏写确有依据的材料状态，不把全部普通未答项塞进去。unknowns保留其他缺口，不把拒答变成“守底线”卖点。

底三栏可用固定“待补充”占位，不能为摆满三栏编规则或证据。前台保留证据性质、公开边界和必要缺口，不交原始采访日志。上游ID/版本未知保留在后台，默认不把这些技术缺口展示给学员；如果资料无法辨认实际影响成卡，只说需要补充哪项信息。图片转录保真与客户端自动读图本轮未验收，不能冒称准确。

## 同源渲染与实际保存

记录最后原答并finish，在persona生成前执行：

`python3 <Skill目录>/scripts/check_quotes.py --prepare --sources <最终采访state或实际原始材料...> --source-manifest trusted-sources.json`

写persona后运行：

`python3 <Skill目录>/scripts/run.py persona.json --sources <同一冻结来源...> --source-manifest trusted-sources.json --interview-state interview-state.json --out result --save-downloads`

无实际采访的0问预填可省--interview-state，仍须冻结真实来源。输入资料不静默改写；守卫失败回原答修数据，不改来源或校验器绕过。

前台是一张完整卡：六维详细内容→原版六维环绕图与一句话→底三栏。HTML与长PNG同源；同文稿仅含人设结果与必要缺口。完整公开来源和结构化交接内容保留在后台JSON，不嵌入人看MD。证据与内容动作进入对应维度及后台原字段，不另加长段；没有客户卡附录。

run.py只选择已有带Pillow的Python，无安装或环境修改。默认交真实PNG附件与预览、HTML，以及需要的人看同文稿，不默认交JSON或技术报告。不放网页下载按钮；用--save-downloads自动存已有Downloads，核对真实文件存在且字节一致才称已保存；失败保留任务目录PNG，后台分别记录生成/保存状态；前台只用student_message和必要一句补充说真实影响，不展示路径、日志或异常细节。不覆盖旧图，不声称普通浏览器按钮已在WorkBuddy可用。

本候选的标准库状态回归、资料模拟、模型运行、WorkBuddy UI安装和真人内容确认分层记录；任何单层成功不能替代内容准确性或从零完整流程验收，不自动放正式学员目录。
