# 原答冻结与摘录计划

## answers.json

只存本次用户回答原文，不存助手提问示例或复述。不要删限定或把订单/成交改成实付。原答真假仍须本人核对。

```json
{
  "profile_id":"本次唯一学员编号",
  "profile_version":1,
  "mode":"real",
  "status":"draft",
  "customer_type":"individual",
  "question_count":2,
  "sources":[
    {"id":"Q1","answer":"第一条实际回答完整原文","kind":"user_statement"},
    {"id":"Q2","answer":"第二条实际回答完整原文","kind":"user_statement"}
  ]
}
```

mode为real或fictional_demo，模拟kind全部simulation。status为draft、planned（零客户计划对象）或incomplete（业务/对象仍不明）。customer_type为individual、organization或unknown。question_count实际0—10次；直接收到已有回答不虚报新采访。id为不重复Q1—Q10。

prepare创建interview/job.json，不覆盖旧job，锁定answers文件SHA；完整读取返回原答后再写plan。

## plan.json

```json
{
  "schema_version":"literal-1",
  "business_ref":{"source_id":"Q1","quote":"主营完整原句"},
  "group_ref":{"source_id":"Q2","quote":"主要客群完整原句"},
  "dimensions":[
    {"id":"basic","refs":[{"source_id":"Q2","quote":"完整原句"}]},
    {"id":"family","unknown":true},
    {"id":"occupation","unknown":true},
    {"id":"spending","unknown":true},
    {"id":"housing","unknown":true},
    {"id":"habits","unknown":true}
  ],
  "pairs":[
    {"basis":"reported","need_ref":{"source_id":"Q2","quote":"完整需求分句"},"concern_ref":{"source_id":"Q2","quote":"完整顾虑分句"}},
    {"basis":"candidate","need_title":"可能需求","need_detail":"推演与依据，待确认","concern_title":"可能顾虑","concern_detail":"为何可能犹豫及依据，待确认","source_ids":["Q1"]},
    {"basis":"unknown"}
  ],
  "unknown_refs":[]
}
```

仅示结构，不照抄占位文字。pairs实际10个位置，顺序reported→candidate→unknown；脚本分配NC01—NC10。用户明确不推演则不填candidate。不足10个有效问题的unknown不能称有效需求。

六维按固定id顺序。每维选1—2条真正相关原答refs；全无信息用unknown=true且无refs。企业/个人标题由脚本生成，不混淆付款者、拍板者、使用者。

quote须逐字匹配冻结原答完整句或分号分句，可带原有句末标点，六维不截开逗号连接限定；reported需求/顾虑另允许完整逗号分句。普通顿号并列不拆，仅当整段以“想/希望/需要/要/反复问”起头、顿号后是明确“怕/担心/担忧/害怕”时，可在该顿号分出需求与顾虑，整段上下文仍保留。不得把同一句同时填入需求和顾虑。整段回答也可选。保留“接触过、或、左右、有人”、币种与预算/成交/到账性质，不自行换词、缩数值或截掉同句限定。

脚本把refs同文用于main和short，完整关联原答作detail。完整原句已带句末标点时直接衔接，不再重复加分号。仅1条时图第二行标“原答摘录”。原答含印象/估计等时basis保守标estimate。summary只拼固定前缀与原答客群，不再添其他属性；只会去掉“目前主要是/现在主要是/目前常接的是”等固定语法开头，不改客户特征。前台main与detail同文时只显示一次；其他原答上下文照常保留，JSON中的detail和sources不删。

reported标题为所选需求/顾虑原句，说明保留所在完整分号段上下文。不另写main/short/detail/summary，脚本不采用这些自由字段。自己的提问举例不属于sources。

candidate四个文字字段可写可能需求、可能顾虑及依据，前台单独分区并标待确认。不能伪造原话、案例/业绩或性能承诺。unknown_refs可选择原答中“不知道/没问过”等完整句，脚本原样列入未知，不添加不存在的事实。

交付目标为10个需求＋10个担忧、一一对应。原答不足10组时，依据本次六维、业务与购买情境提出其余不同candidate，不把缺行业比例等背景误判成不能推导需求；具体背景未知合并大框，不影响10条主网格。HTML每栏为一个两列五行网格，各条小标签区分原答和推演；不再按reported/candidate拆成两个网格。用户明确禁止推演或缺主营/购买者/任务时才用unknown，并说明无法完成，不把占位当有效需求。用户补信息时按SKILL的新版本流程重新冻结，不修改旧结果。candidate有本次回答依据且与已知组有实质差异，数量不代表质量已通过。

## 输出

compile生成profile-compiled.json并调用渲染器出同文HTML/PNG/MD/JSON，包含原答、来源和输入/job/plan SHA。不要改编译数据：render会重新读取绑定原文件及plan构建预期结果，改显示字段或原答会被拒绝。更正需另存输入版本与新job/结果目录，不覆写旧输入伪造通过。

匹配保证仅是“本次输入里有这句话”，不是原答真实、代表多数、六维选句和配对正确、候选合理或原生格式已通过的证明。仍需核对业务客群、源文件、选句与输出画面。
