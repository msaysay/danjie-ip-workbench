"""Fixed, data-driven long PNG export. No network or image-generation API.

PNG requires an existing Pillow installation and a local CJK font. Never install
dependencies silently. All card text is wrapped, never ellipsized or rewritten.
"""
import html
import os
import re
from pathlib import Path
import xml.etree.ElementTree as ET
from presentation import extra_detail, pending_info

GOLD='#eacf79'
WHITE='#f2f3ed'
GRAY='#aab7ad'
CYAN='#86cedb'
BG='#0d1712'
CARD='#16201a'
LINE='#35463a'


def wrap(value, size, width):
    # Keep numbers/English words intact and closing punctuation with its text.
    raw=re.findall(r'[A-Za-z0-9]+(?:[./%—–-][A-Za-z0-9]+)*|\n|[^\n]',str(value))
    tokens=[]
    for token in raw:
        if token in '。！？；：，、）》】”’%％' and tokens and tokens[-1]!='\n':
            tokens[-1]+=token
        else:
            tokens.append(token)
    lines, current, units = [], '', 0
    for token in tokens:
        # Only an individual unbroken token wider than the whole box may split.
        parts=list(token) if sum(size*(0.6 if c.isascii() else 1.02) for c in token)>width else [token]
        for c in parts:
            weight = sum(size*(0.6 if ch.isascii() else 1.02) for ch in c)
            if c == '\n' or (current and units + weight > width):
                lines.append(current)
                current, units = '', 0
                if c == '\n':
                    continue
            current += c
            units += weight
    if current:
        lines.append(current)
    return lines or ['']


class Scene:
    def __init__(self):
        self.items=[]
        self.height=0

    def rect(self,x,y,w,h,fill=CARD,stroke=LINE,r=12):
        self.items.append(('rect',(x,y,w,h),{'fill':fill,'stroke':stroke,'r':r}))

    def text(self,value,x,y,size=26,fill=WHITE,anchor='start',bold=False):
        self.items.append(('text',(x,y),{'value':str(value),'size':size,'fill':fill,'anchor':anchor,'bold':bold}))

    def paragraph(self,value,x,y,width,size=26,fill=WHITE,bold=False):
        lines=wrap(value,size,width)
        for i,line in enumerate(lines):
            self.text(line,x,y+i*size*1.5,size,fill,bold=bold)
        return len(lines)*size*1.5

    def line(self,x1,y1,x2,y2,fill=LINE):
        self.items.append(('line',(x1,y1,x2,y2),{'fill':fill}))


def make_scene(data,diagram_html):
    s=Scene()
    label='虚构案例' if data['mode']=='fictional_demo' else ('计划客群' if data['status']=='planned' else '待本人核对')
    s.text('蛋解课堂',48,62,22,GOLD,bold=True)
    s.text(label,1032,62,22,GOLD,anchor='end')
    s.text('蛋解六维目标客群画像卡',48,132,42,bold=True)
    s.text('看清客户是谁、想要什么、担心什么。',48,181,25,GOLD)
    s.line(48,215,1032,215)
    s.text('01 客户是谁',48,275,34,bold=True)
    y=310
    # Three rows, two columns. Each row grows to fit all text in either card.
    for row in range(3):
        group=data['dimensions'][row*2:row*2+2]
        heights=[]
        for d in group:
            detail=extra_detail(d)
            heights.append(85+len(wrap(d['main'],28,418))*42+(len(wrap(detail,23,418))*34.5+12 if detail else 0))
        h=max(heights)
        for col,d in enumerate(group):
            x=48+col*502
            s.rect(x,y,482,h)
            s.text('%02d  %s'%(row*2+col+1,d['title']),x+24,y+43,27,GOLD,bold=True)
            used=s.paragraph(d['main'],x+24,y+91,418,28,bold=True)
            if extra_detail(d):
                s.paragraph(extra_detail(d),x+24,y+91+used+12,418,23,GRAY)
        y+=h+20
    y+=35
    s.text('六维画像，一眼看清',48,y,32,GOLD,bold=True)
    y+=30
    svg=re.search(r'<svg\b.*?</svg>',diagram_html,re.S).group(0)
    root=ET.fromstring(svg)
    model_h=float(root.attrib['viewBox'].split()[3])
    classes={
        'model-label':{'size':22,'fill':GRAY},
        'model-value':{'size':25,'fill':WHITE,'bold':True},
        'model-center-kicker':{'size':18,'fill':GOLD},
        'model-center-text':{'size':27,'fill':WHITE,'bold':True},
    }
    def visit(node,inherited=None):
        tag=node.tag.split('}')[-1]
        a=node.attrib
        inherited=dict(inherited or {})
        inherited.update(classes.get(a.get('class'),{}))
        if tag in ('title','desc'):
            return
        if tag=='text':
            size=float(re.search(r'font-size:([\d.]+)',a.get('style','')).group(1)) if 'font-size:' in a.get('style','') else inherited.get('size',25)
            s.text(''.join(node.itertext()),40+float(a['x']),y+float(a['y']),size,a.get('fill',inherited.get('fill',WHITE)),a.get('text-anchor','start'),inherited.get('bold',False))
        elif tag=='line':
            s.line(40+float(a['x1']),y+float(a['y1']),40+float(a['x2']),y+float(a['y2']),'#6e6039')
        elif tag=='polygon':
            pts=[(40+float(p.split(',')[0]),y+float(p.split(',')[1])) for p in a['points'].split()]
            s.items.append(('polygon',pts,{'fill':None,'stroke':GOLD}))
        elif tag=='circle':
            s.items.append(('circle',(40+float(a['cx']),y+float(a['cy']),float(a['r'])),{'fill':a.get('fill',GOLD),'stroke':a.get('stroke')}))
        for child in node:
            visit(child,inherited)
    visit(root)
    y+=model_h+25
    summary_h=100+len(wrap(data['summary'],27,912))*40.5
    s.rect(48,y,984,summary_h,fill='#192219',stroke=None,r=0)
    s.line(48,y,48,y+summary_h,GOLD)
    s.text('一句话画像',74,y+39,22,GOLD)
    s.paragraph(data['summary'],74,y+86,912,27,bold=True)
    y+=summary_h+60
    for kind,title in [('need','02 客户想要什么'),('concern','03 客户担心什么')]:
        s.line(48,y,1032,y)
        y+=65
        s.text(title,48,y,34,bold=True)
        y+=45
        note='根据已有回答整理；可能需求仍要和客户确认。' if kind=='need' else '按编号对应需求；推测的担忧不当成客户原话。'
        s.text(note,48,y,23,GRAY)
        y+=30
        grouped=[p for p in data['pairs'] if p['basis']!='unknown']
        for row in range(0,len(grouped),2):
            pairs=grouped[row:row+2]
            computed=[]
            for p in pairs:
                tlines=len(wrap(p[kind+'_title'],27,380))
                dlines=len(wrap(p[kind+'_detail'],23,380))
                basis_label={'reported':'回答中提到','candidate':'AI推演 · 待确认'}[p['basis']]
                footer=basis_label if kind=='need' else '对应 %02d｜%s\n%s'%(int(p['id'][-2:]),p['need_title'],basis_label)
                computed.append((max(190,68+tlines*40.5+dlines*34.5+len(wrap(footer,19,380))*28.5+24),footer))
            h=max(v[0] for v in computed)
            for col,(p,(_,footer)) in enumerate(zip(pairs,computed)):
                x=48+col*502
                s.rect(x,y,482,h)
                s.text('%02d'%int(p['id'][-2:]),x+22,y+43,27,GOLD if kind=='need' else CYAN,bold=True)
                used=s.paragraph(p[kind+'_title'],x+82,y+43,378,27,bold=True)
                used+=s.paragraph(p[kind+'_detail'],x+82,y+43+used+14,378,23,GRAY)+14
                s.paragraph(footer,x+82,y+43+used+14,378,19,GOLD if kind=='need' else GRAY)
            y+=h+20
        y+=40
    pending=pending_info(data)
    if pending:
        # One shared panel replaces all unknown need AND concern mini-cards.
        top=y
        paragraphs=[(pending['summary'],25,WHITE)]
        paragraphs += [('• '+item,24,GRAY) for item in pending['items']]
        paragraphs += [(pending['prompt'],25,GOLD),(pending['note'],22,GRAY)]
        height=100+sum(len(wrap(text,size,912))*size*1.5+18 for text,size,_ in paragraphs)
        s.rect(48,top,984,height,fill='#192219',stroke=GOLD)
        s.text(pending['title'],74,top+48,30,GOLD,bold=True)
        y=top+98
        for text,size,color in paragraphs:
            y+=s.paragraph(text,74,y,912,size,color)+18
        y=top+height+35
    s.height=int(y+20)
    return s


def export_svg(scene,path):
    e=lambda v:html.escape(str(v),quote=True)
    parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="%d" viewBox="0 0 1080 %d">'%(scene.height,scene.height),'<rect width="1080" height="100%%" fill="%s"/>'%BG,'<g font-family="PingFang SC,Microsoft YaHei,Noto Sans CJK SC,sans-serif">']
    for kind,coords,a in scene.items:
        if kind=='text':
            parts.append('<text x="%s" y="%s" fill="%s" font-size="%s" font-weight="%s" text-anchor="%s">%s</text>'%(*coords,a['fill'],a['size'],'700' if a['bold'] else '400',a['anchor'],e(a['value'])))
        elif kind=='rect':
            parts.append('<rect x="%s" y="%s" width="%s" height="%s" rx="%s" fill="%s" stroke="%s"/>'%(*coords,a['r'],a['fill'],a['stroke'] or 'none'))
        elif kind=='line':
            parts.append('<line x1="%s" y1="%s" x2="%s" y2="%s" stroke="%s"/>'%(*coords,a['fill']))
        elif kind=='circle':
            parts.append('<circle cx="%s" cy="%s" r="%s" fill="%s" stroke="%s"/>'%(*coords,a['fill'],a['stroke'] or 'none'))
        elif kind=='polygon':
            parts.append('<polygon points="%s" fill="none" stroke="%s"/>'%(' '.join('%s,%s'%p for p in coords),a['stroke']))
    parts+=['</g></svg>']
    path.write_text(''.join(parts),encoding='utf-8')


def export_png(scene,path,font_path=None):
    if scene.height > 24000:
        raise RuntimeError('文字过长，长图超过24000像素；未裁字或冒充PNG成功。请缩短重复表述后重试。')
    try:
        from PIL import Image,ImageDraw,ImageFont,PngImagePlugin
    except ImportError as exc:
        raise RuntimeError('PNG导出需要当前Python已有Pillow；未自动安装。HTML已保留，不能声称PNG已生成。') from exc
    if font_path and not Path(font_path).is_file():
        raise RuntimeError('--font指定的中文字体文件不存在，未静默换字体。')
    candidates=[font_path,os.environ.get('DANJIE_CJK_FONT'),'/System/Library/Fonts/PingFang.ttc','/System/Library/Fonts/STHeiti Medium.ttc','C:/Windows/Fonts/msyh.ttc','C:/Windows/Fonts/simhei.ttf','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc','/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc']
    chosen=next((p for p in candidates if p and Path(p).is_file()),None)
    if not chosen:
        raise RuntimeError('PNG导出未找到中文字体；可用--font指定本机中文字体。不使用缺中文字的默认字体冒充成功。')
    im=Image.new('RGB',(1080,scene.height),BG)
    draw=ImageDraw.Draw(im)
    cache={}
    for kind,coords,a in scene.items:
        if kind=='text':
            size=round(a['size'])
            if size not in cache:
                cache[size]=ImageFont.truetype(chosen,size)
            draw.text(coords,a['value'],font=cache[size],fill=a['fill'],anchor={'start':'ls','middle':'ms','end':'rs'}[a['anchor']],stroke_width=0)
        elif kind=='rect':
            x,y,w,h=coords
            draw.rounded_rectangle((x,y,x+w,y+h),radius=a['r'],fill=a['fill'],outline=a['stroke'],width=1)
        elif kind=='line':
            draw.line(coords,fill=a['fill'],width=1)
        elif kind=='circle':
            x,y,r=coords
            draw.ellipse((x-r,y-r,x+r,y+r),fill=a['fill'],outline=a['stroke'],width=1)
        elif kind=='polygon':
            draw.line(coords+[coords[0]],fill=a['stroke'],width=1)
    meta=PngImagePlugin.PngInfo()
    meta.add_text('Title','蛋解六维目标客群画像卡')
    meta.add_text('Description','三部分完整长图；不代表内容已获真人确认。')
    im.save(path,pnginfo=meta)
    return {'width':1080,'height':scene.height,'font':str(chosen),'text_elements':sum(k=='text' for k,_,_ in scene.items)}


def export_long_image(data,diagram_html,out,stem,font_path=None):
    scene=make_scene(data,diagram_html)
    svg=out/(stem+'-完整长图.svg')
    png=out/(stem+'-完整长图.png')
    export_svg(scene,svg)
    result={'svg':str(svg),'png':None,'png_ready':False}
    try:
        info=export_png(scene,png,font_path)
        result.update(info,png=str(png),png_ready=True)
    except (RuntimeError,OSError,ValueError) as exc:
        result['png_error']=str(exc)
    return result
