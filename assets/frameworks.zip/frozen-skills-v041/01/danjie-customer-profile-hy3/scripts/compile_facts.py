#!/usr/bin/env python3
"""Bind literal card facts to an immutable snapshot of this interview's answers.

This checks extraction, not real-world truth or relevance of selected answers.
"""
import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

from render import DIMENSION_IDS, SOURCE_ID, TITLES, reject_duplicate_keys
from presentation import join_excerpts


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"),
                      object_pairs_hook=reject_duplicate_keys)


def write_json(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_answers(data):
    if not isinstance(data, dict):
        raise ValueError("answers必须是对象。")
    for key in ("profile_id", "mode", "status", "customer_type"):
        if not isinstance(data.get(key), str) or not data[key].strip():
            raise ValueError("answers缺少" + key)
    if data["mode"] not in ("real", "fictional_demo"):
        raise ValueError("mode无效。")
    if data["customer_type"] not in (*TITLES, "unknown"):
        raise ValueError("customer_type无效。")
    if data["status"] not in ("draft", "planned", "incomplete"):
        raise ValueError("status无效。")
    if type(data.get("profile_version")) is not int or data["profile_version"] < 1:
        raise ValueError("profile_version须为正整数。")
    if type(data.get("question_count")) is not int or not 0 <= data["question_count"] <= 10:
        raise ValueError("question_count须为实际0—10次发问。")
    sources = data.get("sources")
    if not isinstance(sources, list) or len(sources) > 10:
        raise ValueError("sources须为最多10条原始回答。")
    seen = set()
    for source in sources:
        if not isinstance(source, dict) or not isinstance(source.get("id"), str) or not SOURCE_ID.fullmatch(source["id"]):
            raise ValueError("回答id须为Q1—Q10。")
        if source["id"] in seen:
            raise ValueError("回答id重复。")
        seen.add(source["id"])
        if not isinstance(source.get("answer"), str) or not source["answer"].strip():
            raise ValueError("回答须为非空原文。")
        kind = "simulation" if data["mode"] == "fictional_demo" else "user_statement"
        if source.get("kind") != kind:
            raise ValueError("回答来源类型与mode不符。")
    return {s["id"]: s["answer"] for s in sources}


def segments(answer, fine=False):
    # Dimension excerpts retain comma-connected qualifiers and alternatives.
    whole = answer.strip()
    coarse = [s.strip() for s in re.split(r"[；;。！？\n]+", whole) if s.strip()]
    units = {whole, *coarse}
    # A literal complete sentence may include its original closing punctuation.
    units.update(s.strip().rstrip("；;") for s in re.findall(r"[^；;。！？\n]+[；;。！？]?", whole) if s.strip())
    if fine:
        for block in coarse:
            units.update(s.strip() for s in re.split(r"，|(?<!\d),(?!\d)", block) if s.strip())
            # Do not split ordinary lists. Only a need followed by an explicit
            # concern marker can use enumeration punctuation as a boundary.
            if re.match(r"^(?:想|希望|需要|要|反复问)", block):
                units.update(s.strip() for s in re.split(r"、(?=怕|担心|担忧|害怕)", block) if s.strip())
    return units


def literal(ref, sources, fine=False):
    if not isinstance(ref, dict) or set(ref) != {"source_id", "quote"}:
        raise ValueError("原答摘录须只含source_id和quote。")
    sid, quote = ref["source_id"], ref["quote"]
    if sid not in sources or not isinstance(quote, str) or quote not in segments(sources[sid], fine):
        raise ValueError("摘录不匹配原答完整语句：%s；不能改词、补设定或截掉同句限定。" % sid)
    return quote, sid


def context(ref, sources):
    quote, sid = literal(ref, sources, fine=True)
    blocks = [s.strip() for s in re.split(r"[；;。！？\n]+", sources[sid]) if s.strip()]
    return next((s for s in blocks if quote in s), sources[sid])


def compile_profile(plan, answers, sources, binding):
    if plan.get("schema_version") != "literal-1":
        raise ValueError("plan.schema_version须为literal-1；不接收旧自由归纳profile。")
    business, _ = literal(plan.get("business_ref"), sources)
    group, _ = literal(plan.get("group_ref"), sources)
    # Only remove a fixed grammatical introduction, never customer attributes.
    group = re.sub(r"^(?:目前主要是|现在主要是|目前主要服务的是|现在主要服务的是|目前常接的是|现在常接的是|主要是)", "", group)
    dims, unknowns = [], []
    raw_dims = plan.get("dimensions")
    if not isinstance(raw_dims, list) or [d.get("id") for d in raw_dims if isinstance(d, dict)] != DIMENSION_IDS:
        raise ValueError("六维须按固定id顺序完整选择原答。")
    titles = TITLES.get(answers["customer_type"], TITLES["individual"])
    for i, item in enumerate(raw_dims):
        refs = item.get("refs", [])
        if not isinstance(refs, list) or len(refs) > 2:
            raise ValueError("每维选择1—2条原答；无信息可明确unknown。")
        if item.get("unknown") is True:
            if refs:
                raise ValueError("unknown维度不得夹带事实摘录。")
            dims.append(dict(id=item["id"], title=titles[i], main="还不了解", detail="本次回答尚未提供这一维的信息。",
                             short=["还不了解", "还不了解"], basis="unknown", source_ids=[]))
            unknowns.append(titles[i] + "：还不了解")
            continue
        if not refs:
            raise ValueError("非unknown维度必须摘录原答。")
        quotes, ids = zip(*(literal(ref, sources) for ref in refs))
        ids = list(dict.fromkeys(ids))
        detail = join_excerpts(sources[sid] for sid in ids)
        basis = "estimate" if re.search(r"估计|印象|大概|可能|左右|约\s*\d", detail) else "reported"
        dims.append(dict(id=item["id"], title=titles[i], main=join_excerpts(quotes), detail=detail,
                         short=list(quotes) if len(quotes) == 2 else [quotes[0], "原答摘录"],
                         basis=basis, source_ids=ids))
    pairs = []
    rows = plan.get("pairs")
    if not isinstance(rows, list) or len(rows) != 10:
        raise ValueError("须有10个位置：原答/推演/未知分开。")
    previous_rank = -1
    ranks = {"reported": 0, "candidate": 1, "unknown": 2}
    for i, item in enumerate(rows, 1):
        basis = item.get("basis")
        if basis not in ranks or ranks[basis] < previous_rank:
            raise ValueError("需求顺序须原答摘录→AI推演→未知位置。")
        previous_rank = ranks[basis]
        pid = "NC%02d" % i
        if basis == "reported":
            need, ns = literal(item.get("need_ref"), sources, fine=True)
            concern, cs = literal(item.get("concern_ref"), sources, fine=True)
            if need.rstrip("。！？；;") == concern.rstrip("。！？；;"):
                raise ValueError("需求和顾虑不能是同一句；请选择各自原文，缺证时用unknown，不复制整句充当两栏。")
            pairs.append(dict(id=pid, basis=basis, need_title=need,
                              need_detail=context(item["need_ref"], sources), concern_title=concern,
                              concern_detail=context(item["concern_ref"], sources), source_ids=list(dict.fromkeys([ns, cs]))))
        elif basis == "candidate":
            fields = ("need_title", "need_detail", "concern_title", "concern_detail")
            if any(not isinstance(item.get(k), str) or not item[k].strip() for k in fields):
                raise ValueError("推演须完整说明需求、顾虑与推演依据。")
            ids = item.get("source_ids")
            if not isinstance(ids, list) or not ids or any(sid not in sources for sid in ids):
                raise ValueError("推演须指明所依据的本次回答。")
            pairs.append(dict(id=pid, basis=basis, source_ids=ids,
                              **{k: item[k] for k in fields}))
        else:
            pairs.append(dict(id=pid, basis=basis, need_title="还不了解", concern_title="还不了解",
                              need_detail="本次尚未提供，未用推测填成事实。", concern_detail="本次尚未提供，未用推测填成事实。", source_ids=[]))
            unknowns.append(pid + "需求/顾虑尚未提供")
    for ref in plan.get("unknown_refs", []):
        quote, _ = literal(ref, sources)
        unknowns.append(quote)
    prefix = "我的计划目标用户客群是" if answers["status"] == "planned" else "我的目标用户客群是"
    return dict(schema_version="1.0", extraction_contract="literal-1", source_binding=binding,
                **{k: answers[k] for k in ("profile_id", "profile_version", "mode", "status", "customer_type", "question_count", "sources")},
                business=business, group_name=group, dimensions=dims, summary=prefix + group,
                pairs=pairs, unknowns=list(dict.fromkeys(unknowns)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("answers", type=Path)
    prep.add_argument("--out", type=Path, required=True)
    run = sub.add_parser("compile")
    run.add_argument("plan", type=Path)
    run.add_argument("--job", type=Path, required=True)
    run.add_argument("--out", type=Path, required=True)
    run.add_argument("--save-downloads", action="store_true")
    run.add_argument("--downloads-dir", type=Path)
    args = parser.parse_args()
    try:
        if args.action == "prepare":
            answers = read_json(args.answers)
            check_answers(answers)
            args.out.mkdir(parents=True, exist_ok=True)
            job = args.out / "job.json"
            with job.open("x", encoding="utf-8") as stream:
                json.dump(dict(contract="literal-1", input_path=str(args.answers.resolve()),
                               input_sha256=digest(args.answers), answers=answers), stream, ensure_ascii=False, indent=2)
            print(json.dumps(dict(job=str(job), input_sha256=digest(args.answers), answers=answers), ensure_ascii=False))
            return 0
        job = read_json(args.job)
        if job.get("contract") != "literal-1" or digest(job["input_path"]) != job["input_sha256"]:
            raise ValueError("原答已改变或job无效；不得使用旧来源绑定。")
        answers = read_json(job["input_path"])
        if answers != job["answers"]:
            raise ValueError("job原答快照与实际输入不符。")
        sources = check_answers(answers)
        binding = dict(input_path=job["input_path"], input_sha256=job["input_sha256"],
                       job_path=str(args.job.resolve()), job_sha256=digest(args.job),
                       plan_path=str(args.plan.resolve()), plan_sha256=digest(args.plan))
        data = compile_profile(read_json(args.plan), answers, sources, binding)
        args.out.mkdir(parents=True, exist_ok=True)
        profile = args.out / "profile-compiled.json"
        write_json(profile, data)
        command = [sys.executable, str(Path(__file__).with_name("render.py")), str(profile), "--out", str(args.out)]
        if args.save_downloads:
            command.append("--save-downloads")
        if args.downloads_dir:
            command.extend(["--downloads-dir", str(args.downloads_dir)])
        return subprocess.run(command, check=False).returncode
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps(dict(extraction_valid=False, error=str(exc)), ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
