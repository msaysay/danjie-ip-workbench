#!/usr/bin/env python3
"""Render the fixed customer card, without network access.

HTML/JSON/SVG use the standard library. PNG uses existing Pillow and a CJK font.

Validation is structural. A passing file is not proof of customer truth,
representativeness, semantic correspondence, or model quality.
"""

import argparse
import base64
import html
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from presentation import extra_detail, pending_info


TITLE = "蛋解六维目标客群画像卡"
DIMENSION_IDS = ["basic", "family", "occupation", "spending", "housing", "habits"]
TITLES = {
    "individual": ["基本轮廓", "家庭结构", "职业身份", "收入与消费", "住房与车辆", "生活与购物"],
    "organization": ["企业类型与地区", "规模与经营阶段", "对接与决策角色", "采购预算与付款", "业务场景与条件", "寻找与采购习惯"],
}
SOURCE_ID = re.compile(r"Q(?:[1-9]|10)\Z")
UNKNOWNS = {"", "unknown", "不知道", "不清楚", "还不了解", "未提供", "未确定", "待补充", "待确认", "未知"}
ASSETS = Path(__file__).resolve().parents[1] / "assets"


def escape(value):
    return html.escape(str(value), quote=True)


def text_missing(value):
    return not isinstance(value, str) or value.strip().lower() in UNKNOWNS


def validate(data):
    errors, warnings = [], []
    if not isinstance(data, dict):
        return {"structural_valid": False, "content_ready": False, "errors": ["根对象必须是 JSON 对象。"], "warnings": [], "semantic_verified": False}

    def fail(message):
        errors.append(message)

    extraction_verified = False
    try:
        if data.get("extraction_contract") != "literal-1":
            raise ValueError("请先用compile_facts.py prepare/compile从原答摘录，不接收自由改写事实。")
        from compile_facts import read_json, digest, check_answers, compile_profile
        binding = data["source_binding"]
        if set(binding) != {"input_path", "input_sha256", "job_path", "job_sha256", "plan_path", "plan_sha256"}:
            raise ValueError("原答绑定字段不完整。")
        for kind in ("input", "job", "plan"):
            if digest(binding[kind + "_path"]) != binding[kind + "_sha256"]:
                raise ValueError(kind + "来源已改变，旧摘录不能放行。")
        answers = read_json(binding["input_path"])
        job = read_json(binding["job_path"])
        if job.get("contract") != "literal-1" or job.get("answers") != answers or job.get("input_sha256") != binding["input_sha256"] or job.get("input_path") != binding["input_path"]:
            raise ValueError("原答快照不匹配。")
        expected = compile_profile(read_json(binding["plan_path"]), answers, check_answers(answers), binding)
        if data != expected:
            raise ValueError("显示数据被独立改写；必须从本次原答和摘录计划重新编译。")
        extraction_verified = True
    except (OSError, ValueError, KeyError, TypeError) as exc:
        fail("原答摘录校验失败：" + str(exc))

    def require_text(obj, key, location, nonempty=True):
        value = obj.get(key)
        if not isinstance(value, str) or (nonempty and not value.strip()):
            fail("%s.%s 必须是%s字符串。" % (location, key, "非空" if nonempty else ""))

    for key in ("profile_id", "business", "group_name", "summary"):
        require_text(data, key, "root")
    if data.get("schema_version") != "1.0":
        fail("schema_version 必须是 1.0。")
    if type(data.get("profile_version")) is not int or data["profile_version"] < 1:
        fail("profile_version 必须是大于等于 1 的整数。")
    if data.get("mode") not in ("real", "fictional_demo"):
        fail("mode 只能是 real 或 fictional_demo。")
    if data.get("status") not in ("draft", "planned", "incomplete"):
        fail("status 只能是 draft、planned 或 incomplete。")
    if data.get("customer_type") not in ("individual", "organization", "unknown"):
        fail("customer_type 只能是 individual、organization 或 unknown。")
    count = data.get("question_count")
    if type(count) is not int or not 0 <= count <= 10:
        fail("question_count 必须是 0—10 的整数；追问也要计入。")
    if not isinstance(data.get("unknowns"), list):
        fail("unknowns 必须是数组，无缺口时用 []。")

    sources = data.get("sources")
    source_ids = set()
    if not isinstance(sources, list):
        fail("sources 必须是数组。")
        sources = []
    for index, source in enumerate(sources):
        location = "sources[%d]" % index
        if not isinstance(source, dict):
            fail(location + " 必须是对象。")
            continue
        require_text(source, "id", location)
        require_text(source, "answer", location)
        sid = source.get("id")
        if isinstance(sid, str):
            if not SOURCE_ID.fullmatch(sid):
                fail(location + ".id 必须是 Q1—Q10。")
            if sid in source_ids:
                fail("来源 ID 重复：" + sid)
            source_ids.add(sid)
        if data.get("mode") == "fictional_demo":
            if source.get("kind") != "simulation":
                fail(location + ".kind：虚构模拟必须写 simulation。")
        elif source.get("kind") != "user_statement":
            fail(location + ".kind：真实资料必须写 user_statement。")

    def check_refs(item, location, required):
        refs = item.get("source_ids")
        if not isinstance(refs, list) or any(not isinstance(s, str) for s in refs):
            fail(location + ".source_ids 必须是字符串数组。")
            return
        if required and not refs:
            fail(location + "：非 unknown 内容必须有来源题号。")
        if len(refs) != len(set(refs)):
            fail(location + "：source_ids 不应重复。")
        for sid in refs:
            if sid not in source_ids:
                fail(location + "：找不到来源 " + sid)

    dimensions = data.get("dimensions")
    if not isinstance(dimensions, list) or len(dimensions) != 6:
        fail("dimensions 必须恰好有 6 条。")
        dimensions = dimensions if isinstance(dimensions, list) else []
    actual_ids = [d.get("id") if isinstance(d, dict) else None for d in dimensions]
    if actual_ids != DIMENSION_IDS:
        fail("六维 ID 与顺序必须是：" + "、".join(DIMENSION_IDS))
    customer_type = data.get("customer_type")
    expected_titles = TITLES.get(customer_type) if isinstance(customer_type, str) else None
    unknown_dimension_count = 0
    for index, dimension in enumerate(dimensions):
        location = "dimensions[%d]" % index
        if not isinstance(dimension, dict):
            fail(location + " 必须是对象。")
            continue
        for key in ("title", "main", "detail"):
            require_text(dimension, key, location, nonempty=(key != "detail"))
        if expected_titles and index < 6 and dimension.get("title") != expected_titles[index]:
            fail(location + ".title 应为“" + expected_titles[index] + "”。")
        short = dimension.get("short")
        if not isinstance(short, list) or len(short) != 2 or any(not isinstance(line, str) or not line.strip() for line in short):
            fail(location + ".short 必须是两条非空短句的数组。")
        basis = dimension.get("basis")
        if basis not in ("reported", "estimate", "unknown"):
            fail(location + ".basis 只能是 reported、estimate 或 unknown。")
        if basis == "unknown":
            unknown_dimension_count += 1
            if not text_missing(dimension.get("main")):
                fail(location + "：unknown 的 main 应为“还不了解”等缺口文字。")
            if isinstance(short, list) and any(not text_missing(line) for line in short):
                fail(location + "：unknown 的 short 不能夹带已知画像结论。")
        check_refs(dimension, location, basis != "unknown")
        if isinstance(short, list) and any(isinstance(line, str) and len(line) > 14 for line in short):
            warnings.append(location + "：图中短句偏长，已保留全文并自动换行。")

    pairs = data.get("pairs")
    if not isinstance(pairs, list) or len(pairs) != 10:
        fail("pairs 必须恰好有 10 组；缺信息用 unknown 占位，不能编造。")
        pairs = pairs if isinstance(pairs, list) else []
    expected_pair_ids = ["NC%02d" % number for number in range(1, 11)]
    if [p.get("id") if isinstance(p, dict) else None for p in pairs] != expected_pair_ids:
        fail("需求顾虑编号必须按顺序为 NC01—NC10。")
    unknown_pair_count = 0
    for index, pair in enumerate(pairs):
        location = "pairs[%d]" % index
        if not isinstance(pair, dict):
            fail(location + " 必须是对象。")
            continue
        for key in ("need_title", "need_detail", "concern_title", "concern_detail"):
            require_text(pair, key, location)
        basis = pair.get("basis")
        if basis not in ("reported", "candidate", "unknown"):
            fail(location + ".basis 只能是 reported、candidate 或 unknown。")
        if basis == "unknown":
            unknown_pair_count += 1
            for key in ("need_title", "concern_title"):
                if not text_missing(pair.get(key)):
                    fail(location + "：unknown 的标题只能写“还不了解”等待补文字。")
        check_refs(pair, location, basis != "unknown")

    prefix = "我的计划目标用户客群是" if data.get("status") == "planned" else "我的目标用户客群是"
    if isinstance(data.get("summary"), str) and not data["summary"].startswith(prefix):
        fail("summary 必须以“" + prefix + "”开头。")
    if text_missing(data.get("business")) or text_missing(data.get("group_name")):
        if data.get("status") != "incomplete":
            fail("主营业务或目标客群还没确定时，status 必须为 incomplete。")

    blocked = []
    if text_missing(data.get("business")):
        blocked.append("主营业务还不了解")
    if text_missing(data.get("group_name")) or data.get("customer_type") == "unknown":
        blocked.append("主要客群还没确定")
    if unknown_dimension_count >= 4:
        blocked.append("超过一半六维尚未知")
    if unknown_pair_count:
        blocked.append("仍有 %d 组需求/顾虑为 unknown 占位" % unknown_pair_count)
    if data.get("status") == "incomplete":
        blocked.append("当前状态为 incomplete")
    for item in data.get("unknowns", []) if isinstance(data.get("unknowns"), list) else []:
        description = json.dumps(item, ensure_ascii=False) if not isinstance(item, str) else item
        if re.search(r"多数.*(未知|不清楚|未确认)|majority.*(unknown|unconfirmed)", description, re.I):
            blocked.append("多数客群的归纳仍未确认")
            break
    warnings.append("结构检查不核实回答真伪、客群代表性、推论准确性或10组是否语义重复；content_ready不是质量或真人验收结论。")
    if any(isinstance(p, dict) and p.get("basis") == "candidate" for p in pairs):
        warnings.append("candidate 是 AI 提出的可能需求/顾虑，仍需学员确认。")
    if data.get("status") == "planned":
        warnings.append("这是计划客群，不是现有客户多数。")
    return {
        "structural_valid": not errors,
        "content_ready": not errors and not blocked,
        "content_ready_definition": "结构完整且未触发关键缺口门槛；不代表语义正确、真实、多数成立或已获学员确认。",
        "semantic_verified": False,
        "workbuddy_tested": False,
        "hy3_tested": False,
        "checks": {"dimension_count": len(dimensions), "pair_count": len(pairs), "question_count": count, "unknown_dimensions": unknown_dimension_count, "unknown_pairs": unknown_pair_count, "descriptive_hexagon_only": True, "literal_extraction_verified": extraction_verified},
        "content_blockers": blocked,
        "errors": errors,
        "warnings": warnings,
    }


def wrap_diagram_text(value, capacity):
    """Wrap without deleting or rewriting any character or numeric qualifier."""
    lines, current, units = [], "", 0.0
    for char in value:
        if char in "WMwm@%":
            weight = 1.0
        elif char.isascii() and char.isupper():
            weight = 0.78
        else:
            weight = 0.64 if ord(char) < 128 else 1.0
        if char == "\n":
            lines.append(current)
            current, units = "", 0.0
            continue
        if current and units + weight > capacity:
            lines.append(current)
            current, units = "", 0.0
        current += char
        units += weight
    if current:
        lines.append(current)
    return lines or [""]


def diagram(data):
    # Port the user's approved desktop radial SVG. There is deliberately no
    # mobile/list variant: the whole viewBox scales in narrow WorkBuddy panels.
    axes = []
    for index, dim in enumerate(data["dimensions"]):
        capacity = 18.0 if index in (0, 3) else 9.6
        lines = [line for value in dim["short"] for line in wrap_diagram_text(value, capacity)]
        axes.append((dim, lines))
    top_extra = max(0, len(axes[0][1]) - 2) * 32
    side_rows = max(len(axes[i][1]) for i in (1, 2, 4, 5))
    side_extra = max(0, side_rows - 4) * 32
    center_y = 320 + top_extra + side_extra / 2
    points = [(500, 150 + top_extra), (647, 235 + top_extra),
              (647, 405 + top_extra + side_extra),
              (500, 490 + top_extra + side_extra),
              (353, 405 + top_extra + side_extra), (353, 235 + top_extra)]
    bottom_y = 558 + top_extra + side_extra
    canvas_height = bottom_y + 36 + (len(axes[3][1]) - 1) * 32 + 34
    canvas_height = max(660 + top_extra + side_extra, canvas_height)
    polygon = " ".join("%s,%s" % point for point in points)
    spokes = "".join('<line x1="500" y1="%s" x2="%s" y2="%s"/>' % (center_y, x, y) for x, y in points)
    nodes = "".join('<circle cx="%s" cy="%s" r="5" fill="#eacf79"/>' % point for point in points)
    connectors = "".join('<line x1="%s" y1="%s" x2="%s" y2="%s"/>' % (x, y, tx, y)
                         for x, y, tx in [(353, points[1][1], 275), (647, points[1][1], 725),
                                          (353, points[2][1], 275), (647, points[2][1], 725)])
    placements = [(500, 37, "middle"), (752, 200 + top_extra, "start"),
                  (752, 370 + top_extra + side_extra, "start"), (500, bottom_y, "middle"),
                  (248, 370 + top_extra + side_extra, "end"), (248, 200 + top_extra, "end")]
    labels = []
    for index, ((dim, lines), (x, y, anchor)) in enumerate(zip(axes, placements)):
        values = "".join('<text class="model-value" x="%s" y="%s" text-anchor="%s">%s</text>' %
                         (x, y + 36 + n * 32, anchor, escape(line)) for n, line in enumerate(lines))
        labels.append('<g class="model-axis axis-%d" data-axis="%s"><text class="model-label" x="%s" y="%s" text-anchor="%s">%s</text>%s</g>' %
                      (index + 1, escape(dim["id"]), x, y, anchor, escape(dim["title"]), values))
    # Fit the literal center phrase; never shorten its content or add claims.
    center_font = 27
    center_lines = wrap_diagram_text(data["group_name"], 6.8)
    while len(center_lines) * (center_font + 9) > 122 and center_font > 14:
        center_font -= 1
        center_lines = wrap_diagram_text(data["group_name"], 180 / center_font)
    line_height = center_font + 9
    first_line_y = center_y + 1 - (len(center_lines) - 2) * line_height / 2
    kicker_y = first_line_y - 42
    center_text = "".join('<text class="model-center-text" style="font-size:%spx" x="500" y="%s" text-anchor="middle">%s</text>' %
                          (center_font, first_line_y + n * line_height, escape(line)) for n, line in enumerate(center_lines))
    hub = '<g class="model-hub"><circle cx="500" cy="%s" r="100" fill="#111914" stroke="#9a8047" stroke-width="1.2"/><text class="model-center-kicker" x="500" y="%s" text-anchor="middle">我的目标客群</text>%s</g>' % (center_y, kicker_y, center_text)
    description = "；".join(dim["title"] + "：" + "，".join(dim["short"]) for dim in data["dimensions"])
    svg = ('<svg class="model-radial" viewBox="0 0 1000 %s" role="img" aria-label="六维目标客群描述图，不打分"><title>六维画像，一眼看清</title><desc>%s。六项说明始终围绕中心，不是评分图。</desc><polygon class="model-outer" points="%s"/><g class="model-structure" opacity=".5">%s</g><g class="model-structure">%s</g>%s%s%s</svg>' %
           (canvas_height, escape(description), polygon, spokes, connectors, hub, nodes, "".join(labels)))
    return '<figure class="profile-model" id="profile-model"><h3>六维画像，一眼看清</h3><div class="model-map">%s</div><figcaption class="model-summary"><span>一句话画像</span>%s</figcaption></figure>' % (svg, escape(data["summary"]))


def render_html(data, report):
    css = (ASSETS / "style.css").read_text(encoding="utf-8")
    texture = ASSETS / "texture.png"
    if texture.is_file():
        encoded = base64.b64encode(texture.read_bytes()).decode("ascii")
        css = css.replace("__TEXTURE__", "data:image/png;base64," + encoded)
    else:
        raise FileNotFoundError("缺少本 Skill 的 assets/texture.png；不应静默更换模板。")
    label = "虚构案例" if data["mode"] == "fictional_demo" else {"draft": "待本人核对", "planned": "计划客群", "incomplete": "资料待补"}[data["status"]]
    top = '<div class="top"><span class="brand">蛋解课堂</span><span class="tag">%s</span></div>' % escape(label)
    dim_html = []
    for index, dim in enumerate(data["dimensions"]):
        detail = extra_detail(dim)
        detail_html = '<p>%s</p>' % escape(detail) if detail else ''
        dim_html.append('<article class="dimension" data-dimension="%s"><h3><i>%02d</i>%s</h3><div class="main">%s</div>%s</article>' % (escape(dim["id"]), index + 1, escape(dim["title"]), escape(dim["main"]), detail_html))
    needs, concerns = {k: [] for k in ("reported", "candidate", "unknown")}, {k: [] for k in ("reported", "candidate", "unknown")}
    for index, pair in enumerate(data["pairs"]):
        if pair["basis"] == "unknown":
            continue
        badge = {"reported": "回答中提到", "candidate": "AI推演 · 待确认", "unknown": "还不了解"}[pair["basis"]]
        needs[pair["basis"]].append('<article class="item" data-pair="%s"><span class="no">%02d</span><div><h3>%s</h3><p>%s</p><span class="basis-tag">%s</span></div></article>' % (escape(pair["id"]), index + 1, escape(pair["need_title"]), escape(pair["need_detail"]), escape(badge)))
        concerns[pair["basis"]].append('<article class="item" data-pair="%s"><span class="no">%02d</span><div><h3>%s</h3><p>%s</p><div class="ref">对应 %02d｜%s</div><span class="basis-tag">%s</span></div></article>' % (escape(pair["id"]), index + 1, escape(pair["concern_title"]), escape(pair["concern_detail"]), index + 1, escape(pair["need_title"]), escape(badge)))
    def sections(groups, kind):
        # Restore the original single two-column grid: ten cards, not 4+6 sections.
        items=''.join(''.join(groups[k]) for k in ('reported','candidate'))
        return '<div class="items %s">%s</div>' % (kind, items)
    pending = pending_info(data)
    pending_html = ''
    if pending:
        items = '<ul>%s</ul>' % ''.join('<li>%s</li>' % escape(item) for item in pending["items"]) if pending["items"] else ''
        pending_html = '<aside class="pending-info" id="pending-info"><h3>%s</h3><p>%s</p>%s<p class="supplement-instruction">%s</p><p class="pending-note">%s</p></aside>' % (escape(pending["title"]), escape(pending["summary"]), items, escape(pending["prompt"]), escape(pending["note"]))
    incomplete_note = '<p class="front-note">这张卡还有待补信息，已合并列在卡片末尾，可以以后在聊天里补齐。</p>' if not report["content_ready"] else ''
    body = '<main class="report" id="complete-result"><section class="page" id="part-1">%s<h1 class="card-title">%s</h1><p class="card-subtitle">看清客户是谁、想要什么、担心什么。</p><div class="heading"><h2>01 客户是谁</h2><span class="part-number">01 / 03</span></div>%s<div class="six">%s</div>%s</section><section class="page" id="part-2">%s<div class="heading"><h2>02 客户想要什么</h2><span class="part-number">02 / 03</span></div><p class="candidate">原答摘录与AI推演分区展示；推演仍要和客户确认。</p>%s</section><section class="page" id="part-3">%s<div class="heading"><h2>03 客户担心什么</h2><span class="part-number">03 / 03</span></div><p class="candidate">和上面的需求按编号对应；推测的担心，不当成客户原话或你的服务承诺。</p>%s</section></main>' % (top, TITLE, incomplete_note, "".join(dim_html), diagram(data), top, sections(needs, "needs"), top, sections(concerns, "concerns"))
    body = body.replace('</section></main>', pending_html + '</section></main>')
    body = body.replace('原答摘录与AI推演分区展示；推演仍要和客户确认。', '结合画像与购买场景整理；回答中提到的与AI推演分别标注，推演仍需确认。')
    policy = "default-src 'none'; img-src data:; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"
    return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="%s"><title>%s</title><style>%s</style></head><body>%s</body></html>' % (escape(policy), TITLE, css, body)


def md_text(value):
    # Escape raw HTML, including script tags, in Markdown-targeted text too.
    return html.escape(str(value), quote=False).replace("|", "\\|").replace("\r", "").replace("\n", "<br>")


def render_markdown(data, report):
    lines = ["# " + TITLE, "", "虚构案例" if data["mode"] == "fictional_demo" else "待本人核对", "", "## 01 客户是谁", ""]
    for dim in data["dimensions"]:
        lines += ["### " + md_text(dim["title"]), "", md_text(dim["main"]), ""]
        if extra_detail(dim):
            lines += [md_text(extra_detail(dim)), ""]
        lines += ["依据：%s；来源：%s" % (dim["basis"], ", ".join(dim["source_ids"]) or "无，待补"), ""]
    lines += ["### 六维画像，一眼看清", ""]
    lines += ["- %s：%s" % (md_text(dim["title"]), "；".join(md_text(line) for line in dim["short"])) for dim in data["dimensions"]]
    lines += ["", "一句话画像：" + md_text(data["summary"]), "", "## 02 客户想要什么", ""]
    for pair in data["pairs"]:
        if pair["basis"] == "unknown":
            continue
        lines += ["### %s %s" % (pair["id"], md_text(pair["need_title"])), "", md_text(pair["need_detail"]), "", "依据：%s；来源：%s" % (pair["basis"], ", ".join(pair["source_ids"]) or "无，待补"), ""]
    lines += ["## 03 客户担心什么", ""]
    for pair in data["pairs"]:
        if pair["basis"] == "unknown":
            continue
        lines += ["### %s %s" % (pair["id"], md_text(pair["concern_title"])), "", md_text(pair["concern_detail"]), "", "对应需求：" + md_text(pair["need_title"]), ""]
    pending = pending_info(data)
    if pending:
        lines += ["## " + pending["title"], "", md_text(pending["summary"]), ""]
        lines += ["- " + md_text(item) for item in pending["items"]]
        lines += ["", md_text(pending["prompt"]), "", md_text(pending["note"]), ""]
    lines += ["## 原始回答与来源", ""]
    for source in data["sources"]:
        lines += ["### " + md_text(source["id"]), "", md_text(source["answer"]), "", "来源类型：" + md_text(source["kind"]), ""]
    lines += ["", "结构校验：通过；内容关键缺口门槛：" + ("未触发" if report["content_ready"] else "未满足"), "", "结构检查不代表内容真实、语义准确、多数成立或已在 WorkBuddy / HY3 验收。", ""]
    return "\n".join(lines)


def dump_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("JSON 键重复：" + key)
        result[key] = value
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description="生成固定黑金三部分六维目标客群卡；只做结构校验，不核实事实。")
    parser.add_argument("profile", type=Path, help="profile.json 路径")
    parser.add_argument("--out", type=Path, default=Path("result"), help="输出目录，默认 result")
    parser.add_argument("--font", type=Path, default=None, help="可选：PNG导出使用的本机中文字体")
    parser.add_argument("--save-downloads", action="store_true", help="另存PNG到电脑下载目录，不覆盖已有文件")
    parser.add_argument("--downloads-dir", type=Path, default=None, help="显式指定下载目录；须与--save-downloads同时使用")
    args = parser.parse_args(argv)
    args.out.mkdir(parents=True, exist_ok=True)
    validation_path = args.out / "validation.json"
    try:
        data = json.loads(args.profile.read_text(encoding="utf-8-sig"), object_pairs_hook=reject_duplicate_keys, parse_constant=lambda value: (_ for _ in ()).throw(ValueError("不允许非标准 JSON 数值：" + value)))
        report = validate(data)
    except (OSError, UnicodeError, ValueError) as exc:
        report = {"structural_valid": False, "content_ready": False, "semantic_verified": False, "errors": ["无法读取有效 profile.json：" + str(exc)], "warnings": []}
        dump_json(validation_path, report)
        print(json.dumps(report, ensure_ascii=False), file=sys.stderr)
        return 2
    dump_json(validation_path, report)
    if not report["structural_valid"]:
        print(json.dumps(report, ensure_ascii=False), file=sys.stderr)
        return 2
    try:
        rendered = render_html(data, report)
        markdown = render_markdown(data, report)
    except (OSError, UnicodeError) as exc:
        report["structural_valid"] = False
        report["content_ready"] = False
        report["errors"].append("渲染资源错误：" + str(exc))
        dump_json(validation_path, report)
        print(json.dumps(report, ensure_ascii=False), file=sys.stderr)
        return 3
    stem = args.out / TITLE
    from long_image import export_long_image
    image_report = export_long_image(data, diagram(data), args.out, TITLE, str(args.font) if args.font else None)
    if args.save_downloads and image_report["png_ready"]:
        try:
            destination_dir = args.downloads_dir or (Path.home() / "Downloads")
            if not destination_dir.is_dir():
                raise OSError("未找到下载目录；请指定现有的--downloads-dir，不猜目录或假装已保存。")
            png_source = Path(image_report["png"])
            base_name = TITLE + "-完整长图-" + datetime.now().strftime("%Y%m%d-%H%M%S")
            destination = destination_dir / (base_name + ".png")
            sequence = 2
            while destination.exists():
                destination = destination_dir / (base_name + "-" + str(sequence) + ".png")
                sequence += 1
            # Exclusive create avoids overwriting a pre-existing file, including races.
            with png_source.open("rb") as source_file, destination.open("xb") as destination_file:
                shutil.copyfileobj(source_file, destination_file)
            if destination.read_bytes() != png_source.read_bytes():
                raise OSError("下载副本字节核对失败，不能称已保存。")
            image_report["saved_download"] = str(destination.resolve())
            image_report["download_saved"] = True
        except OSError as exc:
            image_report["download_saved"] = False
            image_report["download_error"] = str(exc)
    report["long_image"] = image_report
    report["dual_format_complete"] = image_report["png_ready"]
    dump_json(validation_path, report)
    if image_report["png_ready"]:
        if image_report.get("download_saved"):
            image_notice = '完整PNG长图已保存到电脑的“下载”文件夹：' + escape(Path(image_report["saved_download"]).name)
        else:
            image_notice = '完整PNG长图已另行生成。请打开WorkBuddy产物中的PNG附件；本网页不提供内嵌下载按钮。'
        notice = '<div class="image-export-note" style="max-width:1280px;margin:0 auto;padding:18px 24px;color:#eacf79;font-size:16px">%s</div>' % image_notice
        rendered = rendered.replace('<body>', '<body>' + notice)
    stem.with_suffix(".html").write_text(rendered, encoding="utf-8")
    stem.with_suffix(".md").write_text(markdown, encoding="utf-8")
    dump_json(stem.with_suffix(".json"), data)
    print(json.dumps({"structural_valid": True, "content_ready": report["content_ready"], "html": str(stem.with_suffix(".html")), "png": image_report.get("png"), "png_ready": image_report["png_ready"], "saved_download": image_report.get("saved_download"), "download_error": image_report.get("download_error"), "png_error": image_report.get("png_error"), "markdown": str(stem.with_suffix(".md")), "json": str(stem.with_suffix(".json")), "validation": str(validation_path)}, ensure_ascii=False))
    if not image_report["png_ready"]:
        return 4
    return 5 if args.save_downloads and not image_report.get("download_saved") else 0


if __name__ == "__main__":
    sys.exit(main())
