"""Shared presentation rules. Source answers and the ten paired slots stay intact."""
import re


SUPPLEMENT_PROMPT = (
    "想补齐这一块，可以回到聊天说：我想补充这张客群卡。"
    "再告诉我：客户还想解决什么、还担心什么，以及你新了解的情况。"
    "有多少说多少，不知道的继续留空。"
)


def join_excerpts(values):
    """Join complete quotes without the awkward full-stop/semicolon combination."""
    result = ""
    for value in values:
        if result and not result.endswith(("。", "！", "？", ";", "；", "\n")):
            result += "；"
        result += value
    return result


def extra_detail(item):
    """Hide an identical duplicate only; retain all additional source context."""
    normalize = lambda value: re.sub(r"\s+", "", value).rstrip("。；;")
    detail = item.get("detail", "")
    return "" if normalize(item["main"]) == normalize(detail) else detail


def pending_info(data):
    counts = {basis: sum(p["basis"] == basis for p in data["pairs"])
              for basis in ("reported", "candidate", "unknown")}
    # NC05...NC10 remain in JSON for downstream consumers, not six empty tiles.
    items = list(dict.fromkeys(
        item for item in data["unknowns"]
        if not re.fullmatch(r"NC\d{2}需求/顾虑尚未提供", item)
    ))
    if not counts["unknown"] and not items:
        return None
    if counts['unknown']:
        title="待补充的信息"
        summary = ("目标：10个需求＋10个担忧，一一对应。当前原答提到%d组，"
                   "AI推演待确认%d组，尚缺%d组。" %
                   (counts["reported"], counts["candidate"], counts["unknown"]))
    else:
        title="尚不了解的客群信息"
        summary=("上方已列出10个需求和10个担忧：%d组由原答提到，%d组为AI推演、待你确认。"
                 "下面是尚未了解的客群背景，不是把需求数量减掉。" %
                 (counts['reported'], counts['candidate']))
    return dict(title=title, summary=summary, items=items,
                prompt=SUPPLEMENT_PROMPT,
                note="AI推演是可能的关注点，不代表客户原话、已验证多数或商家的服务承诺。")
