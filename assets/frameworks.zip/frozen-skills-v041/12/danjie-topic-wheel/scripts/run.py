import argparse, base64, hashlib, itertools, json, pathlib, re, zipfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
AXES=['identity','customer','judgment','relationship','evidence','action']
INTERESTS=['钱','时间','效果','风险','体验','关系']
QUESTIONS=['怎么选','为什么','怎么解决','拆误区','何时不适合','两者哪个好']
def read_persona(path):
    p=pathlib.Path(path).resolve(); raw=p.read_bytes(); data=json.loads(raw)
    assert [d['id'] for d in data.get('dimensions',[])]==AXES, '需要新版六维人设卡，不接受旧客群卡'
    assert data.get('persona_id') and data.get('persona_version') is not None, '缺少人设标识或版本'
    assert all(d.get('main') for d in data['dimensions']), '六维内容缺失'
    return data,hashlib.sha256(raw).hexdigest(),str(p)

def quote_refs(persona, refs, minimum=1):
    assert isinstance(refs,list) and len(refs)>=minimum and len(set(refs))==len(refs), '请给完整原卡字段指针，不自写引文'
    quotes=[]
    for ref in refs:
        assert isinstance(ref,str) and re.fullmatch(r'/(sources/\d+/answer|dimensions/\d+/main)',ref), '引文仅允许完整原答answer或维度main'
        collection,index,_=ref.split('/')[1:]
        row=persona[collection][int(index)]
        assert row.get('restricted') is not True, '受限原答或维度不可进入公开引文'
        if collection=='dimensions':
            by_id={s.get('id'):s for s in persona.get('sources',[])}
            assert not any(by_id.get(i,{}).get('restricted') is True for i in row.get('source_ids',[])), '维度关联受限原答，不可借维度摘要绕开权限'
        value=persona
        for key in ref.split('/')[1:]:
            value=value[int(key)] if isinstance(value,list) else value[key]
        assert isinstance(value,str) and value.strip(), '引文字段不存在或为空'
        quotes.append({'pointer':ref,'quote':value})
    return quotes

def export(persona,plan,out):
    p,sha,src=read_persona(persona); m=json.loads(pathlib.Path(plan).read_text())
    assert m['source_sha256']==sha, '源卡已经改变，请重读'
    assert m['persona_id']==p['persona_id'] and m['persona_version']==p['persona_version'], '人设绑定错误'
    assert m['center'] and m['audience']
    assert 'basis' not in m, '不接受自由改写的依据，使用basis_refs'
    m['basis_quotes']=quote_refs(p,m['basis_refs'],3)
    assert isinstance(m.get('topic_scope'),dict) and all(isinstance(m['topic_scope'].get(k),str) and m['topic_scope'][k].strip() for k in ['subject','beneficiary','decision']), '请先锁定同一问题的决策者、使用者与核心判断'
    assert len(m['center_short'].splitlines())<=2 and all(len(s)<=8 for s in m['center_short'].splitlines()), '中心短标题超长'
    assert len(m['scenes'])==6 and len({s['label'] for s in m['scenes']})==6
    for s in m['scenes']:
        assert 0<len(s['label'])<=6 and isinstance(s.get('hypothesis'),str) and s['hypothesis'].strip()
        assert 'basis' not in s, '假设条件与原卡引文须分开'
        s['kind']='hypothesis'
        s['source_quotes']=quote_refs(p,s['source_refs'],0)
    assert len(m['topics'])==216, '必须覆盖216组合'
    got=set(); titles=set()
    for t in m['topics']:
        k=tuple(t['selection']); assert len(k)==3 and all(type(x)==int and 0<=x<6 for x in k) and k not in got
        axes=t.get('axes',{})
        assert axes=={'interest':INTERESTS[k[0]],'question':QUESTIONS[k[1]],'scene':m['scenes'][k[2]]['label']}, 'selection必须按[利益,问法,情境]排列，并与axes三个原标签完全对应'
        assert all(isinstance(t.get(v),str) and t[v].strip() for v in ['topic','gap'])
        assert 'reason' not in t, '不能自写事实依据，使用reason_refs'
        t['reason_quotes']=quote_refs(p,t['reason_refs'])
        t['status']='candidate_question_not_verified'
        assert len(t['topic'])<=140, '选题过长'
        assert t['topic'] not in titles, '存在完全重复选题'
        titles.add(t['topic']); got.add(k)
    assert got==set(itertools.product(range(6),repeat=3))
    m['source_path']=src; m['source_mode']=p.get('mode','unknown')
    m['version']='0.1.6'; m['status']='candidate_questions_with_hypotheses'
    m['id']=hashlib.sha256(json.dumps(m,ensure_ascii=False,sort_keys=True).encode()).hexdigest()[:16]
    m['topics'].sort(key=lambda t:t['selection'])
    raw=json.dumps(m,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    texture='data:image/jpeg;base64,'+base64.b64encode((ROOT/'assets/texture.jpg').read_bytes()).decode()
    fragment=(ROOT/'assets/wheel.html').read_text().replace('__ROOT__','danjie-wheel-'+m['id']).replace('__DATA__',raw).replace('__TEXTURE__',texture)
    out=pathlib.Path(out).resolve(); assert not out.exists(), '保留已有结果，另用新的结果目录'; out.mkdir(parents=True)
    (out/'fragment.html').write_text(fragment)
    html='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>蛋解一题多讲大转盘</title><style>body{margin:0;background:#101010;padding:12px}</style></head><body>'+fragment+'</body></html>'
    (out/'蛋解一题多讲大转盘.html').write_text(html)
    (out/'wheel.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
    (out/'来源回执.json').write_text(json.dumps({'persona_id':p['persona_id'],'persona_version':p['persona_version'],'source_path':src,'source_sha256':sha,'mode':p.get('mode'),'combinations':216,'evidence':'full_source_fields_resolved_verbatim','scenes':'explicit_hypotheses_not_events','topics':'candidate_questions_not_verified','native_client_verified':False},ensure_ascii=False,indent=2))
    with zipfile.ZipFile(out/'大转盘结果包.zip','w',zipfile.ZIP_DEFLATED) as z:
        for n in ['蛋解一题多讲大转盘.html','wheel.json','来源回执.json']: z.write(out/n,n)
    print(json.dumps({'html':str(out/'蛋解一题多讲大转盘.html'),'combinations':216,'source_sha256':sha},ensure_ascii=False))

if __name__=='__main__':
    a=argparse.ArgumentParser(); a.add_argument('command',choices=['prepare','export']); a.add_argument('--persona',required=True); a.add_argument('--plan'); a.add_argument('--out',required=True); args=a.parse_args()
    if args.command=='prepare':
        p,sha,src=read_persona(args.persona); out=pathlib.Path(args.out); out.mkdir(parents=True,exist_ok=True)
        (out/'persona-read.json').write_text(json.dumps({'source_path':src,'source_sha256':sha,'persona':p},ensure_ascii=False,indent=2)); print(str(out/'persona-read.json'))
    else: export(args.persona,args.plan,args.out)
