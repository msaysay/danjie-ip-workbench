# 绝活卡输出契约

```json
{
  "schema_version": "0.2",
  "source_refs": {"customer_card": "", "three_circle_card": "", "opening_card": "", "evidence_card": ""},
  "topic_ref": {"topic_id": "", "viewpoint_id": ""},
  "mode": "real|fictional_demo",
  "status": "confirmed|draft|missing_core_fact",
  "identity": "",
  "audience": "",
  "problem": "",
  "scale_statement": "",
  "result_statement": "",
  "evidence_statement": "",
  "facts": [
    {
      "kind": "identity|audience|problem|scale|result|evidence|boundary",
      "raw_statement": "",
      "normalized_statement": "",
      "actor": "self|team|customer|unknown",
      "time_scope": "",
      "object_scope": "",
      "source": "",
      "evidence_status": "self_reported|record_seen|independently_verified|pending",
      "public_scope": "public|anonymous|internal|unknown"
    }
  ],
  "hero_sentence": "",
  "necessary_note": "",
  "unused_materials": [],
  "gaps": [],
  "forbidden_inferences": []
}
```

`hero_sentence`只可使用身份、对象与问题、规模、结果及`facts`中对应表述和必要连接词，不纳入`evidence_statement`中的材料展示解释。`evidence_statement`与证据facts仍保留后台，不因主句精简而删除。身份来自本轮第1题，客群与问题来自目标客群卡，肌肉数字、结果和展示材料来自后四题。所有数字默认标记`self_reported`，不宣称独立核验；AI不得创造数字，也不得把学员原话中的“团队、参与、反馈”升级成本人独立成果。具体客户反馈是结果，可以保留；“邮件可展示”是证明方式，不进入主句。
