#!/usr/bin/env python3
"""Render a standalone 蛋解亮出绝活 HTML card from a small JSON model."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
from pathlib import Path


def validate_hero(text: str) -> None:
    # Reject known backstage/process leakage; never silently rewrite a learner's claim.
    process = r"self_reported|fictional_demo|(?:本轮|本次).{0,16}(?:上传|待核|核验|自述|演练)|未独立核验|尚未上传|上传待核|本人自述|无前后效率统计|单户个人感受|不代表(?:全部|所有)客户"
    privacy_list = r"(?:[，,；;（(]|^)(?:客户|企业|联系人)[^。；;\n]{0,45}不公开"
    evidence_aside = r"(?:交接(?:单|清单)|邮件|合同|证明材料|证据|记录)[^。；;\n]{0,32}(?:可以|能够|可供|可)(?:对应)?(?:展示|核对|证明)|能对应.{0,12}结果的证据是"
    if re.search(process, text, re.I) or re.search(privacy_list, text) or re.search(evidence_aside, text):
        raise SystemExit(
            "hero_sentence含后台核验、保密或证据展示说明，请移到note和后台；只重拟主句后正常重导，"
            "保留约数、团队/本人参与、单例反馈等必要事实关系，不要绕过或手改成品。"
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    skill_root = Path(__file__).resolve().parents[1]
    template = (skill_root / "assets" / "template.html").read_text(encoding="utf-8")
    texture = base64.b64encode((skill_root / "assets" / "texture.png").read_bytes()).decode("ascii")
    model = json.loads(args.model.read_text(encoding="utf-8"))
    required = ["mode", "hero_sentence", "note"]
    if not isinstance(model, dict):
        raise SystemExit("model must be a JSON object")
    missing = [key for key in required if key not in model]
    if missing:
        raise SystemExit("missing fields: " + ", ".join(missing))
    if model["mode"] not in ("real", "fictional_demo"):
        raise SystemExit("mode must be real or fictional_demo")
    if not isinstance(model["hero_sentence"], str) or not model["hero_sentence"].strip():
        raise SystemExit("hero_sentence must be a non-empty string")
    validate_hero(model["hero_sentence"])
    if not isinstance(model["note"], str):
        raise SystemExit("note must be a string")
    if args.output.suffix.lower() != ".html":
        raise SystemExit("output must end with .html")
    text_path = args.output.with_suffix(".txt")
    model["text_file_name"] = text_path.name

    html = template.replace("__TEXTURE_BASE64__", texture)
    html = html.replace("__MODEL_JSON__", json.dumps(model, ensure_ascii=False).replace("</", "<\\/"))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(html, encoding="utf-8")
    text_path.write_text(model["hero_sentence"] + "\n", encoding="utf-8")
    receipt = {
        "skill_version": "0.3.8",
        "mode": model["mode"],
        "files": [
            {"name": p.name, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in (args.output, text_path)
        ],
        "client_saved": "not_verified_by_renderer",
    }
    args.output.with_suffix(".delivery.json").write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({"html": str(args.output), "text": str(text_path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
