# -*- coding: utf-8 -*-
"""Read profile FIRST and selected opening SECOND. No AI/business authorship."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

LABELS=dict(event='有事为证',numbers='有数为证',comparison='有对比为证',research='有研究为证')
FIELDS=('text','source_ids','reasoning','countercheck','support_assessment')
sha=lambda b:hashlib.sha256(b).hexdigest()


def profile_text(path,raw):
    if path.suffix.lower()=='.docx':
        with zipfile.ZipFile(path) as z:xml=ET.fromstring(z.read('word/document.xml'))
        ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
        return '\n'.join(''.join(t.text or '' for t in p.iter(ns+'t')) for p in xml.iter(ns+'p'))
    return raw.decode('utf-8-sig')


def prepare(profile,hook,out):
    profile,hook,out=Path(profile),Path(hook),Path(out)
    if out.exists() and any(out.iterdir()):raise ValueError('stage目录已有文件，请另建新目录，不覆盖')
    # Deliberately finish first-card reading before opening the second file.
    raw1=profile.read_bytes();text1=profile_text(profile,raw1)
    if not text1.strip():raise ValueError('目标客群卡为空')
    first=dict(kind='profile',path=str(profile.resolve()),sha256=sha(raw1))
    raw2=hook.read_bytes();card=json.loads(raw2.decode('utf-8-sig'))
    if card.get('card_type')!='danjie-opening-selection':raise ValueError('请先从实际当头一棒卡映射已选字段，不能只传一句新观点')
    ref=card.get('profile_ref') or {};s=card.get('selected') or {}
    if ref.get('card_sha256')!=first['sha256']:raise ValueError('两卡不匹配：当头一棒关联的客群原件不是本次这张')
    if not isinstance(ref.get('id'),str) or not ref['id'].strip() or type(ref.get('version')) is not int or ref['version']<1:raise ValueError('缺客群ID或有效版本')
    if any(not isinstance(s.get(k),str) or not s[k].strip() for k in ('topic_id','question','method','viewpoint_id','viewpoint','old_cognition','customer_task')):raise ValueError('当头一棒尚未选定具体观点或缺原卡字段，先确认，不代写')
    if s['method'] not in ('necessary_condition','selection_standard','result_direction'):raise ValueError('反转方式无效')
    if card.get('owner_confirmed') is not True:raise ValueError('当头一棒尚未确认采用，请先选定并确认一句观点')
    if card.get('mode') not in ('real','fictional_demo'):raise ValueError('保留真实/模拟边界')
    for k in ('business_offer','customer_role','selection_origin'):
        if not isinstance(card.get(k),str) or not card[k].strip():raise ValueError('缺原卡字段：'+k)
    second=dict(kind='hook',path=str(hook.resolve()),sha256=sha(raw2))
    chain=dict(read_order=['profile','hook'],profile=first,hook=second,profile_id=ref['id'],profile_version=ref['version'],topic_id=s['topic_id'],viewpoint_id=s['viewpoint_id'],viewpoint=s['viewpoint'])
    ctx='ctx-'+sha(raw1)[:16];wid='wf-proof-'+sha(raw1+raw2)[:16]
    bind=dict(context_id=ctx,context_version=1,profile_id=ref['id'],profile_version=ref['version'],topic_id=s['topic_id'],viewpoint_id=s['viewpoint_id'],viewpoint=s['viewpoint'],method=s['method'])
    hook_card=dict(id='hook-'+s['viewpoint_id'],version=1,binding=copy.deepcopy(bind),text=s['viewpoint'],source_ids=['input-hook'],stance_confirmed=card['owner_confirmed'])
    variants=[dict(id=k,label=v,evidence_kind=k,support_assessment='unsupported',text='【待补：尚未查找该类原始材料】',source_ids=[],reasoning=[],countercheck='尚未检索',gaps=['尚未查找该类原始材料']) for k,v in LABELS.items()]
    proof=dict(id='proof-'+s['viewpoint_id'],version=1,binding=copy.deepcopy(bind),stance_confirmed=card['owner_confirmed'],method_revision='0.4.3',selected_variant='event',variants=variants)
    proof.update({k:copy.deepcopy(variants[0][k]) for k in FIELDS})
    project=dict(schema_version=1,skill_version='0.3.3',workflow_id=wid,context_id=ctx,context_version=1,mode=card['mode'],status='draft',business=dict(offer=card['business_offer'],target_roles=[card['customer_role']],exclusions='',service_scope=card['business_offer']),profile=dict(id=ref['id'],version=ref['version'],label=ref.get('label','目标客群'),customer_role=card['customer_role'],roles={},traits=[]),needs=[],concerns=[],service_matches=[],topics=[dict(id=s['topic_id'],question=s['question'],customer_role=card['customer_role'],task=s['customer_task'],source_ids=['input-profile','input-hook'],concern_ids=[],need_ids=[],status='selected',approaches=[dict(method=s['method'],old_cognition=s['old_cognition'],old_cognition_source_ids=['input-hook'],statement=s['viewpoint'],viewpoint_id=s['viewpoint_id'],status='selected')])],selection=dict(topic_id=s['topic_id'],method=s['method'],viewpoint_id=s['viewpoint_id'],viewpoint=s['viewpoint'],customer_task=s['customer_task']),cards=dict(hook=hook_card,proof=proof,ability=None,guide=None),sources=[dict(id='input-profile',origin='document',reference=first['path'],summary='本次客群原卡，仅业务背景，非观点效果证据',review_status='opened',publicity='internal'),dict(id='input-hook',origin='document',reference=second['path'],summary='本次当头一棒已选原句；选择来源：'+card['selection_origin'],review_status='opened',publicity='internal')],state=dict(current_stage='proof',question_counts=dict(profile=0,hook=0,proof=0,ability=0,guide=0),pending_question=None,completed=['profile','hook']),owner_review=dict(confirmed=False,source_id=None),pending_items=[],history=[],script=None,input_chain=chain)
    receipt=dict(input_chain=chain,profile_original_text=text1,opening_selection=card,note='仅生成两卡承接种子，不是研究成果；确认不由脚本补齐')
    out.mkdir(parents=True,exist_ok=True)
    for name,value in [('project.json',project),('input-receipt.json',receipt)]:
        (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    return dict(read_order=chain['read_order'],profile_id=ref['id'],viewpoint=s['viewpoint'],project=str(out/'project.json'))


def validate_chain(data):
    c=data.get('input_chain') or {};pf=data.get('profile') or {};s=data.get('selection') or {}
    if ((data.get('cards') or {}).get('hook') or {}).get('stance_confirmed') is not True:raise ValueError('当头一棒尚未确认采用，不能导出写作建议')
    if c.get('read_order')!=['profile','hook']:raise ValueError('缺先客群后当头一棒的读取记录')
    for kind in ('profile','hook'):
        item=c.get(kind) or {};h=item.get('sha256','')
        if item.get('kind')!=kind or not item.get('path') or len(h)!=64 or any(ch not in '0123456789abcdef' for ch in h):raise ValueError('两卡原件记录不完整：'+kind)
    if any(c.get(k)!=pf.get(v) for k,v in [('profile_id','id'),('profile_version','version')]):raise ValueError('结果换了客群或版本')
    if any(c.get(k)!=s.get(k) for k in ('topic_id','viewpoint_id','viewpoint')):raise ValueError('结果换了当头一棒中的选定原句')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for flag in ('profile','hook','out'):parser.add_argument('--'+flag,required=True,type=Path)
    args=parser.parse_args()
    try:print(json.dumps(prepare(args.profile,args.hook,args.out),ensure_ascii=False))
    except (ValueError,OSError,KeyError,TypeError) as e:parser.exit(2,str(e)+'\n')
