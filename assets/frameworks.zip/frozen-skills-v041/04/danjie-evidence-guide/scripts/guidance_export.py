#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Export guidance, not four finished speeches. No network/model calls."""
import argparse,base64,json,copy,re,zipfile
from pathlib import Path
from urllib.parse import urlparse
from read_inputs import validate_chain

LABELS=dict(event='有事为证',numbers='有数为证',comparison='有对比为证',research='有研究为证')
def nonempty(v):return isinstance(v,str) and bool(v.strip())
def has_unqualified_claim(body):
    # Narrow wording guard only; an explicitly negated warning is not a claim.
    terms=('这类研究支持','研究已经证明','后续费用不失控','后续不超预算','决策才稳','真实顾虑')
    for sentence in re.split(r'[。！？?\n；;]',body):
        for term in terms:
            for match in re.finditer(re.escape(term),sentence):
                prefix=sentence[:match.start()].rstrip(' “"「『')
                if not re.search(r'(?:不(?:得|能|要|应|可)|禁止|避免)(?:写成|说成|说|宣称|声称|表述为|认定|认为)?$',prefix):
                    return True
    return False
def validate(d):
    validate_chain(d)
    g=d.get('guidance') or {}
    if g.get('schema')!='guide-1' or g.get('preferred') not in LABELS or not nonempty(g.get('reason')):raise ValueError('缺建议结构、推荐路线或理由')
    ms=g.get('methods')
    if not isinstance(ms,list) or len(ms)!=4 or any(not isinstance(x,dict) for x in ms) or [x.get('id') for x in ms]!=list(LABELS):raise ValueError('须分别准备四条写作路线')
    sources={s['id']:s for s in d.get('sources',[])}
    for x in ms:
        state=x.get('evidence_state')
        refs=x.get('fact_source_ids')
        if state not in ('collecting','documented') or not isinstance(refs,list):raise ValueError('每条须明确取材中或已有证据，以及fact_source_ids')
        if state=='documented':
            if not refs:raise ValueError('已有证据须绑定原始材料')
            for rid in refs:
                src=sources.get(rid,{})
                if rid in ('input-hook','input-profile') or src.get('review_status')!='opened' or not src.get('locator') or not src.get('summary'):raise ValueError('画像/观点或无原文位置不能当作案例研究证据')
        else:
            if refs:raise ValueError('取材中不能同时声称已有事实来源')
            if any(not isinstance(t,str) or not t.rstrip().endswith(('？','?')) for t in x.get('steps',[])):raise ValueError('缺证时只交不预设答案的取材问题，不写既定动作结果')
            body=' '.join([x.get('advice',''),*x.get('steps',[]),*(m.get('detail','') for m in x.get('materials',[]))])
            if has_unqualified_claim(body):raise ValueError('取材建议预设了未提供的事实或结论')
            if x.get('id')=='numbers' and re.search(r'[×*]|功率\s*[xX]',body):raise ValueError('缺真实参数时不先写乘法估算，先问单位时段与依据')
        if x.get('label')!=LABELS[x['id']]:raise ValueError('讲法名称不匹配')
        if any(not nonempty(x.get(k)) for k in ('advice','outline','limits')):raise ValueError('缺写法、骨架或边界')
        for k,lo,hi in [('steps',2,4),('materials',0,3),('need_from_owner',0,3)]:
            if not isinstance(x.get(k),list) or not lo<=len(x[k])<=hi:raise ValueError('条数或类型不符：'+k)
        if any(not nonempty(t) for t in x['steps']+x['need_from_owner']):raise ValueError('步骤与本人材料必须可读')
        for m in x['materials']:
            if not isinstance(m,dict) or m.get('kind') not in ('verified','direction') or any(not nonempty(m.get(k)) for k in ('title','detail')):raise ValueError('材料须分已核实和查找方向')
            if m['kind']=='direction':
                if m.get('source_id') or m.get('url'):raise ValueError('未核方向不能伪装原文来源')
            else:
                s=sources.get(m.get('source_id'))
                if not s or s.get('publicity')!='public' or s.get('origin')!='public_source' or s.get('review_status')!='opened':raise ValueError('已核资料缺可公开原始来源')
                if any(not nonempty(s.get(k)) for k in ('url','published_at','accessed_at','access_method','locator','summary')):raise ValueError('已核来源缺日期或原文位置')
                if urlparse(s['url']).scheme not in ('https','http'):raise ValueError('来源链接不安全')
                if any(t in s['access_method'] for t in ('仅摘要','读取摘要','检索摘要','未打开')):raise ValueError('摘要不得升级为已核原文')
    return {'kind':'writing_guidance_not_script','routes':4,'verified_materials':sum(m['kind']=='verified' for x in ms for m in x['materials']),'note':'结构通过不等于资料真实性、语义或WorkBuddy原生通过'}

def export(d,out):
    report=validate(d);out=Path(out)
    if out.exists() and any(out.iterdir()):raise ValueError('输出目录非空；请另存，不覆盖旧稿')
    assets=Path(__file__).resolve().parent.parent/'assets'
    d=copy.deepcopy(d)
    prompts=json.loads((assets/'method-prompts.json').read_text())
    for x in d['guidance']['methods']:
        if x['evidence_state']=='collecting':
            t=prompts[x['id']]
            x['outline']=' → '.join(v['label']+'：[按真实资料填写]' for v in t['details'])
            if x['id']=='event':
                x['advice']='围绕上面这句观点，先找一件有记录可回查的真实事情。把当时的问题、采取的动作和后来发生的变化讲清，不先规定它必须支持这句观点。'
                x['steps']=['当时具体要解决什么问题，涉及谁？','实际采取了什么动作，有什么记录可以核对？','后来发生了什么，哪些部分支持或不支持上面这句观点？']
                x['materials']=[m for m in x['materials'] if m['kind']=='verified']+[{'kind':'direction','title':'先找一件可回查的事情','detail':'围绕当前观点，查看本人可公开或已脱敏的原始记录；有相反结果也如实保留。没有这样的事，不编故事。'}]
                x['materials']=x['materials'][:3]
                x['need_from_owner']=['一件与当前观点有关、可回查且已脱敏的真实事情；没有就说明没有。']
            if x['id']=='comparison':
                x['advice']='围绕上面这句观点，把两种实际选择放到同一需求和同一比较口径下，看材料显示哪些相同、哪些不同。不按价格或身份先判谁好谁坏。'
                x['steps']=['本题要比较哪两种真实选择，客户要解决的是同一个问题吗？','哪些条件需要对齐，比较的时间范围和资料来源分别是什么？','实际有哪些差别，也可能没有明显差别，它们能说明什么、还不能说明什么？']
                x['materials']=[m for m in x['materials'] if m['kind']=='verified']+[{'kind':'direction','title':'准备双方同口径材料','detail':'按本题收集双方可核对的原件或实际记录，列明已知项、估算项与缺项。保持相同需求及比较条件，不先填优劣或输赢。'}]
                x['materials']=x['materials'][:3]
                x['need_from_owner']=['本题两种选择的原始材料，以及实际需要对齐的条件；没有的项目标明未知。']
            if x['id']=='research':x['advice']='这条先找与当前观点直接相关的原始研究。没找到并读懂原文前，只提供查找方向，不写研究结论。'
    css=(assets/'style.css').read_text().replace('__PROOF_TEXTURE__','data:image/png;base64,'+base64.b64encode((assets/'background.png').read_bytes()).decode())
    payload=json.dumps({'project':d},ensure_ascii=False).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    prompts=json.loads((assets/'method-prompts.json').read_text())
    if list(prompts)!=list(LABELS) or any(len(x.get('details',[]))!=3 for x in prompts.values()):raise ValueError('课堂提示必须含四种讲法、各三个细节')
    safe_prompts=json.dumps(prompts,ensure_ascii=False).replace('<','\\u003c')
    page=(assets/'guide.html').read_text().replace('__STYLE__',css).replace('__DATA__',payload).replace('__PROMPTS__',safe_prompts)
    if any(t in page for t in ('__STYLE__','__DATA__','__PROMPTS__')):raise ValueError('页面未完整填入')
    out.mkdir(parents=True,exist_ok=True)
    (out/'以理服人写作建议.html').write_text(page,encoding='utf-8')
    (out/'project.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'检查记录.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    with zipfile.ZipFile(out/'四种讲法建议.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for i,x in enumerate(d['guidance']['methods'],1):
            t=prompts[x['id']]
            source_by_id={s['id']:s for s in d.get('sources',[])}
            material_lines=[]
            for m in x['materials']:
                line=('已核对原文：' if m['kind']=='verified' else '建议查找，尚未核实：')+m['title']+'：'+m['detail']
                if m['kind']=='verified':
                    s=source_by_id[m['source_id']]
                    line+='\n原文：'+s['url']+'\n位置：'+s['locator']+'\n发布：'+s['published_at']+'；核对：'+s['accessed_at']
                material_lines.append(line)
            parts=[('虚拟教学示例' if d.get('mode')=='fictional_demo' else '写作建议'),d['profile']['label'],d['selection']['viewpoint'],x['label'],'拿什么：'+t['materials'],t['question'],*[v['label']+'：'+v['hint'] for v in t['details']],t['closing'],x['advice'],*x['steps'],*material_lines,*x['need_from_owner'],x['outline'],'边界：'+x['limits']]
            name=f'{i:02d}-{x["label"]}-建议.txt'
            (out/name).write_text('\n\n'.join(parts),encoding='utf-8')
            archive.writestr(name,'\n\n'.join(parts))
    return out/'以理服人写作建议.html'
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('input',type=Path);a.add_argument('--out',required=True,type=Path);args=a.parse_args()
    page=export(json.loads(args.input.read_text()),args.out)
    print('打开以理服人写作建议：'+str(page.resolve()))
    print('保存四种讲法建议：'+str((page.parent/'四种讲法建议.zip').resolve()))
