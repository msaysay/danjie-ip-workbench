#!/usr/bin/env python3
"""Offline, standard-library-only validator/exporter. Never authors business facts."""
import argparse
import copy
import csv
import html
import json
import sys
from pathlib import Path

VERSION = "0.3.3"
READABLE_VERSIONS = {"0.3.0", "0.3.1", "0.3.2", VERSION}
COMPLETED_MATERIAL = {"completed_self_report", "completed_record_available", "verified_record", "self_report_without_records"}
FUNCTIONS = ["当头一棒", "以理服人", "亮出绝活", "指条明路"]
KEYS = ["hook", "proof", "ability", "guide"]
LIMITS = dict(profile=10, hook=5, proof=3, ability=10, guide=5)
METHODS = {"necessary_condition": "推翻必要条件", "selection_standard": "翻转选择标准", "result_direction": "翻转结果方向"}
BINDING_KEYS = ["context_id", "context_version", "profile_id", "profile_version", "topic_id", "viewpoint_id", "viewpoint", "method"]
PROOF_METHOD_VERSION = "0.4.3"


def nonblank(value):
    return isinstance(value, str) and bool(value.strip())


def proof_gate(data):
    """Proof-only record consistency, not semantic verification of the argument."""
    errors, blockers = [], []
    proof = (data.get("cards") or {}).get("proof") or {}
    if not proof:
        return dict(errors=[], blockers=["尚无以理服人卡"], can_export_text=False,
                    status="pending", method_version=PROOF_METHOD_VERSION)
    assessment = proof.get("support_assessment")
    text = proof.get("text", "")
    if assessment not in ("supported", "partial", "unsupported"):
        errors.append("proof.support_assessment须为supported/partial/unsupported")
    placeholder = isinstance(text, str) and text.startswith("【待补：") and text.endswith("】") and "\n" not in text
    if assessment != "supported":
        blockers.append("当前准确观点尚未充分支撑，只交待查卡")
        if not placeholder:
            errors.append("未充分支撑的proof.text必须是单条【待补：具体原因】占位，不能另交口播")
    elif not nonblank(text) or placeholder:
        errors.append("supported卡须有实际说理草稿，不能仍是空白或待补占位")
    if not data.get("selection"):
        blockers.append("尚未选定准确当头一棒")
    reasons = proof.get("reasoning", [])
    if not isinstance(reasons, list):
        errors.append("proof.reasoning须为数组")
        reasons = []
    if assessment == "supported" and not 1 <= len(reasons) <= 3:
        blockers.append("以理服人须有1至3条相关支撑链")
    if assessment == "supported" and not nonblank(proof.get("countercheck")):
        blockers.append("缺实际反例/另一解释/边界核对记录")
    sources = {s.get("id"): s for s in data.get("sources", []) if isinstance(s, dict)}
    ids = list(proof.get("source_ids", [])) if isinstance(proof.get("source_ids", []), list) else []
    for row in reasons:
        if not isinstance(row, dict):
            continue
        if assessment == "supported" and (not row.get("source_ids") or any(not nonblank(row.get(k)) for k in ("text", "proves", "limit"))):
            blockers.append("支撑链缺材料、回扣、边界或来源")
        ids.extend(row.get("source_ids", []) if isinstance(row.get("source_ids", []), list) else [])
    if assessment == "supported":
        if not ids:
            blockers.append("没有支撑来源")
        for sid in dict.fromkeys(ids):
            s = sources.get(sid)
            if not s:
                blockers.append("支撑来源不存在：" + str(sid))
                continue
            if s.get("publicity") != "public":
                blockers.append("支撑来源未获公开许可：" + str(sid))
            if s.get("origin") == "public_source" and s.get("review_status") != "opened":
                blockers.append("外部来源原材料尚未读到：" + str(sid))
            if s.get("origin") == "public_source" and s.get("review_status") == "opened":
                if (not str(s.get("url", "")).startswith(("http://", "https://"))
                        or not nonblank(s.get("accessed_at")) or "published_at" not in s
                        or not nonblank(s.get("access_method")) or not nonblank(s.get("locator"))):
                    blockers.append("外部来源缺可核对的原文访问记录：" + str(sid))
            if s.get("origin") == "hypothesis":
                blockers.append("AI推测不能作为已成立事实：" + str(sid))
            if s.get("origin") == "simulation" and data.get("mode") != "fictional_demo":
                blockers.append("模拟材料不能作为真实业务支撑：" + str(sid))
            if s.get("review_status") == "pending":
                blockers.append("来源仍待核对：" + str(sid))
    if assessment == "supported" and blockers:
        errors.append("supported状态与支撑记录冲突；先补材料或改为待补占位，不导出口播")
    return dict(errors=list(dict.fromkeys(errors)), blockers=list(dict.fromkeys(blockers)),
                can_export_text=assessment == "supported" and not errors and not blockers,
                status="teaching_demo" if data.get("mode") == "fictional_demo" and not errors and not blockers else "draft_supported" if assessment == "supported" and not errors and not blockers else "pending",
                method_version=PROOF_METHOD_VERSION,
                note="仅检查状态与来源记录一致性，不证明来源真被访问、语义支撑充分、本人已核对或获客有效")


def shape_errors(data):
    """Reject malformed nested JSON before semantic checks; never coerce confirmations."""
    errors = []
    if not isinstance(data, dict):
        return ["根数据必须为对象"]
    for key in ("workflow_id", "context_id"):
        if not nonblank(data.get(key)):
            errors.append(key + "须为非空字符串")

    def obj(value, path):
        if not isinstance(value, dict):
            errors.append(path + "须为对象")
            return {}
        return value

    def strings(value, path):
        if not isinstance(value, list) or any(not nonblank(x) for x in value):
            errors.append(path + "须为非空字符串数组（可空数组）")

    def rows(value, path):
        if not isinstance(value, list):
            errors.append(path + "须为数组")
            return []
        for i, row in enumerate(value):
            if not isinstance(row, dict):
                errors.append(f"{path}[{i}]须为对象")
        return [x for x in value if isinstance(x, dict)]

    def identifier(row, key, path):
        if key in row and row[key] is not None and not nonblank(row[key]):
            errors.append(path + "." + key + "须为非空字符串")

    def boolean(row, key, path):
        if key in row and type(row[key]) is not bool:
            errors.append(path + "." + key + "须为JSON布尔值，不接受字符串/数字")

    business = obj(data.get("business"), "business")
    strings(business.get("target_roles", []), "business.target_roles")
    profile = obj(data.get("profile"), "profile")
    identifier(profile, "id", "profile")
    obj(profile.get("roles", {}), "profile.roles")
    for trait in rows(profile.get("traits", []), "profile.traits"):
        strings(trait.get("source_ids", []), "trait.source_ids")
    for field in ("needs", "concerns", "service_matches", "topics", "sources"):
        for row in rows(data.get(field, []), field):
            identifier(row, "id", field)
            if field == "sources" and not isinstance(row.get("origin"), str):
                errors.append("source.origin须为字符串枚举")
            for key in ("source_ids", "need_ids", "concern_ids"):
                if key in row:
                    strings(row[key], field + "." + key)
            if field == "topics":
                for a in rows(row.get("approaches", []), "approaches"):
                    if not isinstance(a.get("method"), str):
                        errors.append("approach.method须为字符串枚举")
                    identifier(a, "viewpoint_id", "approach")
                    strings(a.get("old_cognition_source_ids", []), "approach.old_cognition_source_ids")
    selection = data.get("selection")
    if selection is not None:
        selection = obj(selection, "selection")
        for key in ("topic_id", "viewpoint_id", "viewpoint", "method", "customer_task"):
            if not nonblank(selection.get(key)):
                errors.append("selection." + key + "须为非空字符串")
    cards = obj(data.get("cards") if data.get("cards") is not None else {}, "cards")
    for key in KEYS:
        if cards.get(key) is None:
            continue
        card = obj(cards[key], "cards." + key)
        identifier(card, "id", key)
        if type(card.get("version")) is not int or card.get("version", 0) < 1:
            errors.append(key + ".version须为正整数")
        obj(card.get("binding"), key + ".binding")
        boolean(card, "stance_confirmed", key)
        strings(card.get("source_ids", []), key + ".source_ids")
        if "text" in card and not isinstance(card["text"], str):
            errors.append(key + ".text须为字符串")
        if key == "proof":
            for row in rows(card.get("reasoning", []), "proof.reasoning"):
                strings(row.get("source_ids", []), "reasoning.source_ids")
                if any(not nonblank(row.get(k)) for k in ("text", "proves", "limit")):
                    errors.append("支撑链每项须有text/proves/limit")
        if key == "ability":
            for row in rows(card.get("claims", []), "ability.claims"):
                strings(row.get("source_ids", []), "claim.source_ids")
                if not nonblank(row.get("text")):
                    errors.append("本人声明每项须有text")
        if key == "guide":
            entry = obj(card.get("public_entry") or {}, "guide.public_entry")
            boolean(entry, "owner_confirmed", "public_entry")
            boolean(entry, "tested", "public_entry")
            strings(entry.get("source_ids", []), "public_entry.source_ids")
    state = obj(data.get("state"), "state")
    counts = obj(state.get("question_counts"), "state.question_counts")
    if set(counts) != set(LIMITS):
        errors.append("question_counts须保留五阶段完整计数，不得以丢字段重置")
    if state.get("pending_question") is not None:
        pending = obj(state["pending_question"], "pending_question")
        for key in ("id", "text", "stage"):
            if not nonblank(pending.get(key)):
                errors.append("pending_question." + key + "须为非空字符串")
    strings(state.get("completed", []), "state.completed")
    review = obj(data.get("owner_review") or {}, "owner_review")
    boolean(review, "confirmed", "owner_review")
    identifier(review, "source_id", "owner_review")
    if data.get("script") is not None:
        script = obj(data["script"], "script")
        for row in rows(script.get("annotated", []), "script.annotated"):
            strings(row.get("source_ids", []), "annotated.source_ids")
            if not isinstance(row.get("text"), str):
                errors.append("annotated.text须为字符串")
        strings(script.get("filming_notes", []), "script.filming_notes")
    return errors


def validate(data):
    errors, warnings, blockers = [], [], []
    if not isinstance(data, dict):
        return dict(errors=["根数据必须为对象"], warnings=[], recording_gate=False, blockers=["数据无效"])
    for key in ["schema_version", "skill_version", "workflow_id", "context_id", "context_version", "mode", "status", "business", "profile", "needs", "concerns", "service_matches", "topics", "sources", "state", "pending_items"]:
        if key not in data:
            errors.append("缺根字段：" + key)
    if type(data.get("schema_version")) is not int or data.get("schema_version") != 1:
        errors.append("schema_version须为1")
    if not isinstance(data.get("skill_version"), str) or data.get("skill_version") not in READABLE_VERSIONS:
        errors.append("不支持的数据版本；请显式迁移，不按当前版本假称通过")
    elif data.get("skill_version") != VERSION:
        warnings.append("读取旧版数据" + data["skill_version"] + "；校验/导出工具为" + VERSION + "，未自动改写原数据版本")
    if data.get("mode") not in ("real", "fictional_demo"):
        errors.append("mode无效")
    if data.get("status") not in ("draft", "needs_review", "incomplete", "reviewed_for_recording"):
        errors.append("status无效")
    if type(data.get("context_version")) is not int or data.get("context_version", 0) < 1:
        errors.append("context_version须为正整数")
    if not data.get("workflow_id") or not data.get("context_id"):
        errors.append("工作ID/上下文ID不能为空")
    for key in ["needs", "concerns", "service_matches", "topics", "sources", "pending_items"]:
        if key in data and not isinstance(data[key], list):
            errors.append(key + "须为数组")
    if errors:
        return dict(errors=errors, warnings=warnings, recording_gate=False, blockers=["结构无效"])
    errors.extend(shape_errors(data))
    if errors:
        return dict(errors=errors, warnings=warnings, recording_gate=False, blockers=["嵌套结构无效"])
    proof_report = proof_gate(data)
    errors.extend(proof_report["errors"])
    if ((data.get("cards") or {}).get("proof") or {}).get("support_assessment") == "supported":
        blockers.extend(proof_report["blockers"])
    sources = {}
    origins = {"user_statement", "recalled_quote", "exact_quote", "document", "public_source", "hypothesis", "simulation"}
    for source in data["sources"]:
        sid = source.get("id")
        if not sid or sid in sources:
            errors.append("来源ID缺失或重复：" + str(sid))
        sources[sid] = source
        if source.get("origin") not in origins:
            errors.append("来源类型无效：" + str(sid))
        if source.get("publicity") not in ("public", "internal", "unknown"):
            errors.append("来源公开状态缺失：" + str(sid))
        if not nonblank(source.get("reference")) or source.get("review_status") not in ("provided", "opened", "pending", "simulated"):
            errors.append("来源须有定位和核对状态：" + str(sid))
        if source.get("origin") == "public_source" and source.get("review_status") == "opened":
            if not str(source.get("url", "")).startswith(("https://", "http://")) or not nonblank(source.get("accessed_at")):
                errors.append("声称打开的外部来源缺URL/访问日期：" + str(sid))
            if "published_at" not in source:
                errors.append("外部来源须保留published_at；不详显式填null，不编日期：" + str(sid))
            if not nonblank(source.get("access_method")) or not nonblank(source.get("locator")):
                blockers.append("外部来源缺实际打开方式/相关原文定位：" + str(sid))
        if data["mode"] == "real" and source.get("origin") == "simulation":
            blockers.append("含模拟来源，不得标真人可试拍")

    def refs(ids, where, required=False, public=False):
        if not isinstance(ids, list):
            errors.append(where + "的source_ids须为数组")
            return
        if required and not ids:
            blockers.append(where + "无来源")
        for sid in ids:
            if sid not in sources:
                errors.append(where + "引用不存在的来源：" + str(sid))
            elif public and sources[sid].get("publicity") != "public":
                blockers.append(where + "使用未获公开许可的来源：" + str(sid))
            elif public and sources[sid].get("origin") in ("hypothesis", "simulation"):
                blockers.append(where + "仍用推测/模拟作事实")
            elif public and sources[sid].get("origin") == "public_source" and sources[sid].get("review_status") != "opened":
                blockers.append(where + "的外部来源尚未打开原材料：" + str(sid))

    profile = data["profile"]
    if not isinstance(profile, dict) or not profile.get("id") or type(profile.get("version")) is not int or profile.get("version", 0) < 1:
        errors.append("客群ID和正整数版本缺失")
        profile = {}
    business = data["business"]
    if not isinstance(business, dict) or not nonblank(business.get("offer")):
        blockers.append("当前业务未明确")
        business = {}
    if profile.get("customer_role") and profile["customer_role"] not in business.get("target_roles", []):
        errors.append("客群角色不属于当前业务目标客户")
    for trait in profile.get("traits", []):
        refs(trait.get("source_ids", []), "客群特征")
    need_ids = {x.get("id") for x in data["needs"]}
    concern_ids = {x.get("id") for x in data["concerns"]}
    for field in ("needs", "concerns"):
        ids = set()
        for item in data[field]:
            if not item.get("id") or item["id"] in ids:
                errors.append(field + "的ID缺失/重复")
            ids.add(item.get("id"))
            refs(item.get("source_ids", []), field)
            if item.get("assessment") not in ("reported", "observed", "candidate", "unknown"):
                errors.append(field + "缺证据状态")
            if field == "concerns" and any(x not in need_ids for x in item.get("need_ids", [])):
                errors.append("顾虑引用不存在的需求")
            if item.get("assessment") in ("reported", "observed") and any(sources.get(s, {}).get("origin") == "hypothesis" for s in item.get("source_ids", [])):
                errors.append("AI推测不能标真实反馈/观察")
    for match in data["service_matches"]:
        refs(match.get("source_ids", []), "服务匹配")
        if any(x not in need_ids for x in match.get("need_ids", [])) or any(x not in concern_ids for x in match.get("concern_ids", [])):
            errors.append("服务匹配引用不存在的需求/顾虑")
    topics = {}
    view_ids = set()
    for topic in data["topics"]:
        if not topic.get("id") or topic["id"] in topics:
            errors.append("选题ID缺失/重复")
        topics[topic.get("id")] = topic
        refs(topic.get("source_ids", []), "选题")
        if topic.get("customer_role") not in business.get("target_roles", []):
            errors.append("选题偷换目标客户角色：" + str(topic.get("id")))
        if topic.get("customer_role") != profile.get("customer_role"):
            errors.append("选题与当前优先客群角色不一致：" + str(topic.get("id")))
        if any(x not in need_ids for x in topic.get("need_ids", [])) or any(x not in concern_ids for x in topic.get("concern_ids", [])):
            errors.append("选题引用不存在的需求/顾虑")
        methods = set()
        for approach in topic.get("approaches", []):
            method = approach.get("method")
            if method not in METHODS or method in methods:
                errors.append("反转方式无效或同题重复")
            methods.add(method)
            refs(approach.get("old_cognition_source_ids", []), "原认知")
            if approach.get("status") not in ("candidate", "selected", "no_fit", "pending"):
                errors.append("反转状态无效")
            if approach.get("status") in ("candidate", "selected"):
                vid = approach.get("viewpoint_id")
                if not vid or vid in view_ids or not approach.get("statement") or not approach.get("old_cognition"):
                    errors.append("可用反转缺独立ID/原认知/句子，或观点ID重复")
                view_ids.add(vid)
    state = data["state"]
    if not isinstance(state, dict):
        errors.append("state须为对象")
        state = {}
    for stage, count in state.get("question_counts", {}).items():
        if stage not in LIMITS or type(count) is not int or count < 0 or count > LIMITS[stage]:
            errors.append("实际发问超额或计数无效：" + stage)
    pending_question = state.get("pending_question")
    if pending_question and (not pending_question.get("id") or not pending_question.get("text") or pending_question.get("stage") not in LIMITS):
        errors.append("断点问题缺ID/阶段/问题")
    selection = data.get("selection")
    cards = data.get("cards") or {}
    if selection:
        topic = topics.get(selection.get("topic_id"), {})
        match = [a for a in topic.get("approaches", []) if a.get("method") == selection.get("method") and a.get("viewpoint_id") == selection.get("viewpoint_id") and a.get("statement") == selection.get("viewpoint") and a.get("status") == "selected"]
        if len(match) != 1:
            errors.append("选中观点与本题方法/准确句子/选择状态不一致")
        if selection.get("customer_task") != topic.get("task"):
            errors.append("选中任务与选题任务不一致")
        expected = dict(context_id=data["context_id"], context_version=data["context_version"], profile_id=profile.get("id"), profile_version=profile.get("version"), topic_id=selection.get("topic_id"), viewpoint_id=selection.get("viewpoint_id"), viewpoint=selection.get("viewpoint"), method=selection.get("method"))
        for key in KEYS:
            card = cards.get(key)
            if not card:
                blockers.append("缺卡：" + key)
                continue
            if not card.get("id") or type(card.get("version")) is not int:
                errors.append(key + "缺卡ID/版本")
            for field in BINDING_KEYS:
                if card.get("binding", {}).get(field) != expected[field]:
                    errors.append(key + "绑定失配：" + field)
            if not card.get("text"):
                blockers.append(key + "无可说文本")
            if not nonblank(card.get("text")):
                blockers.append(key + "可说文本为空或仅空白")
            if card.get("scope") == "unbound_draft":
                blockers.append(key + "仍是未绑定单模块草稿，须复核并生成绑定新版本")
            refs(card.get("source_ids", []), key, required=True, public=True)
        if (cards.get("hook") or {}).get("text") != selection.get("viewpoint"):
            errors.append("开场卡文本与选中观点不逐字一致")
        if (cards.get("hook") or {}).get("stance_confirmed") is not True:
            blockers.append("开场立场尚未本人确认")
    else:
        blockers.append("尚未选择准确观点")
        for key in KEYS:
            card = cards.get(key)
            if not card:
                continue
            if key not in ("ability", "guide") or card.get("scope") != "unbound_draft" or data.get("script") is not None:
                errors.append("未选观点的单模块须明确unbound_draft且不可总装：" + key)
                continue
            binding = card.get("binding", {})
            for field, expected_value in dict(context_id=data["context_id"], context_version=data["context_version"], profile_id=profile.get("id"), profile_version=profile.get("version")).items():
                if binding.get(field) != expected_value:
                    errors.append(key + "未绑定草稿上下文失配：" + field)
            if any(binding.get(field) is not None for field in ("viewpoint_id", "viewpoint", "method")):
                errors.append(key + "未绑定草稿不得伪造观点/方法")
            if binding.get("topic_id") is not None and binding["topic_id"] not in topics:
                errors.append(key + "草稿引用不存在的选题")
            refs(card.get("source_ids", []), key)
            blockers.append(key + "为未绑定单模块草稿，不能直接当已匹配观点的卡")
    proof = cards.get("proof") or {}
    if proof.get("support_assessment") != "supported":
        blockers.append("观点支撑未充分完成")
    if proof and not proof.get("reasoning"):
        blockers.append("观点没有具体支撑链")
    if proof and not proof.get("countercheck"):
        blockers.append("未检查反例/边界")
    for item in proof.get("reasoning", []):
        refs(item.get("source_ids", []), "支撑链", required=True, public=True)
    ability = cards.get("ability") or {}
    if not nonblank(ability.get("contribution")) or not ability.get("claims"):
        blockers.append("缺本人真实贡献/声明")
    material_state = str(ability.get("material_state") or "").strip().lower()
    if ability and not material_state:
        blockers.append("本人交付/材料状态未明确")
    if ability and material_state not in COMPLETED_MATERIAL:
        blockers.append("绝活仅计划/未执行/模拟或材料状态未知，不能视为已有真实交付")
    for item in ability.get("claims", []):
        refs(item.get("source_ids", []), "本人声明", required=True, public=True)
    guide = cards.get("guide") or {}
    entry = guide.get("public_entry") or {}
    if not nonblank(guide.get("first_step")) or not nonblank(guide.get("service")) or not nonblank(entry.get("value")) or entry.get("owner_confirmed") is not True:
        blockers.append("服务第一步或公开入口未本人明确")
    if any(token in str(entry.get("value") or "") for token in ("未提供", "待补", "待真人", "未确认")):
        blockers.append("公开入口仍是待补占位，不是已确认的真实入口")
    if entry.get("value"):
        refs(entry.get("source_ids", []), "公开入口", required=True, public=True)
    if entry.get("owner_confirmed") and not entry.get("tested"):
        warnings.append("入口仅本人提供，未实测送达/承接；不可宣称获客链验证")
    if guide and not nonblank(guide.get("handoff_check")):
        blockers.append("缺入口承接检查记录，不能宣称交接完整")
    review = data.get("owner_review") or {}
    review_source = sources.get(review.get("source_id"), {})
    if review.get("confirmed") is not True or review_source.get("origin") not in ("user_statement", "document") or review_source.get("review_status") not in ("provided", "opened"):
        blockers.append("缺可定位的本人最终核对")
    if data["mode"] == "fictional_demo":
        blockers.append("教学模拟不能标真人可试拍")
    for item in data["pending_items"]:
        if isinstance(item, dict) and item.get("severity") in ("critical", "blocker"):
            blockers.append(item.get("text", "有关键缺口"))
    script = data.get("script")
    if script:
        annotated = script.get("annotated", [])
        if [x.get("function") for x in annotated] != FUNCTIONS:
            errors.append("标注稿必须依次明确四招功能，不用开头/中段替代")
        if len(annotated) == 4:
            for key, item in zip(KEYS, annotated):
                if item.get("text") != (cards.get(key) or {}).get("text"):
                    errors.append("组稿与卡片文本不一致：" + key)
                refs(item.get("source_ids", []), "组稿", required=True, public=True)
        if script.get("clean_text") != "\n\n".join(x.get("text", "") for x in annotated):
            errors.append("干净稿与逐段标注稿不逐字一致")
    else:
        blockers.append("尚未总装文稿")
    blockers = list(dict.fromkeys(blockers))
    if data["status"] == "reviewed_for_recording" and (blockers or errors):
        errors.append("状态被错误升级为可试拍")
    return dict(errors=list(dict.fromkeys(errors)), warnings=warnings, recording_gate=not errors and not blockers, blockers=blockers, proof_gate=proof_report, note="结构门槛，不是事实核验或传播/成交效果判定")


def esc(value):
    return html.escape(str(value if value is not None else ""), quote=True)


def display_project(data, report):
    """Internal raw JSON is retained; incomplete claims are not presented as a usable script."""
    view = copy.deepcopy(data)
    cards = view.get("cards") or {}
    ability = cards.get("ability") or {}
    source_index = {source["id"]: source for source in view.get("sources", [])}
    ability_refs = list(ability.get("source_ids", []))
    for claim in ability.get("claims", []):
        ability_refs.extend(claim.get("source_ids", []))
    nonfact_ability = not ability_refs or any(source_index.get(sid, {}).get("origin") in (None, "hypothesis", "simulation") for sid in ability_refs)
    if ability and (str(ability.get("material_state", "")).strip().lower() not in COMPLETED_MATERIAL
                    or not nonblank(ability.get("contribution")) or not ability.get("claims") or nonfact_ability):
        ability["text"] = "【待补：本人真实完成的动作/交付尚未提供；计划或模拟不作为绝活证明】"
        for part in (view.get("script") or {}).get("annotated", []):
            if part.get("function") == "亮出绝活":
                part["text"] = ability["text"]
    guide = cards.get("guide") or {}
    entry = guide.get("public_entry") or {}
    if guide and (not nonblank(guide.get("service")) or not nonblank(guide.get("first_step"))
                  or not nonblank(entry.get("value")) or entry.get("owner_confirmed") is not True
                  or any(x in str(entry.get("value", "")) for x in ("未提供", "待补", "待真人", "未确认"))):
        guide["text"] = "【待补：真实服务第一步、公开入口及承接方式；当前不发出预约邀请】"
        for part in (view.get("script") or {}).get("annotated", []):
            if part.get("function") == "指条明路":
                part["text"] = guide["text"]
    if report.get("blockers") and view.get("script"):
        view["script"]["clean_text"] = "【净稿暂不提供：关键缺口或本人核对尚未完成。原project.json仅供恢复和审计，不表示可直接拍摄。】"
    return view


def mtext(value):
    """Render one untrusted value as literal Markdown text, never new markup."""
    text = str(value if value is not None else "")
    punctuation = r'''!"#$%'()*+,-./:;=?@[\]^_`{|}~'''
    entities = {"&": "&amp;", "<": "&lt;", ">": "&gt;", "\n": "&#10;", "\r": "&#13;", "\t": "&#9;"}
    return "".join(
        entities.get(char, "\\" + char if char in punctuation else "&#32;" if i == 0 and char == " " else char)
        for i, char in enumerate(text)
    )


def md(data, report):
    data = display_project(data, report)

    def value(item, default="待补"):
        return mtext(default if item is None or item == "" else item)

    def ids(items):
        return value(",".join(str(item) for item in (items or [])), "未提供")

    lines = ["# 老板IP获客内容档案", "", "模型：蛋解伏魔杖法", "",
             "输入数据版本：schema " + value(data.get("schema_version")) + " / skill " + value(data.get("skill_version")), "",
             "校验与导出工具版本：" + value(VERSION) + "（不自动改写输入数据版本）", "",
             "教学模拟，非真实客户/成绩/验证。" if data["mode"] == "fictional_demo" else "本人提供及材料记录仍须按来源核对，状态不代表发布或获客效果。", "",
             "## 当前状态", "", value(data["status"]), ""]
    lines += ["- " + value(item) for item in report.get("blockers", []) + report.get("warnings", [])]
    p, business = data["profile"], data["business"]
    roles = p.get("roles") or {}
    lines += ["", "## 目标客群画像", "", value(p.get("label")), "",
              "- 客群 ID / 版本：" + value(p.get("id")) + " / " + value(p.get("version")),
              "- 当前服务：" + value(business.get("offer")),
              "- 本轮优先内容对象：" + value(p.get("customer_role")),
              "- 业务目标角色：" + ids(business.get("target_roles", [])),
              "- 付款者：" + value(roles.get("payer")),
              "- 决策者：" + value(roles.get("decider")),
              "- 使用者：" + value(roles.get("user")),
              "- 业务排除：" + value(business.get("exclusions")),
              "- 服务范围与边界：" + value(business.get("service_scope")), ""]
    for item in p.get("traits", []):
        lines.append("- " + value(item.get("group")) + " / " + value(item.get("label")) + "：" + value(item.get("value"))
                     + "（状态：" + value(item.get("assessment"), "unknown") + "；来源：" + ids(item.get("source_ids")) + "）")
    for field, heading in [("needs", "需求"), ("concerns", "购买顾虑")]:
        lines += ["", "## " + heading, ""]
        for item in data[field]:
            lines.append("- " + value(item.get("id")) + " " + value(item.get("text"))
                         + "（状态：" + value(item.get("assessment"), "unknown") + "；来源：" + ids(item.get("source_ids"))
                         + ("；关联需求：" + ids(item.get("need_ids")) if field == "concerns" else "") + "）")
    lines += ["", "## 服务匹配", ""]
    for item in data["service_matches"]:
        lines += ["- 服务：" + value(item.get("help"), "未匹配") + "；边界：" + value(item.get("boundary")),
                  "  关联需求：" + ids(item.get("need_ids")) + "；关联顾虑：" + ids(item.get("concern_ids")) + "；来源：" + ids(item.get("source_ids"))]
    lines += ["", "## 候选选题库", ""]
    for i, topic in enumerate(data["topics"], 1):
        lines += ["### 选题 " + str(i), "", "- 选题 ID：" + value(topic.get("id")),
                  "- 问题：" + value(topic.get("question")), "- 状态：" + value(topic.get("status")),
                  "- 客户角色：" + value(topic.get("customer_role")), "- 客户任务：" + value(topic.get("task")),
                  "- 关联需求：" + ids(topic.get("need_ids")) + "；关联顾虑：" + ids(topic.get("concern_ids")),
                  "- 选题来源：" + ids(topic.get("source_ids")), ""]
        approaches = topic.get("approaches", [])
        if not approaches:
            lines += ["尚未生成反转方式与开场，不自动补写。", ""]
        for j, approach in enumerate(approaches, 1):
            method = approach.get("method")
            lines += ["#### 反转方式 " + str(j), "",
                      "- 方法：" + value(METHODS.get(method), "未识别方法") + " / " + value(method),
                      "- 状态：" + value(approach.get("status")),
                      "- 观点 ID：" + value(approach.get("viewpoint_id"), "未提供"),
                      "- 同题原认知：" + value(approach.get("old_cognition")),
                      "- 原认知来源：" + ids(approach.get("old_cognition_source_ids")),
                      "- 准确开场：" + ("【不适用，不生成句子】" if approach.get("status") == "no_fit" else value(approach.get("statement"), "【尚未生成】")), ""]
    selection = data.get("selection")
    lines += ["## 当前选择", ""]
    if selection:
        lines += ["- 选题 ID：" + value(selection.get("topic_id")), "- 方法：" + value(selection.get("method")),
                  "- 观点 ID：" + value(selection.get("viewpoint_id")), "- 本人选定的准确句子：" + value(selection.get("viewpoint")),
                  "- 客户任务：" + value(selection.get("customer_task")), ""]
    else:
        lines += ["尚未选定准确观点；以上候选不代表本人已确认采用。", ""]
    lines += ["## 四招卡与标注稿", ""]
    for key, label in zip(KEYS, FUNCTIONS):
        card = (data.get("cards") or {}).get(key) or {}
        lines += ["### " + label, "", value(card.get("text"), "【待补】"), "",
                  "卡片 ID / 版本：" + value(card.get("id"), "未提供") + " / " + value(card.get("version"), "未提供"), "",
                  "来源：" + ids(card.get("source_ids")), ""]
        if key == "proof" and card:
            lines += ["支撑状态：" + value(card.get("support_assessment")), ""]
            for item in card.get("reasoning", []):
                lines += ["- " + value(item.get("text")) + "；证明范围：" + value(item.get("proves"))
                          + "；边界：" + value(item.get("limit")) + "；来源：" + ids(item.get("source_ids"))]
            lines += ["", "反例与边界核对：" + value(card.get("countercheck")), ""]
        if key == "ability" and card:
            lines += ["交付/材料状态：" + value(card.get("material_state")), ""]
        if key == "guide" and card:
            entry = card.get("public_entry") or {}
            lines += ["- 服务：" + value(card.get("service")), "- 第一步：" + value(card.get("first_step")),
                      "- 公开入口：" + value(entry.get("value")),
                      "- 入口本人确认 / 实测状态：" + value(entry.get("owner_confirmed")) + " / " + value(entry.get("tested")),
                      "- 入口来源：" + ids(entry.get("source_ids")), "- 承接检查：" + value(card.get("handoff_check")), ""]
    lines += ["## 干净口播稿", ""]
    if report.get("blockers") or report.get("errors"):
        lines += ["净稿暂不提供：仍有关键缺口或结构错误。project.json 中的原稿只供恢复，不能视为完整可试拍稿。", ""]
    else:
        lines += [value((data.get("script") or {}).get("clean_text"), "【未总装，净稿暂不提供】"), ""]
    lines += ["## 拍摄提示", ""]
    lines += ["- " + value(item) for item in (data.get("script") or {}).get("filming_notes", [])]
    lines += ["", "## 来源及公开边界", ""]
    for source in data["sources"]:
        lines += ["- " + value(source.get("id")) + "｜" + value(source.get("origin")) + "｜" + value(source.get("reference"))
                  + "｜" + value(source.get("review_status")) + "｜" + value(source.get("publicity")),
                  "  摘要：" + value(source.get("summary"))]
        if source.get("url"):
            lines += ["  地址：" + value(source.get("url")) + "；发布日期：" + value(source.get("published_at"))
                      + "；访问日期：" + value(source.get("accessed_at"))]
    lines += ["", "## 缺口与断点", "",
              mtext(json.dumps(dict(pending=data["pending_items"], state=data["state"]), ensure_ascii=False, indent=2)), "",
              "本文件不等于已拍摄、已发布或已获客。"]
    return "\n".join(lines)


def render(data, report):
    data = display_project(data, report)
    safe = json.dumps(dict(project=data, report=report, methods=METHODS), ensure_ascii=False).replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    return r'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none';style-src 'unsafe-inline';script-src 'unsafe-inline';img-src data:;connect-src 'none';font-src 'none'"><title>蛋解伏魔杖法｜获客内容档案</title><style>
:root{--bg:#0b0e10;--panel:#151b1e;--gold:#f5ce53;--muted:#a7b1b6;--line:#303a3f;--cyan:#84ccdc;--green:#91c6a7}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:#f2f3ef;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;line-height:1.7}header{padding:56px max(24px,calc((100vw - 1260px)/2)) 36px;border-bottom:1px solid var(--line);background:radial-gradient(ellipse at right top,#4b3c1626,transparent 64%)}.eyebrow{color:var(--gold);font-size:13px;letter-spacing:3px}h1{font-size:clamp(30px,4vw,48px);line-height:1.3;margin:15px 0 14px;letter-spacing:-1px}h2{font-size:25px;margin:0 0 24px}h3{font-size:18px;margin:0 0 10px}p{margin:8px 0}.muted,small{color:var(--muted)}.wrap{max-width:1308px;padding:28px 24px 64px;margin:auto;display:grid;grid-template-columns:196px 1fr;gap:40px}aside{position:sticky;top:22px;height:max-content}aside a{display:block;color:var(--muted);text-decoration:none;padding:12px 0;font-size:14px}aside a:hover{color:var(--gold)}section{margin-bottom:46px;scroll-margin-top:22px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.card{border:1px solid var(--line);border-radius:14px;padding:23px;background:var(--panel);overflow-wrap:anywhere}.wide{grid-column:1/-1}.tag{color:var(--gold);font-size:12px;letter-spacing:1px}.notice{padding:15px 20px;border-left:3px solid var(--gold);background:#211d13;margin-bottom:25px}.notice p{font-size:14px}.steps{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}.step{color:var(--muted);border:1px solid var(--line);padding:7px 12px;border-radius:99px;font-size:13px}.step.done{color:var(--green);border-color:#436352}.num{color:var(--cyan);font-size:13px;margin-right:10px}ul{padding-left:20px}.item{border-bottom:1px solid var(--line);padding:12px 0}.item:last-child{border:0}.fact{display:flex;justify-content:space-between;gap:16px}.fact span:first-child{color:var(--muted);font-size:14px}.fact span:last-child{text-align:right}button,select{background:#1c252a;color:#eef1ed;border:1px solid #3a484f;border-radius:8px;padding:10px 13px;font:inherit;font-size:14px;cursor:pointer;max-width:100%}button:hover,button.active{border-color:var(--gold);color:var(--gold)}button:disabled{opacity:.45;cursor:default}.buttons{display:flex;gap:10px;flex-wrap:wrap;margin:16px 0}.quote{font-size:24px;line-height:1.65;color:var(--gold);margin:20px 0}.pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:17px;line-height:1.9}.source{font-size:12px;color:var(--muted);margin-top:14px}.function{font-size:15px;color:var(--gold);margin:0 0 12px}.script-block{border-top:1px solid var(--line);padding:23px 0}.script-block:first-child{border-top:0}details summary{cursor:pointer;color:var(--cyan)}.reveal{padding:14px 0}footer{color:var(--muted);font-size:12px;padding-top:30px;border-top:1px solid var(--line)}#copy-status{color:var(--green);font-size:13px}.pill{color:var(--green)}@media(max-width:760px){.wrap{display:block;padding:22px 18px}aside{position:static;display:flex;gap:16px;overflow:auto;margin-bottom:24px}aside a{white-space:nowrap}.grid{grid-template-columns:1fr}.wide{grid-column:auto}header{padding:32px 22px}.card{padding:19px}.fact{display:block}.fact span:last-child{display:block;text-align:left}.quote{font-size:21px}}@media print{body{background:#fff;color:#111}header{background:none}aside,.buttons,select{display:none}.wrap{display:block}.card,.notice{background:white;border-color:#bbb}.muted,small,.source{color:#555}.quote,.function,.tag,.eyebrow{color:#756000}section{break-inside:avoid}details{display:block}}</style>
<header><div class="eyebrow">蛋解课堂 · 学员实操档案</div><h1>从一群客户，到一条获客视频</h1><p class="muted">蛋解伏魔杖法 / 客群画像 → 当头一棒 → 以理服人 → 亮出绝活 → 指条明路</p><div class="steps" id="steps"></div></header><div class="wrap"><aside><a href="#overview">01 客群与服务</a><a href="#demand">02 需求与顾虑</a><a href="#topics">03 选题与开场</a><a href="#script">04 四招与成稿</a><a href="#sources">05 来源与断点</a></aside><main><div id="notices"></div><section id="overview"><h2>先知道，你在帮谁</h2><div class="grid" id="profile"></div></section><section id="demand"><h2>想要什么，为什么犹豫</h2><div class="grid" id="needs"></div><div id="matches"></div></section><section id="topics"><h2>把顾虑，变成可讲的问题</h2><div class="card"><label for="topic">01 / 具体选题</label><p><select id="topic"></select></p><div class="buttons" id="methods"></div><div id="approach"></div></div><p class="source">仅浏览已生成候选，不联网。切换这里不会改写当前成稿；换题需回 WorkBuddy 重新匹配后续三招。</p></section><section id="script"><h2>四招合一，前后只讲一件事</h2><div class="buttons"><button id="annotated-btn" class="active">逐段标注稿</button><button id="clean-btn">干净口播稿</button><button id="copy-btn">复制当前稿</button><span id="copy-status"></span></div><div class="card" id="script-content"></div><div class="card" style="margin-top:16px"><h3>拍摄提示 / 待补事项</h3><div id="filming"></div></div></section><section id="sources"><h2>依据留得住，下次不重问</h2><div class="card"><details><summary>查看来源与公开状态</summary><div id="source-list" class="reveal"></div></details><details><summary>查看当前断点与缺口</summary><pre id="state" class="pre reveal"></pre></details></div></section><footer>离线结果页 · 所有文案来自本次数据。未核实项不等于事实；未试拍、未发布、未验证获客效果。下次把 project.json 交给 WorkBuddy 继续。</footer></main></div>
<script type="application/json" id="payload">''' + safe + r'''</script><script>
const {project:p,report:r,methods:M}=JSON.parse(document.getElementById('payload').textContent);const $=id=>document.getElementById(id);const E=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const labels={reported:'本人提供',observed:'材料记录',candidate:'待验证候选',unknown:'待补',draft:'草稿',needs_review:'待核对',incomplete:'有缺口',reviewed_for_recording:'本人核对后可试拍'};const names=['目标客群','当头一棒','以理服人','亮出绝活','指条明路'];const keys=['profile','hook','proof','ability','guide'];$('steps').innerHTML=names.map((x,i)=>'<span class="step '+((p.state.completed||[]).includes(keys[i])?'done':'')+'">'+(i+1)+' / '+E(x)+'</span>').join('');
let n=[];if(p.mode==='fictional_demo')n.push('教学模拟：人物、客户、记录、成绩和入口均非真人验证，不可照搬成自己的事实。');n.push('当前状态：'+(labels[p.status]||p.status));if(r.blockers.length)n.push(p.mode==='fictional_demo'?'本页仅演示最终版式；真人经历、实际入口和本人核对仍需补齐。完整检查可在「来源与断点」查看。':'仍需核对：'+r.blockers.slice(0,3).join('；')+(r.blockers.length>3?'；另有'+(r.blockers.length-3)+'项见「来源与断点」。':''));n.push(...r.warnings);$('notices').innerHTML='<div class="notice">'+n.map(x=>'<p>'+E(x)+'</p>').join('')+'</div>';
const pf=p.profile;const roles=pf.roles||{};$('profile').innerHTML='<div class="card wide"><div class="tag">目标客群 · '+E(pf.id)+' / v'+E(pf.version)+'</div><h3>'+E(pf.label)+'</h3><p>'+E(p.business.offer)+'</p><p class="muted">内容对象：'+E(pf.customer_role)+' · 付款：'+E(roles.payer||'待补')+' · 决策：'+E(roles.decider||'待补')+' · 使用：'+E(roles.user||'待补')+'</p><p class="source">服务边界：'+E(p.business.exclusions||'待补')+'</p></div>'+(pf.traits||[]).map(t=>'<div class="card"><div class="tag">'+E(t.group)+'</div><h3>'+E(t.label)+'</h3><p>'+E(t.value)+'</p><small>'+E(labels[t.assessment]||t.assessment)+' / '+E((t.source_ids||[]).join(', '))+'</small></div>').join('');
$('needs').innerHTML=[['needs','需求 / 想得到什么'],['concerns','顾虑 / 担心买后怎样']].map(([k,title])=>'<div class="card"><h3>'+title+'</h3>'+p[k].map(x=>'<div class="item"><span class="num">'+E(x.id)+'</span>'+E(x.text)+'<div class="source">'+E(labels[x.assessment]||x.assessment)+' / '+E(x.source_ids.join(', '))+'</div></div>').join('')+'</div>').join('');$('matches').innerHTML='<div class="card" style="margin-top:16px"><h3>我的服务能满足哪一部分</h3>'+p.service_matches.map(x=>'<div class="item">'+E(x.help)+'<p class="muted">边界：'+E(x.boundary)+'</p></div>').join('')+'</div>';
$('topic').innerHTML=p.topics.map(t=>'<option value="'+E(t.id)+'">'+E(t.id+' / '+t.question)+'</option>').join('');let method=p.selection?.method||'selection_standard';if(p.selection)$('topic').value=p.selection.topic_id;function showTopic(){const t=p.topics.find(t=>t.id===$('topic').value);if(!t){$('approach').textContent='选题待补';return}$('methods').innerHTML=Object.entries(M).map(([k,label])=>'<button data-method="'+k+'" class="'+(method===k?'active':'')+'">02 / '+label+'</button>').join('');for(const b of $('methods').querySelectorAll('button'))b.onclick=()=>{method=b.dataset.method;showTopic()};const a=(t.approaches||[]).find(a=>a.method===method);$('approach').innerHTML='<p class="source">客户任务：'+E(t.task)+'</p>'+(!a||['no_fit','pending'].includes(a.status)?'<p class="muted">这种反转尚无足够材料，不为凑按钮造一句。</p>':'<p class="muted">03 / 同题原认知</p><p>'+E(a.old_cognition)+'</p><p class="muted">04 / 一句开场</p><div class="quote">'+E(a.statement)+'</div><small>状态：'+E(a.status)+' · 观点 '+E(a.viewpoint_id)+' · 原认知依据 '+E((a.old_cognition_source_ids||[]).join(', '))+'</small>')};$('topic').onchange=showTopic;showTopic();
let mode='annotated';const F=['当头一棒','以理服人','亮出绝活','指条明路'];const K=['hook','proof','ability','guide'];function texts(){return p.script?.annotated||K.map((k,i)=>({function:F[i],text:p.cards?.[k]?.text||'【待补】',source_ids:p.cards?.[k]?.source_ids||[]}))}function showScript(){const a=texts();$('script-content').innerHTML=mode==='clean'?'<div class="pre">'+E(p.script?.clean_text||'【尚未总装，不能称完整干净稿】')+'</div>':a.map((x,i)=>'<div class="script-block"><div class="function">0'+(i+1)+' / '+E(x.function)+'</div><div class="pre">'+E(x.text)+'</div><div class="source">来源 '+E((x.source_ids||[]).join(', '))+'</div></div>').join('');$('annotated-btn').classList.toggle('active',mode==='annotated');$('clean-btn').classList.toggle('active',mode==='clean')};$('annotated-btn').onclick=()=>{mode='annotated';showScript()};$('clean-btn').onclick=()=>{mode='clean';showScript()};$('copy-btn').onclick=async()=>{const s=mode==='clean'?(p.script?.clean_text||'【未总装】'):texts().map(x=>'【'+x.function+'】\n'+x.text).join('\n\n');try{await navigator.clipboard.writeText(s);$('copy-status').textContent='已复制'}catch(e){const range=document.createRange();range.selectNodeContents($('script-content'));const sel=window.getSelection();sel.removeAllRanges();sel.addRange(range);$('copy-status').textContent='浏览器限制复制，文字已选中，请手动复制'}};showScript();$('filming').innerHTML=(p.script?.filming_notes||['尚未生成拍摄提示']).map(x=>'<p>'+E(x)+'</p>').join('');$('source-list').innerHTML=p.sources.map(s=>'<div class="item"><span class="num">'+E(s.id)+'</span>'+E(s.summary||s.reference)+'<p class="source">'+E(s.origin+' / '+s.review_status+' / '+s.publicity)+'<br>'+E(s.reference)+'</p></div>').join('');$('state').textContent=JSON.stringify({pending:p.pending_items,state:p.state},null,2);
$('state').textContent=JSON.stringify({pending:p.pending_items,state:p.state,checks:r},null,2);
if(r.blockers.length){$('clean-btn').disabled=true;$('clean-btn').textContent='净稿暂不提供 · 先补缺口';$('clean-btn').onclick=()=>{};$('copy-status').textContent='仅可复制当前待核标注稿，未完成处保留待补。'}
</script></html>'''


def export(data, out):
    # This portable evidence-card candidate has one student projection only.
    # Canonical full cumulative data remains in project.json, not in the student page.
    from proof_export import export_proof
    export_proof(data, out)
    return validate(data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["validate", "export"])
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding="utf-8"))
        if args.command == "export":
            if args.out is None:
                parser.error("export需要--out")
            report = export(data, args.out)
        else:
            report = validate(data)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return int(bool(report["errors"]))
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as e:
        print(json.dumps({"errors": [str(e)], "recording_gate": False}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
