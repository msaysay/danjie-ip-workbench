# 建议数据

课堂通用提示固定读取 assets/method-prompts.json，不让模型临场改写或省略。四种讲法各有取材范围、一句总追问、三项细节和一句提醒；页面、复制文字和下载数据都保留这些提示。它们是教学方法，不是客户已发生的事实。个性化 guidance 必须回答本题如何取材、如何展开，不能用固定提示冒充个性化结果。

在read_inputs种子根部添加guidance，不重建其它累计卡。schema为guide-1，推荐preferred属于四id之一，reason说明推荐理由。methods依次event/numbers/comparison/research。

```json
{"schema":"guide-1","preferred":"comparison","reason":"本题适合用实物展示差别","methods":[{"id":"event","label":"有事为证","evidence_state":"collecting","fact_source_ids":[],"advice":"本题先找一件与选中观点直接相关、能回查记录的事情。","steps":["当时具体卡在哪个问题？","实际做了什么，后来发生什么，有没有留下记录？"],"materials":[{"kind":"direction","title":"建议查什么","detail":"具体查询词、需要核什么"}],"need_from_owner":["只需本人提供的事情"],"outline":"[按真实资料填写]","limits":"单例不能证明所有客户有效"}]}
```

示例只给一项，实际四项都要有。每项还必须有 evidence_state 和 fact_source_ids。默认 evidence_state="collecting"、fact_source_ids=[]，此时 steps 为2—4个中性取材问题，以问号结尾，例如“当时为什么要比较这两种选择？”；不能预填动作、效果或成功结局。outline传入空白骨架即可，导出器会统一替换为三项真实资料填写框。materials为0—3条，need_from_owner为0—3条。无需本人补料写空数组，不能索要不相关收入/隐私。不要强凑固定资料数。

只有实际读到案例记录、计算原始数据或研究原文，才能写 evidence_state="documented"，fact_source_ids 绑定 sources 中对应原件，包含 opened 状态、locator 原文位置和 summary。客群卡、当头一棒观点都不是案例或研究证据，不能拿 input-profile/input-hook 代替。缺参数时先问数量、单位、时间范围和数据来源，不先列乘法估算；缺原研究时不代写研究结论。举例不冒充发生过的事实。

material.kind为direction或verified。direction只是具体找法，不能带source_id或链接假称已查。verified必须绑定source_id；对应sources原件应publicity=public、review_status=opened、origin=public_source，且url、published_at、accessed_at、access_method、locator、summary均来自本次实际打开原文。只读摘要、二手转引、打不开，仍为direction，不能升级。

verified资料也必须说明与此观点的关系和边界；不要只列标题/链接。研究资料讲到原研究实际测什么，不能从盘子感知跳到“某套餐够吃”，不能从推荐做法跳到效果保证。高风险法律、医疗、金融动态材料核现行官方来源，不给个案结论。

人物原话、统计和案例不从客群“可能担忧”推出来；用户确认不是独立核验。AI不能将生成的suggestion/outline写回本人事实库。guidance只是一张建议卡，不是原proof已成立或可发布的证明。
