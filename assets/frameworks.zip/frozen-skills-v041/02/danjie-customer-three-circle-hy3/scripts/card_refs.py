"""Resolve literal card fields; no external lookup or inferred values."""
def require(ok,message):
    if not ok:raise ValueError(message)

def resolve(profile,ref):
    require(isinstance(ref,str) and ref,'缺少来源路径')
    value=profile
    for part in ref.split('.'):
        if isinstance(value,dict):value=value.get(part)
        elif isinstance(value,list):
            ids=all(isinstance(v,dict) and v.get('id') for v in value)
            require(not(ids and part.isdecimal()),'来源数组有id，请用实际id：'+ref)
            value=(value[int(part)] if part.isdecimal() and int(part)<len(value)
                   else next((v for v in value if isinstance(v,dict) and v.get('id')==part),None))
        else:value=None
        require(value is not None,'原卡找不到来源：'+ref)
    require(isinstance(value,str) and value.strip(),'来源须指向卡内具体文字：'+ref)
    return value

def root(ref):return '.'.join(ref.split('.')[:2])
