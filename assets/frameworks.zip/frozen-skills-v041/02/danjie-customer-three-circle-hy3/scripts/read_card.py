"""Read supplied cards without third-party dependencies or executing their content."""
import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZipFile

IDS=['basic','family','occupation','spending','housing','habits']
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}

class VisibleText(HTMLParser):
    def __init__(self):
        super().__init__();self.parts=[];self.skip=0
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style'):self.skip+=1
        elif tag in ('p','div','h1','h2','h3','article','section','tr','br'):self.parts.append('\n')
    def handle_endtag(self,tag):
        if tag in ('script','style'):self.skip=max(0,self.skip-1)
        elif tag in ('p','div','h1','h2','h3','article','section','tr'):self.parts.append('\n')
    def handle_data(self,value):
        if not self.skip:self.parts.append(value)

def docx_content(path):
    with ZipFile(path) as z:
        info=z.getinfo('word/document.xml')
        if info.file_size>12_000_000:raise ValueError('Word正文过大')
        root=ET.fromstring(z.read(info))
    paras=[];tables=[]
    def text(node):return ''.join(t.text or '' for t in node.findall('.//w:t',NS))
    for node in root.find('w:body',NS):
        if node.tag.endswith('}p'):
            value=text(node).strip()
            if value:paras.append({'id':'P'+str(len(paras)+1),'text':value})
        elif node.tag.endswith('}tbl'):
            rows=[[text(c).strip() for c in r.findall('w:tc',NS)] for r in node.findall('w:tr',NS)]
            tables.append({'id':'T'+str(len(tables)+1),'rows':rows})
    if not paras and not tables:raise ValueError('Word无可读文字；扫描或纯图片需要读图能力')
    return paras,tables

def load_card(path):
    path=Path(path);raw=path.read_bytes()
    if len(raw)>30_000_000:raise ValueError('文件过大，请提供单张客群卡')
    suffix=path.suffix.lower()
    if suffix=='.json':
        value=json.loads(raw)
        if not isinstance(value,dict):raise ValueError('客群卡JSON必须是对象')
        return value
    if suffix=='.docx':
        paras,tables=docx_content(path);texts=[p['text'] for p in paras]
        joined='\n'.join(texts)+'\n'+'\n'.join(' '.join(row) for t in tables for row in t['rows'])
        result={'mode':'fictional_demo' if '虚构' in joined else 'reported','paragraphs':paras,'tables':tables}
        for table in tables:
            rows=table['rows']
            if len(rows)==7 and len(rows[0])==3 and rows[0][0]=='维度':
                result['dimensions']=[{'id':IDS[i],'title':r[0],'main':r[1],'detail':r[2]} for i,r in enumerate(rows[1:])]
                break
        summary=next((t for t in texts if t.startswith(('我的目标用户客群是','我的计划目标用户客群是'))),None)
        if summary:result['summary']=summary
        index=next((i for i,t in enumerate(texts) if re.fullmatch(r'01\s*客户是谁',t)),None)
        if index and index>0:result['business']=texts[index-1]
        groups={};kind=None;current=None
        for t in texts:
            if re.fullmatch(r'02\s*客户想要什么',t):kind='need';current=None;continue
            if re.fullmatch(r'03\s*客户担心什么',t):kind='concern';current=None;continue
            if not kind:continue
            match=re.match(r'^(0[1-9]|10)\s+(.+)$',t)
            if match:
                current='NC'+match.group(1);groups.setdefault(current,{'id':current,'basis':'candidate'})[kind+'_title']=match.group(2)
            elif current:
                key=kind+'_detail';groups[current][key]=groups[current].get(key,'')+t
        keys=('need_title','need_detail','concern_title','concern_detail')
        if len(groups)==10 and all(all(k in v for k in keys) for v in groups.values()):
            result['pairs']=[groups['NC%02d'%i] for i in range(1,11)]
        return result
    if suffix in ('.html','.htm'):
        parser=VisibleText();parser.feed(raw.decode('utf-8-sig'))
        lines=[s.strip() for s in ''.join(parser.parts).splitlines() if s.strip()]
    elif suffix in ('.txt','.md'):
        lines=[s.strip() for s in raw.decode('utf-8-sig').splitlines() if s.strip()]
    else:raise ValueError('脚本只读JSON DOCX HTML TXT MD；图片或旧DOC需环境读图或用户转存，不自动安装')
    return {'mode':'fictional_demo' if any('虚构' in t for t in lines) else 'reported',
            'paragraphs':[{'id':'P'+str(i+1),'text':t} for i,t in enumerate(lines)]}

def main():
    p=argparse.ArgumentParser();p.add_argument('card');p.add_argument('--out',required=True);a=p.parse_args()
    data=load_card(a.card);out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'normalized':str(out),'input':Path(a.card).name,'sha256':hashlib.sha256(Path(a.card).read_bytes()).hexdigest(),
                      'dimensions':len(data.get('dimensions',[])),'pairs':len(data.get('pairs',[]))},ensure_ascii=False))

if __name__=='__main__':main()
