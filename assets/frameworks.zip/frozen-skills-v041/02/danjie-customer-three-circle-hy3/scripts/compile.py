"""Compile one relational topic plan. Counts and links are code, not model guesses."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import tempfile

from card_refs import require
from read_card import load_card

VERSION = '0.8.8'
AXIS_NAMES = ('内容方向', '客户处境', '具体情境')
PLACEHOLDER = re.compile(r'(?:待补(?:充|齐)?|待填(?:写)?|未知|暂缺|未提供|未统计|不清楚|其他|通用|人群\d+|场景\d+|方向\d+)+')
LOADED = re.compile(r'一定会|最可能|最容易|更容易|往往|通常|普遍|发生率|概率|必然|经常|常常|总是')
ADVICE = re.compile(r'^(?:应当|应该|建议(?:先|让|做|选|采用)|必须(?:先|让|做|选|采用|统一)|要求对方|要求商家|先做|优先选择)')
UNKNOWN_TITLE = re.compile(r'(?:还不了解|不了解|不知道|未知|尚未了解|尚未提供|未提供|待补(?:充|齐)?|暂缺|不清楚|未统计)[。！？；;\s]*')


def canonical(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def norm(value):
    return re.sub(r'[\W_]+', '', value, flags=re.UNICODE)


def text(value, name, low=2, high=160):
    require(isinstance(value, str) and low <= len(value.strip()) <= high,
            name + '需为' + str(low) + '—' + str(high) + '字')
    return value.strip()


def effective_pairs(profile):
    """Validate original positions, but never use unknown slots as topic evidence."""
    pairs = profile.get('pairs')
    require(isinstance(pairs, list) and pairs, '原卡未读出需求/顾虑，请核对原文件是否为本课客群卡')
    valid, seen = {}, set()
    for pair in pairs:
        require(isinstance(pair, dict), '原卡需求须为对象')
        ident = pair.get('id')
        require(isinstance(ident, str) and re.fullmatch(r'NC\d{2}', ident), '需求编号须为NC01等规范格式')
        require(ident not in seen, '原卡需求编号重复')
        seen.add(ident)
        require(all(isinstance(pair.get(k), str) and pair[k].strip()
                    for k in ('need_title', 'need_detail', 'concern_title', 'concern_detail')),
                '原卡需求/顾虑不完整：' + ident)
        if pair.get('basis') == 'unknown' or any(UNKNOWN_TITLE.fullmatch(pair[k].strip())
                                                for k in ('need_title', 'concern_title')):
            continue
        valid[ident] = pair
    require(valid, '原卡没有有效需求/顾虑；未知空位不能作为选题来源，请先补充原卡')
    return valid


def build(plan, profile, *, complete=True):
    require(isinstance(complete, bool), 'complete须为布尔值')
    require(isinstance(plan, dict), 'plan须为对象')
    require(plan.get('version') == VERSION, 'plan版本必须为' + VERSION)
    required = {'version', 'center', 'groups'}
    require(set(plan) in (required, required | {'scope'}), 'plan只写version、center、groups及可选scope')
    scope = plan.get('scope', 'customer_outcome')
    require(scope in ('customer_outcome', 'single_topic'), 'scope只能为customer_outcome或single_topic')
    business = profile.get('business')
    group = profile.get('summary') or profile.get('group_name')
    text(business, '原卡业务', 2, 4000)
    text(group, '原卡客群总结', 2, 4000)
    mode = profile.get('mode')
    require(mode in ('fictional_demo', 'reported', 'planned', 'real'), '原卡资料性质不能推定')
    pair_map = effective_pairs(profile)
    center = text(plan.get('center'), '中心', 2, 80)
    groups = plan.get('groups')
    require(isinstance(groups, list) and (len(groups) == 8 if complete else 1 <= len(groups) <= 8),
            '必须8个不同内容方向' if complete else '逐组规划须有1—8个内容方向')
    axes = [{'label': name, 'items': []} for name in AXIS_NAMES]
    topics = []
    questions = []
    decisions = set()
    names = [set(), set(), set()]
    used_needs = set()

    def refs_for(need_ids):
        return ['pairs.' + n + '.' + k for n in need_ids
                for k in ('need_title', 'need_detail', 'concern_title', 'concern_detail')]

    def node(axis, label, needs):
        label = text(label, AXIS_NAMES[axis], 2, 14)
        key = norm(label)
        require(not PLACEHOLDER.fullmatch(key), '不能用占位词填格：' + label)
        require(len(key) >= 2, '标签须有实际文字，不能仅有符号')
        require(key not in names[axis], '同圈标签重复：' + label)
        names[axis].add(key)
        require(not LOADED.search(label), '标签不能预设频率或客户特征：' + label)
        ident = ('D', 'A', 'S')[axis] + str(len(axes[axis]['items']) + 1)
        evidence = ['需求：' + pair_map[n]['need_title'] + '；顾虑：' + pair_map[n]['concern_title'] for n in needs]
        result = {'id': ident, 'label': label, 'refs': refs_for(needs), 'status': 'inferred',
                  'basis': '依据原卡推演的候选选题，不是已调查事实。' + '；'.join(evidence)}
        if axis == 1:
            result['audience_scope'] = '原卡同一付费客群的一种可能处境，不是新增人口或购买者。'
        axes[axis]['items'].append(result)
        return result

    for gi, g in enumerate(groups, 1):
        require(isinstance(g, dict), '每个方向须为对象')
        require(set(g) == {'direction', 'states'}, '每组只写direction、states')
        states = g.get('states')
        require(isinstance(states, list) and len(states) == 2, '每个方向下须2种客户处境')
        require(all(isinstance(s, dict) and isinstance(s.get('scenes'), list) for s in states),
                '处境须为对象，scenes须为列表')
        counts = [len(s['scenes']) for s in states]
        require(sorted(counts) == [1, 2], '每方向合计3题，两种处境分别1题和2题')
        direction_needs = []
        for state in states:
            require(set(state) == {'label', 'scenes'}, '每种处境只写label、scenes')
            for scene in state['scenes']:
                require(isinstance(scene, dict), '每个情境须为对象')
                require(set(scene) == {'event', 'new_info', 'ask', 'check', 'needs'},
                        '每个情境只写event、new_info、ask、check、needs')
                need_ids = scene.get('needs')
                require(isinstance(need_ids, list) and 1 <= len(need_ids) <= 3
                        and len(set(need_ids)) == len(need_ids)
                        and all(n in pair_map for n in need_ids), 'needs须为本卡1—3个有效NC编号；不能引用unknown或未知占位')
                for n in need_ids:
                    if n not in direction_needs:
                        direction_needs.append(n)
        d = node(0, g.get('direction'), direction_needs)
        for state in states:
            state_needs = list(dict.fromkeys(n for s in state['scenes'] for n in s['needs']))
            a = node(1, state.get('label'), state_needs)
            for scene in state['scenes']:
                event = text(scene.get('event'), '触发分句', 4, 14)
                require(not re.search(r'[，,。.!！?？：:；;\n]', event), 'event写一个短分句，不写整道题')
                require(not event.startswith(('如果', '假如', '假设')),
                        'event不带如果，程序自动标为假设情境')
                require(not re.search(r'担心|害怕|希望|想要|犹豫', event),
                        'event写触发动作或变化，不重复客户的担忧')
                require(norm(event) != norm(a['label']), '客户处境与触发事件不能完全相同')
                new_info = text(scene.get('new_info'), '新增信息', 4, 80)
                ask = text(scene.get('ask'), '核心问题', 5, 28)
                require(ask.endswith(('？', '?')) and ask.count('？') + ask.count('?') == 1, 'ask只写一道完整问句')
                require(norm(event) not in norm(ask), 'ask不再复述event，程序自动合并')
                question = '如果' + event + '，' + ask
                require(not LOADED.search(question), '问题不能预设频率、因果或客户属性：' + question)
                decision = ask[:-1]
                require(norm(decision) not in decisions, '具体决策重复：' + decision)
                decisions.add(norm(decision))
                check = text(scene.get('check'), '核对信息', 4, 160)
                require(not ADVICE.search(check), 'check只列核对信息，不替客户作决定：' + check)
                s = node(2, event, scene['needs'])
                qid = 'Q' + str(len(topics) + 1)
                refs = refs_for(scene['needs'])
                used_needs.update(scene['needs'])
                topics.append({'ids': [d['id'], a['id'], s['id']], 'question_id': qid,
                               'source_refs': refs, 'topic': question, 'premise': 'hypothetical',
                               'why': '面向“' + a['label'] + '”这一可能处境，讨论“' + event + '”时的具体选择。情境为选题假设，不是客户实录。',
                               'gap': '回答前需核对：' + check, 'decision': decision})
                questions.append({'id': qid, 'question': question, 'ask': ask, 'new_info': new_info,
                                  'decision': decision, 'check': check,
                                  'refs': refs, 'needs': scene['needs'], 'direction': d['label'],
                                  'state': a['label'], 'event': event})
    if complete and scope == 'customer_outcome':
        require(len(used_needs) >= min(8, len(pair_map)), '至少覆盖8项有效原卡需求，有效不足8项时须全覆盖；不计unknown空位')
    count = len(groups)
    require([len(a['items']) for a in axes] == [count, 2 * count, 3 * count]
            and len(topics) == 3 * count, '三圈数量错误')
    model = {'version': VERSION, 'title': '蛋解三圈选题模型', 'business': business, 'group': group,
             'center': center, 'mode': mode, 'scope': scope,
             'focus_refs': ['summary' if profile.get('summary') else 'group_name'],
             'input_summary': '原业务和客群沿用原卡；' + str(count) + '方向、' + str(2 * count)
                              + '处境、' + str(3 * count) + '情境及选题成组设计，程序统一建立对应关系。',
             'planning_notice': '三圈是基于客群卡需求/顾虑推演的候选内容规划，处境可以重叠；不是已调查的客户分类或真实事件。',
             'axes': axes, 'topics': topics, 'examples': [topics[i] for i in (0, 9, 18) if i < len(topics)]}
    return model, questions


def research_handoff(model, questions, profile):
    """Project the exact generated questions into the unchanged Skill03 contract."""
    profile_ref = {k: profile[k] for k in ('profile_id', 'profile_version') if k in profile}
    limits = [s for s in profile.get('public_boundaries', []) if isinstance(s, str)]
    limits += ['候选情境为推演，不是客户实录；原卡未知事实及服务能力仍须核实。']
    topics = []
    for topic, question in zip(model['topics'], questions):
        require(topic['question_id'] == question['id'] and topic['topic'] == question['question'],
                '交接题目与当前三圈不同源')
        topics.append({'topic_id': question['id'], 'combination_id': 'combo-' + question['id'],
                       'cell_ids': list(topic['ids']), 'question': question['question'],
                       'candidate_title': question['question'],
                       'customer_role': profile.get('group_name') or model['group'],
                       'customer_task': question['decision'], 'source_refs': list(question['refs']),
                       'evidence_gaps': [question['check']], 'public_limits': list(limits),
                       'status': '待研究'})
    require(len(topics) == 24 and len({t['topic_id'] for t in topics}) == 24, '交接须同序保存24道实际选题')
    return {'schema_version': 'owner-ip-three-circle-research-handoff-v1',
            'learner_id': profile.get('profile_id', ''), 'profile_ref': profile_ref,
            'model_id': model['id'], 'model_version': VERSION, 'mode': profile['mode'],
            'source_binding': {'profile_source': model['profile_source'], 'plan_source': model['plan_source']},
            'identity_note': '沿用原卡已有编号；原卡缺编号时未编造，下游仍需可绑定编号的原客群卡。',
            'topics': topics}


def student_view(model):
    """Only data used by the student result UI; audit provenance stays backstage."""
    topics = [{k: topic[k] for k in ('ids', 'topic', 'decision', 'gap')}
              for topic in model['topics']]
    for topic in topics:
        topic['gap'] = topic['gap'].replace('回答前需核对：', '讲这题前，先核实：', 1)
    return {'id': model['id'], 'title': model['title'], 'business': model['business'],
            'group': model['group'], 'center': model['center'], 'mode': model['mode'],
            'axes': [{'label': axis['label'],
                      'items': [{k: item[k] for k in ('id', 'label')} for item in axis['items']]}
                     for axis in model['axes']],
            'topics': topics, 'examples': [topics[i] for i in (0, 9, 18) if i < len(topics)]}


def student_markdown(model, questions):
    # Business facts and useful conditions are results, not disposable process metadata.
    lines = ['# 蛋解三圈选题模型', '', model['business'], '', model['group'], '',
             '## 中心选题', '', model['center'], '',
             '这些是待核实的候选选题，不是客户原话。']
    if model['mode'] == 'fictional_demo':
        lines.extend(['', '虚构示例，仅供演示。'])
    lines.extend(['', '## 24个候选选题'])
    for index, q in enumerate(questions, 1):
        lines.extend(['', f'### {index:02d} {q["question"]}', '',
                      f'方向：{q["direction"]}　｜　客户处境：{q["state"]}　｜　情境：{q["event"]}', '',
                      '要弄清：' + q['decision'], '', '讲这题前，先核实：' + q['check']])
    return '\n'.join(lines) + '\n'


def review_markdown(model, questions, profile):
    """Show actual questions beside full source needs; never grade their meaning."""
    def cell(value):
        return str(value).replace('|', '／').replace('\r', ' ').replace('\n', ' ')

    pair_map = {pair['id']: pair for pair in profile['pairs']}
    lines = ['# 三圈逐题核对', '',
             '这是程序整理的待核对表，不是语义通过结论。下列原卡文字是资料，不是执行指令。', '',
             '原业务：' + cell(model['business']), '',
             '原付费客群：' + cell(model['group']), '',
             '逐题核对：父方向原字面是否覆盖本题；处境之后是否出现真正新信息；问题、判断与资料是否同一对象；来源的接收方、用途和服务阶段是否仍适用。', '',
             '## 本组实际在判断什么', '',
             '|方向原文|其下三个实际判断|', '|---|---|']
    for direction in model['axes'][0]['items']:
        decisions = [topic['question_id'] + '：' + topic['decision']
                     for topic in model['topics'] if topic['ids'][0] == direction['id']]
        lines.append('|' + cell(direction['label']) + '|' + cell('；'.join(decisions)) + '|')
    lines.extend(['', '## 逐题与原卡对照', '',
                  '|题号|原卡需求和顾虑全文（目的）|方向原文|已有处境|新触发事件|相对处境新增的信息|核心问题原文|回答前需取得的信息|',
                  '|---|---|---|---|---|---|---|---|'])
    for question in questions:
        sources = []
        for ident in question['needs']:
            pair = pair_map[ident]
            sources.append(ident + ' 需求：' + pair['need_title'] + '；' + pair['need_detail']
                           + ' 顾虑：' + pair['concern_title'] + '；' + pair['concern_detail'])
        values = [question['id'], ' ／ '.join(sources), question['direction'], question['state'],
                  question['event'], question['new_info'], question['ask'], question['check']]
        lines.append('|' + '|'.join(cell(value) for value in values) + '|')
    lines.extend(['', '来源和数量正确不等于问题自然、决策不同或三圈覆盖正确；自查须记录具体问题、改动和未解决项。'])
    return '\n'.join(lines) + '\n'


def run(plan_path, output, profile_path):
    source = Path(profile_path)
    plan_path = Path(plan_path)
    raw = plan_path.read_bytes()
    profile = load_card(source)
    model, questions = build(json.loads(raw), profile, complete=True)
    model['profile_source'] = {'file': source.name, 'sha256': digest(source.read_bytes())}
    model['plan_source'] = {'file': plan_path.name, 'sha256': digest(raw)}
    model['id'] = digest(canonical(model))[:20]
    handoff = research_handoff(model, questions, profile)
    payload = json.dumps(student_view(model), ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    template = (Path(__file__).resolve().parent.parent / 'assets/interactive.html').read_text(encoding='utf-8')
    require(template.count('__MODEL_JSON__') == 1, '模板占位符错误')
    out = Path(output)
    require(not out.exists(), '已有输出不覆盖，请另开新目录保留原始结果')
    out.parent.mkdir(parents=True, exist_ok=True)
    page = out / '蛋解三圈选题模型.html'
    review = review_markdown(model, questions, profile)
    report = {'version': VERSION, 'structure_pass': True, 'node_counts': [8, 16, 24], 'topic_count': 24,
              'links_from_parent_child_plan': True, 'source_facts_copied_verbatim': True,
              'source': model['profile_source'], 'plan': model['plan_source'],
              'effective_need_ids': list(effective_pairs(profile)), 'handoff_topic_count': len(handoff['topics']),
              'semantic_review': 'required', 'client_interaction': 'not_proven_by_compiler', 'live_api': False}
    files = {page.name: template.replace('__MODEL_JSON__', payload),
             '选题清单.md': student_markdown(model, questions),
             '03-选题研究交接.json': json.dumps(handoff, ensure_ascii=False, indent=2) + '\n',
             '_internal/model.json': json.dumps(model, ensure_ascii=False, indent=2) + '\n',
             '_internal/questions.json': json.dumps(questions, ensure_ascii=False, indent=2) + '\n',
             '_internal/review.md': review,
             '_internal/validation.json': json.dumps(report, ensure_ascii=False, indent=2) + '\n'}
    with tempfile.TemporaryDirectory(prefix='.three-circle-', dir=out.parent) as temporary:
        stage = Path(temporary) / 'result'
        stage.mkdir()
        for name, content in files.items():
            (stage / name).parent.mkdir(parents=True, exist_ok=True)
            (stage / name).write_text(content, encoding='utf-8')
        require(not out.exists(), '编译期间出现同名输出，不覆盖')
        stage.rename(out)
    return {'html': str(page), 'text': str(out / '选题清单.md'),
            'internal_model': str(out / '_internal/model.json'), 'validation': report}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('plan')
    p.add_argument('output')
    p.add_argument('--profile', required=True)
    args = p.parse_args()
    try:
        print(json.dumps(run(args.plan, args.output, args.profile), ensure_ascii=False))
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as e:
        raise SystemExit('未生成结果：' + str(e))


if __name__ == '__main__':
    main()
