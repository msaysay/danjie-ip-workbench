"""Only whole source strings plus fixed classroom frames may enter learner copy."""
import json
from pathlib import Path

def need(ok,msg):
    if not ok: raise ValueError(msg)
def compile_content(d,receipt):
    need('endings' not in d and 'cards' not in d,'0.2.0不接受自由编写的结尾/摘要；请给原句引用')
    originals={c['role']:c for c in receipt['cards']}
    extra=None
    if d.get('owner_answers_file'):
        p=Path(d['owner_answers_file']).resolve(); text=p.read_text(encoding='utf-8')
        rows=json.loads(text)
        need(isinstance(rows,dict) and isinstance(rows.get('answers'),list),'原答文件格式错误')
        need(len(rows['answers'])<=5,'只补最多五个实际问题，不能超额补采访')
        need(all(isinstance(v.get('question'),str) and v['question'].strip() and isinstance(v.get('answer'),str) for v in rows['answers']),'须保存实际题目与完整原答')
        extra={'text':text,'path':str(p)}
    def q(ref):
        need(isinstance(ref,dict),'须引用原句，不可自由改写')
        role=ref.get('role')
        need(role in originals or role=='answer' and extra is not None,'不是本次四卡或本次实际原答')
        record=extra if role=='answer' else originals[role]
        try: obj=json.loads(record['text'])
        except json.JSONDecodeError:
            quote=ref.get('quote','');need(quote.strip() and quote in record['text'].splitlines(),'文字资料须完整一行引用');return quote
        ptr=ref.get('pointer');need(isinstance(ptr,str) and ptr.startswith('/'),'JSON引用须有字段路径')
        for token in ptr[1:].split('/'):
            if isinstance(obj,dict): need(obj.get('restricted') is not True,'受限原答不能进入结尾')
            key=token.replace('~1','/').replace('~0','~')
            obj=obj[int(key)] if isinstance(obj,list) else obj[key]
        need(isinstance(obj,str) and obj.strip() and obj==ref.get('quote'),'须保留完整原文字段，不能改条件或截句')
        need(len(obj)<=650,'该字段过长，请本人提供保留完整条件的短版')
        return obj
    refs=d.get('quotes',{})
    business=q(refs['business']);topic=q(refs['topic']);claim=q(refs['claim'])
    identity=q(refs['identity']) if refs.get('identity') else ''
    action=q(refs['action']) if refs.get('action') else ''
    need(d.get('mode') in ('real','fictional_demo'),'须标真实或虚构')
    modes=[c['text'] for c in receipt['cards'] if '"fictional_demo"' in c['text']]
    need(not modes or d['mode']=='fictional_demo','虚构原卡不能升级为真人')
    cards=[]
    for role,title in [('audience','目标客群'),('hook','当头一棒'),('proof','以理服人'),('ability','亮出绝活')]:
        ref=d.get('summary_refs',{}).get(role)
        cards.append({'title':title,'summary':q(ref) if ref else '已读取本次原卡；没有适合直接公开引用的简短内容，暂不另写摘要。'})
    raw=d.get('service',{});service={'currently_open':False,'entry_public_confirmed':False}
    entryready=False
    if raw.get('currently_open') is True and raw.get('entry_public_confirmed') is True:
        for key in ('offering','first_step','entry','open_confirmation','public_confirmation'):
            service[key]=q(raw[key])
        service.update(currently_open=True,entry_public_confirmed=True);entryready=True
    def ending(kind,purpose,text,gap,facts):
        return {'kind':kind,'ready':bool(text),'purpose':purpose,'text':text,'gap':gap if not text else '', 'facts':facts if text else []}
    ends=[
        ending('entry','让真正有需要的人知道从哪里开始',
            '如果你需要了解这项服务，入口是：'+service['entry']+'\n第一步：'+service['first_step'] if entryready else '',
            '需要本人确认当前开放的服务、第一步和允许公开的入口；没有就先不做邀请。',
            [{'label':'服务原话','value':service.get('offering','')}] if entryready else []),
        ending('action','让观众执行本人明确的一步',
            '看完先做这一步：'+action if action else '',
            '你希望观众现在实际核对或准备哪一步？请本人给一句具体原话。',
            [{'label':'当前判断','value':claim}]),
        ending('summary','收回本人已选的判断，不增加原因或保证',
            '最后记住这句判断：'+claim,'',[]),
        ending('memory','用本人的业务原话留下记忆',
            identity if identity else '',
            '请补一句本人的身份与实际职责，不替你编口号。',[]),
        ending('question','听到本题还没有问清的部分',
            '关于“'+topic+'”，你还有哪一步想问清楚？','',[])
    ]
    recommended=d.get('recommended','summary')
    need(recommended in ('entry','action','summary','memory','question'),'推荐类型错误')
    result={'mode':d['mode'],'business':business,'topic':topic,'recommended':recommended,'cards':cards,'service':service,'endings':ends}
    # Original answer file is preserved for audit, never exposed as learner data.
    if extra: result['_owner_answers_source']=extra['path']
    return result
