#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Read four explicitly provided source files, preserving bytes and scope where supplied."""
import argparse,json,hashlib
from pathlib import Path
ROLES=('audience','hook','proof','ability')
CARD_TYPES={
 'audience':{'audience'},
 'hook':{'hook','danjie-opening-selection'},
 'proof':{'proof'},
 'ability':{'ability','muscle-words'},
}
def read_cards(paths):
 if set(paths)!=set(ROLES):raise ValueError('须指定客群、当头一棒、以理服人、亮出绝活四个原始文件')
 rows=[];scopes=[]
 for role in ROLES:
  p=Path(paths[role]).resolve()
  if not p.is_file():raise ValueError('找不到原卡：'+role)
  raw=p.read_bytes()
  try:text=raw.decode('utf-8')
  except UnicodeDecodeError:raise ValueError('图片或二进制卡请由宿主视觉读取，不假称脚本已读')
  if not text.strip():raise ValueError('原卡为空：'+role)
  scope=None
  if p.suffix.lower()=='.json':
   obj=json.loads(text)
   if isinstance(obj,dict):
    scope=obj.get('scope')
    if obj.get('card_type') and obj['card_type'] not in CARD_TYPES[role]:raise ValueError('卡片类型与指定角色不符：'+role)
  if scope is not None:
   if not isinstance(scope,dict) or any(not scope.get(k) for k in ('owner','topic')):raise ValueError('有scope时需明确所属人与本题')
   scopes.append((scope['owner'],scope['topic']))
  rows.append({'role':role,'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'text':text,'scope':scope})
 if len(set(scopes))>1:raise ValueError('四卡所属人物或本题不一致，停止串卡')
 return {'cards':rows,'scope_check':'matched' if len(scopes)==4 else 'needs_semantic_review','limitation':'文件读取及已声明scope核对；不证明事实真实性，非结构化原卡需AI核对同一客户与观点'}
def main():
 ap=argparse.ArgumentParser()
 for k in ROLES:ap.add_argument('--'+k,required=True)
 ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
 try:
  d=read_cards({k:getattr(a,k) for k in ROLES})
  if a.out.exists():raise ValueError('读取记录已有文件，另用新路径保留原证据')
  a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(d,ensure_ascii=False,indent=2));print(json.dumps(d,ensure_ascii=False,indent=2))
 except (OSError,ValueError,TypeError) as e:ap.exit(2,'未完成：'+str(e)+'\n')
if __name__=='__main__':main()
