#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Normal in-sandbox entry: read a job, then bind/export an authored draft."""
import json
import hashlib
import sys
from pathlib import Path
from read_cards import read_cards
from compile_quotes import compile_content
import render

def prepare(job_path):
    job = json.loads(Path(job_path).read_text(encoding='utf-8'))
    receipt = Path(job['receipt']).resolve()
    if receipt.exists():
        raise ValueError('读取记录已存在，请保留并使用新的本轮路径')
    result = read_cards(job['source_files'])
    receipt.parent.mkdir(parents=True, exist_ok=True)
    receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print('请用Read完整读取四份原文：' + str(receipt))

def export(draft_path, receipt_path, out_path):
    draft = json.loads(Path(draft_path).read_text(encoding='utf-8'))
    receipt = json.loads(Path(receipt_path).read_text(encoding='utf-8'))
    cards = receipt['cards']
    sources = {c['role']: c['path'] for c in cards}
    hashes = {c['role']: c['sha256'] for c in cards}
    current = read_cards(sources)
    if current != receipt:
        raise ValueError('原四卡或读取记录已变化，停止生成')
    draft = compile_content(draft, receipt)
    if draft.get('_owner_answers_source'):
        draft['_owner_answers_sha256'] = hashlib.sha256(Path(draft['_owner_answers_source']).read_bytes()).hexdigest()
    out = Path(out_path).resolve()
    if out.exists():
        raise ValueError('结果目录已存在，请保留并使用新路径')
    draft['source_files'] = sources
    draft['source_hashes'] = hashes
    render.validate(draft)
    bound = Path(draft_path).with_name(Path(draft_path).stem + '-bound.json')
    if bound.exists():
        raise ValueError('已绑定稿件存在，不覆盖')
    bound.write_text(json.dumps(draft, ensure_ascii=False, indent=2), encoding='utf-8')
    sys.argv = ['render.py', '--input', str(bound), '--out', str(out)]
    render.main()

if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == 'prepare':
        prepare(sys.argv[2])
    elif len(sys.argv) == 5 and sys.argv[1] == 'export':
        export(*sys.argv[2:])
    else:
        raise SystemExit('prepare JOB.json | export DRAFT.json RECEIPT.json NEW_RESULT_DIR')
