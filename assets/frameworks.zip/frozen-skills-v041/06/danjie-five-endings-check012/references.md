# 原话锁定数据合同 · 0.2.2

draft根字段：
mode=real或fictional_demo；recommended=entry/action/summary/memory/question；quotes；summary_refs（可空）；service（可空）；owner_answers_file（补问时实际原答路径）。

quotes包含business/topic/claim，另可有identity/action。各值为引用对象，不是直接字符串：
{role:audience或hook或proof或ability或answer,pointer:JSON完整字段路径,quote:完整原句}
role=answer只能指本轮owner_answers_file。该文件为{answers:[{question:实际题目,answer:完整实际原答,restricted:false}]}，最多五条。引用pointer如/answers/0/answer。受限整条不引用；不能给旧回答改名冒充这轮。

JSON引用必须与该字段的完整字符串逐字一致；不取子串，不去掉否定/条件/责任范围。文字资料须完整一行，不复制JSON转成TXT绕过完整字段验证。引用过长就换适合的完整字段或请本人给短版，不自动浓缩。

summary_refs可按audience/hook/proof/ability各选一段适合公开的原文，不填ID、SHA、内部状态、方法枚举或审核元数据。没有适当句子就省略，由程序给中性占位，不让AI自由概括。以理服人的取材建议不是已证实结果，不引用它推断本人的效果。

service仅在实际确认后提供currently_open=true、entry_public_confirmed=true，及offering/first_step/entry/open_confirmation/public_confirmation五个引用。后两项引用支持开放与公开许可的完整原答，不以AI自填true当本人确认。缺任何项就先留空邀请分支；不影响其余四种。

entry和first_step是前台文案引用；open_confirmation/public_confirmation仅作后台授权依据，不拼进文案。访谈时前台原句与授权必须分题记录，原句题让本人直接回答要展示的那一句。不能把一段含授权、测试或执行要求的混合原答整段当公开入口；也不能截掉条件，必要时用剩余题请本人重新给完整短句。

程序生成五段text/purpose/facts与四摘要，拒绝旧draft里的自由endings/cards。所有新文案常量在编译器内；模型不另写hint、payoff或总结理由。原话引用仍需人工对照主题和公开边界，机械完整匹配不是事实真实性证明。

输出：HTML和同文MD，backend绑定原四卡路径/SHA与原答来源，用来审计，不显示在页面。引用本轮真实来源，生成后不倒改原卡或原答。原生另存与脚本出文件分别记录。

生成运行到正常附件交付为止；出厂人工点击验收不派给运行模型。不得额外安装/启动浏览器或自动测试工具，不启动HTTP，不对浏览器目录进行删除或清理；遇拦截原错停止。
