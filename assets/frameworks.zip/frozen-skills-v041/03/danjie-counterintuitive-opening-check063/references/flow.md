# 0.8.0 十题三法候选契约

0.8.1只加生成与语义复核要求，不改0.8.0数据契约、脚本、CSS或已生成结果。为每对候选在后台核对“谁/什么对象—做什么—哪个结果—比较强度”：必要法去掉的是同一必要门槛；标准法改的是同一选择的评价标准；结果法挑战的是同一结果关系。“越多越好”“多就一定好”不是同一命题，不能拿否定后者冒充已经反转前者。记录具体不一致项后只做有据局部修订，保留首版；不靠次数、关键词或自评宣布全行业通过。修过AI原认知也仍是待确认假设，不是客户原话。

这版取消生成前的一句原认知确认门槛，改为每题每法各自的AI候选原认知。旧确认记录和071/072成品保留，不伪装为本版30条都已获确认。

prepare仍校同学员、同版本和输入SHA，原顺序取前10题。plan只含run_binding、default_topic、default_method、topics；topics顺序及topic_id必须与normalized一致，每题只写topic_id和approaches。

每个approaches恰含necessary_condition、selection_standard、result_direction。每法恰含old_cognition（4—180字）、opening（4—60字单一主判断）、conditions（字符串，无新增限制用空串）。不接受空答案或用户确认true之类自造字段。status=candidate、old_cognition_origin=ai_proposed与候选标记由脚本统一生成。

例如只示一题的结构（实际必须10题）：

```json
{"run_binding":"实际normalized值","default_topic":"原题ID","default_method":"selection_standard","topics":[
  {"topic_id":"原题ID","approaches":{
    "necessary_condition":{"old_cognition":"同题必要条件练习假设","opening":"否定同一必要条件的候选","conditions":""},
    "selection_standard":{"old_cognition":"同题旧选择标准练习假设","opening":"旧标准与新标准都可见的候选","conditions":""},
    "result_direction":{"old_cognition":"同题A会带来B的练习假设","opening":"挑战同一结果关系的候选","conditions":""}
  }}
]}
```

只示格式，不照抄内容。各法原认知可以不同，但同题购买对象、使用者和决策不能换掉。conditions只记录本条额外的假设/限定，不写客户已真实如此；影响结论的条件也保留在opening中。

build重新核输入与计划，生成不可混入旧版本的model_id；HTML本地状态按model_id隔离。模型、计划与normalized的路径和SHA绑定；select重新编译期望模型后比较，不接收独立改过的开场/原认知或串卡数据。

select必须有新原回复同时包含“确认”、选题编号或原题、方法中文名、完整old_cognition和完整opening。采用AI假设不等于验证共识；输出仍标ai_proposed。内部记录源路径、SHA与编号不进入学员文案。程序只能做技术防错，不能证明选中的内容在真实行业正确。
