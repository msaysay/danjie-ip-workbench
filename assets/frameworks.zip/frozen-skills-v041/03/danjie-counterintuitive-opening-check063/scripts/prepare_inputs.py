#!/usr/bin/env python3
"""Input normalization helpers; no generation and no confirmation defaults."""
import hashlib
import json
import re
from pathlib import Path


TOPIC_KEYS = ("topics", "candidates", "items", "research_topics", "research_tasks")
TITLE_KEYS = ("candidate_title", "topic", "title", "question", "problem")


def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"无法读取JSON {path}: {exc}") from exc


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_digest(value):
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def text(value):
    return value.strip() if isinstance(value, str) else ""


def first(obj, keys):
    for key in keys:
        value = text(obj.get(key))
        if value:
            return value
    return ""


def as_list(value):
    if isinstance(value, list):
        return [text(x) for x in value if text(x)]
    if text(value):
        return [text(value)]
    return []


def find_three_circle(path):
    if path.is_file():
        return path
    if not path.is_dir():
        raise ValueError(f"三圈路径不存在: {path}")
    preferred = path / "03-选题研究交接.json"
    if preferred.exists():
        return preferred
    candidates = sorted(path.glob("*选题研究交接*.json"))
    if len(candidates) == 1:
        return candidates[0]
    raise ValueError("三圈目录缺少唯一的03-选题研究交接.json；不要改用只有3条combinations的model.json")


def normalize_customer(raw):
    card = raw.get("customer_profile") if isinstance(raw, dict) and isinstance(raw.get("customer_profile"), dict) else raw
    if not isinstance(card, dict):
        raise ValueError("目标客群卡根对象必须为JSON对象")
    pid = first(card, ("profile_id", "audience_id", "customer_profile_id"))
    if not pid:
        raise ValueError("目标客群卡缺少profile_id")
    version = card.get("profile_version", card.get("version"))
    if not isinstance(version, (int, str)) or not str(version).strip():
        raise ValueError("目标客群卡缺少profile_version")
    pairs = []
    for index, item in enumerate(card.get("pairs") or card.get("needs_and_concerns") or []):
        if not isinstance(item, dict):
            continue
        pair = {
            "id": first(item, ("id", "pair_id")) or f"NC{index+1:02d}",
            "need": first(item, ("need_title", "need", "need_detail")),
            "concern": first(item, ("concern_title", "concern", "concern_detail")),
            "basis": first(item, ("basis", "status", "verification_status")) or "unknown",
            "source_ids": as_list(item.get("source_ids") or item.get("source_refs")),
        }
        if pair["need"] or pair["concern"]:
            pairs.append(pair)
    context = card.get("business_context") if isinstance(card.get("business_context"), dict) else {}
    roles = context.get("roles") if isinstance(context.get("roles"), dict) else card.get("roles")
    return {
        "schema_version": text(card.get("schema_version")) or "unknown",
        "profile_id": pid,
        "profile_version": version,
        "mode": first(card, ("mode",)) or "real",
        "status": first(card, ("status",)) or "unknown",
        "business": first(card, ("business", "offering")),
        "group_name": first(card, ("group_name", "customer_group", "target_user")),
        "summary": first(card, ("summary",)),
        "roles": roles if isinstance(roles, dict) else {},
        "role_context": first(context, ("role_context",)),
        "pairs": pairs,
        "unknowns": as_list(card.get("unknowns")),
        "public_boundaries": as_list(card.get("public_boundaries")),
    }


def topic_array(raw):
    if isinstance(raw, list):
        return raw
    if not isinstance(raw, dict):
        return []
    for key in TOPIC_KEYS:
        if isinstance(raw.get(key), list):
            return raw[key]
    return []


def normalize_topic(item, index, fallback_role):
    if not isinstance(item, dict):
        raise ValueError(f"第{index+1}条三圈选题不是对象")
    label = first(item, TITLE_KEYS)
    if not label:
        raise ValueError(f"第{index+1}条三圈选题缺少完整标题")
    tid = first(item, ("topic_id", "id")) or f"topic-{index+1:02d}"
    cid = first(item, ("combination_id", "combo_id")) or f"combo-{index+1:02d}"
    cell_ids = item.get("cell_ids") or item.get("ids")
    if not isinstance(cell_ids, list):
        cell_ids = [item.get(k) for k in ("direction_id", "audience_id", "scene_id") if text(item.get(k))]
    cell_ids = [text(x) for x in cell_ids if text(x)]
    return {
        "id": tid,
        "combination_id": cid,
        "cell_ids": cell_ids,
        "label": label,
        "question": first(item, ("question", "problem")) or label,
        "customer_role": first(item, ("customer_role", "audience", "target_role")) or fallback_role,
        "customer_task": first(item, ("customer_task", "task", "decision_task")) or label,
        "source_refs": as_list(item.get("source_refs") or item.get("sources")),
        "evidence_gaps": as_list(item.get("evidence_gaps") or item.get("missing_evidence") or item.get("claims_to_verify")),
        "public_limits": as_list(item.get("public_limits") or item.get("public_boundaries")),
        "upstream_status": first(item, ("status",)) or "待研究",
    }


def safe_id(value):
    value = re.sub(r"[^0-9A-Za-z_-]+", "-", value).strip("-")
    return value[:48] or "learner"
