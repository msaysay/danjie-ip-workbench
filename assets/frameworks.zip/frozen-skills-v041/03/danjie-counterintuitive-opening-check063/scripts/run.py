#!/usr/bin/env python3
"""Ten topics x three AI-proposed cognition/opening pairs; explicit later adoption."""
import argparse
import base64
import copy
import json
import re
from pathlib import Path
from prepare_inputs import (read_json, digest, canonical_digest, normalize_customer,
                            normalize_topic, topic_array, find_three_circle)

SCHEMA='danjie-opening-candidates-v080'
METHODS={
    'necessary_condition':('推翻必要条件','有A，才能做B','做B，不必有A'),
    'selection_standard':('翻转选择标准','选X，先看A','选X，别先看A，先看B'),
    'result_direction':('翻转结果方向','原来认为A会带来B','A不等于B'),
}


def need(ok,message):
    if not ok:
        raise ValueError(message)


def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def verify_normalized(n):
    need(n.get('schema_version')==SCHEMA,'不是本版十题三法输入')
    identity={k:n[k] for k in ('schema_version','mode','profile_ref','three_circle_ref','input_hashes','customer_context','topics')}
    need(n['run_binding']==canonical_digest(identity),'输入绑定已变化，需重新prepare')
    for key,path in n['input_files'].items():
        need(digest(Path(path))==n['input_hashes'][key+'_sha256'],'原始输入已变化，不能继续')


def prepare(args):
    customer_path=Path(args.customer).resolve()
    customer=normalize_customer(read_json(customer_path))
    circle_path=find_three_circle(Path(args.three_circle).resolve())
    circle=read_json(circle_path);ref=circle.get('profile_ref',{})
    need(ref.get('profile_id')==customer['profile_id'],'三圈与客群卡ID不一致')
    need(str(ref.get('profile_version'))==str(customer['profile_version']),'三圈与客群卡版本不一致')
    items=topic_array(circle);need(len(items)>=10,'三圈不足10题，不在此补造')
    topics=[normalize_topic(t,i,customer['group_name']) for i,t in enumerate(items[:10])]
    need(len({t['id'] for t in topics})==10,'原选题ID重复')
    n=dict(schema_version=SCHEMA,mode='fictional_demo' if 'fictional_demo' in (customer['mode'],circle.get('mode')) else 'real',
        profile_ref=dict(profile_id=customer['profile_id'],profile_version=customer['profile_version']),
        three_circle_ref=dict(model_id=circle.get('model_id'),model_version=circle.get('model_version'),upstream_topic_count=len(items)),
        input_hashes=dict(customer_sha256=digest(customer_path),three_circle_sha256=digest(circle_path)),
        customer_context=customer,topics=topics)
    n['run_binding']=canonical_digest(n)
    n['input_files']=dict(customer=str(customer_path),three_circle=str(circle_path))
    out=Path(args.out)
    need(not (out/'normalized-input.json').exists(),'已有输入不覆盖，请使用新目录')
    write(out/'normalized-input.json',n)
    print(json.dumps(dict(normalized=str(out/'normalized-input.json'),run_binding=n['run_binding'],topics=[t['label'] for t in topics]),ensure_ascii=False))


def public_text(value,name,low,high):
    need(isinstance(value,str) and low<=len(value.strip())<=high,name+'字数或类型不正确')
    value=value.strip()
    need(not re.search(r'(?<![A-Za-z0-9])(?:NC|Q)\d+|topic-\d+|sha256|\.json|\.py|/Users/|run_binding',value,re.I),name+'含内部技术标识')
    return value


def build_model(n,p,binding):
    verify_normalized(n)
    need(set(p)=={'run_binding','default_topic','default_method','topics'},'plan字段不完整或有未知字段')
    need(p['run_binding']==n['run_binding'],'plan属于另一输入')
    need(isinstance(p['topics'],list) and [t.get('topic_id') for t in p['topics']]==[t['id'] for t in n['topics']],'必须按原顺序填写10题')
    need(p['default_topic'] in [t['id'] for t in n['topics']] and p['default_method'] in METHODS,'默认位置不在本次候选中')
    topics=[];openings=set()
    for source,row in zip(n['topics'],p['topics']):
        need(set(row)=={'topic_id','approaches'},'每题只填topic_id和approaches')
        need(isinstance(row['approaches'],dict) and set(row['approaches'])==set(METHODS),'每题必须有三种方式')
        topic=copy.deepcopy(source);topic['approaches']={}
        for key,labels in METHODS.items():
            a=row['approaches'][key]
            need(isinstance(a,dict) and set(a)=={'old_cognition','opening','conditions'},'每法只填原认知、开场和条件')
            old=public_text(a['old_cognition'],'原认知',4,180)
            opening=public_text(a['opening'],'开场',4,60)
            conditions=public_text(a['conditions'],'条件',0,200)
            need(old!=opening,'开场不能只是原认知照抄')
            need(not re.search(r'——|—|;|；|\n|\r|[。！？!?].+',opening),'开场只写一条主判断，不接解释或第二句')
            need(opening not in openings,'不同位置不能填同一句开场')
            openings.add(opening)
            topic['approaches'][key]=dict(label=labels[0],formula_old=labels[1],formula_new=labels[2],
                old_cognition=old,opening=opening,conditions=conditions,status='candidate',
                old_cognition_origin='ai_proposed',owner_confirmation='pending',
                viewpoint_id=canonical_digest([n['run_binding'],source['id'],key,old,opening,conditions])[:24])
        topics.append(topic)
    model=dict(schema_version=SCHEMA,mode=n['mode'],profile_ref=n['profile_ref'],input_hashes=n['input_hashes'],
        run_binding=n['run_binding'],source_binding=binding,business=n['customer_context']['business'],
        topics=topics,default_topic=p['default_topic'],default_method=p['default_method'])
    model['model_id']=canonical_digest(model)[:24]
    return model


def public_model(model):
    topics=[]
    for i,t in enumerate(model['topics'],1):
        approaches={k:{field:a[field] for field in ('label','formula_old','formula_new','old_cognition','opening','conditions','status','old_cognition_origin')}
            for k,a in t['approaches'].items()}
        topics.append(dict(id=f'item-{i:02d}',label=t['label'],customer_role=t['customer_role'],customer_task=t['customer_task'],approaches=approaches))
    default=next(i for i,t in enumerate(model['topics'],1) if t['id']==model['default_topic'])
    return dict(model_id=model['model_id'],mode=model['mode'],title='十条选题，三种反转都能看',
        default_topic=f'item-{default:02d}',default_method=model['default_method'],topics=topics)


def build(args):
    normalized=Path(args.normalized).resolve();plan=Path(args.plan).resolve()
    n=read_json(normalized);p=read_json(plan)
    binding=dict(normalized_path=str(normalized),normalized_sha256=digest(normalized),plan_path=str(plan),plan_sha256=digest(plan))
    model=build_model(n,p,binding)
    out=Path(args.out)
    need(not out.exists(),'已有结果不覆盖，请使用新目录')
    public=public_model(model)
    root=Path(__file__).resolve().parent.parent
    texture=base64.b64encode((root/'assets/texture.png').read_bytes()).decode('ascii')
    payload=json.dumps(public,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    template=(root/'assets/template.html').read_text(encoding='utf-8')
    need(template.count('__MODEL_JSON__')==1,'模板占位符不正确')
    rendered=template.replace('__MODEL_JSON__',payload).replace('__TEXTURE_BASE64__',texture)
    write(out/'internal/model.json',model)
    (out/'蛋解当头一棒.html').write_text(rendered,encoding='utf-8')
    lines=['# 蛋解当头一棒 · 十题三法候选','','全部原认知和开场为AI练习候选，待本人核对；不代表真实客户共识、实际能力或已验证效果。']
    if model['mode']=='fictional_demo':
        lines+=['','本次输入为虚构示例。']
    for i,t in enumerate(model['topics'],1):
        lines+=['',f'## 选题{i:02d} {t["label"]}']
        for a in t['approaches'].values():
            lines+=['','### '+a['label'],'','原认知（AI练习假设）：'+a['old_cognition'],'','开场候选：'+a['opening']]
            if a['conditions']:
                lines+=['','本条条件：'+a['conditions']]
    lines+=['','采用某句前，请在聊天确认选题、方法、原认知与开场；复制或默认高亮不算确认。','']
    (out/'当头一棒-学员结果.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(dict(html=str(out/'蛋解当头一棒.html'),topics=10,candidate_openings=30,selected_card='not_created',model_id=model['model_id']),ensure_ascii=False))


def verify_model(model):
    need(model.get('schema_version')==SCHEMA,'不是本版候选模型')
    binding=model['source_binding']
    for kind in ('normalized','plan'):
        need(digest(Path(binding[kind+'_path']))==binding[kind+'_sha256'],kind+'来源已变化')
    expected=build_model(read_json(Path(binding['normalized_path'])),read_json(Path(binding['plan_path'])),binding)
    need(model==expected,'模型与源计划不一致，不可独立改句后选用')


def select(args):
    model=read_json(Path(args.model));verify_model(model)
    matches=[t for t in model['topics'] if t['id']==args.topic]
    need(len(matches)==1,'所选题不在本次结果')
    t=matches[0];a=t['approaches'][args.method]
    reply_path=Path(args.reply).resolve();reply=reply_path.read_text(encoding='utf-8')
    index=model['topics'].index(t)+1
    marker=bool(re.search(r'选题\s*0*'+str(index)+r'(?!\d)',reply)) or t['label'] in reply
    need(marker and all(s in reply for s in ('确认',a['label'],a['old_cognition'],a['opening'])),'请看过后明确确认选题、方法、完整原认知和开场')
    card=dict(card_type='danjie-opening-selection',
        profile_ref=dict(id=model['profile_ref']['profile_id'],version=int(model['profile_ref']['profile_version']),card_sha256=model['input_hashes']['customer_sha256']),
        selected=dict(topic_id=t['id'],question=t['label'],method=args.method,viewpoint_id=a['viewpoint_id'],viewpoint=a['opening'],
            old_cognition=a['old_cognition'],old_cognition_origin='ai_proposed',customer_task=t['customer_task']),
        owner_confirmed=True,mode=model['mode'],business_offer=model['business'],customer_role=t['customer_role'],
        selection_origin='simulated_learner_message' if model['mode']=='fictional_demo' else 'learner_message',
        cognition_note='采用的AI练习假设，不是普遍客户共识已获验证。',
        selection_reply_sha256=digest(reply_path),selection_reply_file=str(reply_path))
    need(not Path(args.out).exists(),'已有已选卡不覆盖')
    write(args.out,card)
    print('已按新的明确回复生成已选卡，AI原认知仍保留候选来源。')


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='action',required=True)
    p=sub.add_parser('prepare')
    for k in ('customer','three-circle','out'):p.add_argument('--'+k,required=True)
    p=sub.add_parser('build')
    for k in ('normalized','plan','out'):p.add_argument('--'+k,required=True)
    p=sub.add_parser('select')
    for k in ('model','topic','reply','out'):p.add_argument('--'+k,required=True)
    p.add_argument('--method',choices=list(METHODS),required=True)
    args=parser.parse_args()
    try:
        globals()[args.action](args)
    except (ValueError,OSError,KeyError,TypeError,StopIteration) as exc:
        parser.exit(2,f'当头一棒停止：{exc}\n')


if __name__=='__main__':
    main()
