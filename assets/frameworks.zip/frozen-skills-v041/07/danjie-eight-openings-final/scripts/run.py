#!/usr/bin/env python3
"""Freeze source quotes, obtain an actual owner review, compile eight bounded entries."""
import argparse, hashlib, html, json, re, uuid
from pathlib import Path

METHODS=[('当头一棒','判断式','优先反转尺度，不硬造反常识'),('追魂一问','提问式','直接问本题'),('引人入局','情境式','有原件用原件，无原件给假设情境'),('双锋对决','对比式','比较已确认尺度，或对照题目与判断'),('一剑定局','笃定式','直接给本人建议'),('隔空点将','喊话式','提醒正在做决定的人'),('当场亮剑','现场式','有材料用材料，无材料给拍摄建议'),('欲擒故纵','悬念式','追问还缺什么条件')]
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
    p=Path(p)
    if p.exists(): raise ValueError('已有文件不覆盖，请保留原件并另用新路径：'+p.name)
    p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')
def need(b,msg):
    if not b: raise ValueError(msg)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def quote(ref, sources):
    need(isinstance(ref,dict),'必须用原文引用，不接受自由改写字符串')
    p=Path(ref['file']).resolve(); raw=p.read_bytes()
    if str(p) in sources: need(sources[str(p)]==sha(raw),'源文件已变化')
    sources[str(p)]=sha(raw)
    text=raw.decode('utf-8-sig'); pointer=ref.get('pointer')
    if p.suffix.lower()=='.json':
        need(isinstance(pointer,str) and pointer.startswith('/'),'JSON须给原字段pointer')
        obj=json.loads(text)
        for part in pointer[1:].split('/'):
            if isinstance(obj,dict): need(obj.get('restricted') is not True,'受限内容不可公开')
            key=part.replace('~1','/').replace('~0','~')
            obj=obj[int(key)] if isinstance(obj,list) else obj[key]
        need(isinstance(obj,str) and bool(obj.strip()),'引用须为完整非空文字字段')
        need(ref.get('quote')==obj,'原文字段必须整句保留，不能截去否定或条件')
    else:
        obj=ref.get('quote','')
        need(isinstance(obj,str) and obj.strip() and obj in text,'原文引用不匹配')
        need(obj in text.splitlines(),'文字资料须引用完整一行；不要裁掉限定')
    return obj
def verify_sources(req):
    raw=Path(req['source_path']).read_bytes()
    need(sha(raw)==req['input_sha'] and json.loads(raw)==req['profile'],'本轮输入快照已变化')
    for p,h in req['sources'].items(): need(sha(Path(p).read_bytes())==h,'原始材料已变化；保留当前轮，另开新轮')
def prepare(a):
    raw=Path(a.profile).read_bytes(); p=json.loads(raw); sources={}
    need(p.get('mode') in ('fictional_demo','draft'),'缺虚构/候选标识')
    business=quote(p['business_ref'],sources); audience=quote(p['audience_ref'],sources)
    concerns={}
    for c in p.get('concerns',[]):
        need(c['id'] not in concerns,'顾虑ID重复'); concerns[c['id']]=quote(c['ref'],sources)
    need(bool(concerns),'须有本次实际客群内容')
    topics=p.get('topics',[])
    need([t.get('topic_id') for t in topics]==['t%02d'%i for i in range(1,11)],'需要十个题位，缺题可留待补')
    for t in topics:
        need(isinstance(t.get('title'),str) and t['title'].strip(),'题目不可空')
        need(t['title'].count('？')+t['title'].count('?')==1 and t['title'][-1] in '？?','每题只留一个具体问句')
        need(bool(t.get('concern_ids')) and set(t['concern_ids'])<=set(concerns),'本题须关联实际原顾虑')
        need(isinstance(t.get('candidate_claim'),str),'缺候选判断，未知可空')
        need(len(t['candidate_claim'])<=120,'候选判断过长，请先提供保留条件的短版，不在成品内裁句')
        illustrations=t.get('illustrations',{})
        need(isinstance(illustrations,dict) and set(illustrations)<=set(('story_question','scene_opening','scene_direction')),'情境建议字段不正确')
        for value in illustrations.values():
            need(isinstance(value,str) and value.strip() and len(value)<=120,'情境或拍摄建议须是120字内完整文字')
    materials=[]
    for m in p.get('materials',[]):
        need(m.get('kind') in ('story','scene'),'材料类型须为story/scene')
        need(m.get('public_confirmed') is True,'未确认可公开的材料不进入结果')
        need(set(m.get('concern_ids',[]))<=set(concerns),'材料顾虑ID不匹配')
        materials.append({**m,'text':quote(m['ref'],sources)})
    out=Path(a.out).resolve(); need(not out.exists(),'新轮须用新目录，不能清旧目录重做'); out.mkdir(parents=True)
    for path in sources:
        if Path(path).suffix.lower()=='.json':
            actual=json.loads(Path(path).read_bytes())
            if isinstance(actual,dict) and actual.get('mode')=='fictional_demo': need(p['mode']=='fictional_demo','虚构原卡不可升级真人')
    req={'run_id':str(uuid.uuid4()),'input_sha':sha(raw),'source_path':str(Path(a.profile).resolve()),'sources':sources,'profile':p,'business':business,'audience':audience,'concerns':concerns,'materials':materials,'out':str(out)}
    write(out/'request.json',req)
    menu=['# 请核对本次题目和候选判断','虚构示例' if p['mode']=='fictional_demo' else '候选，不代表本人已经确认']
    for i,t in enumerate(topics,1): menu += ['\n%d. %s\n候选判断：%s'%(i,t['title'],t['candidate_claim'] or '待本人补充')]
    menu += ['\n你认同哪些题目和判断，哪些要改或先留空？']
    (out/'请本人核对.md').write_text('\n'.join(menu),encoding='utf-8')
    print(out/'request.json'); print(out/'请本人核对.md')
def confirm(a):
    req=read(a.request); verify_sources(req); raw=Path(a.reply).read_bytes(); reply=json.loads(raw)
    need(isinstance(reply.get('message'),str) and reply['message'].strip(),'须保存实际收到的本人原答')
    need(isinstance(reply.get('accepted'),list) and isinstance(reply.get('edits',{}),dict),'确认映射格式错误')
    ids={t['topic_id'] for t in req['profile']['topics']}
    need(set(reply['accepted'])<=ids and set(reply.get('edits',{}))<=ids,'确认了不存在的题')
    need(not set(reply['accepted']) & set(reply.get('edits',{})),'同一题不能同时接受和改写')
    reviewed=[]
    for t in req['profile']['topics']:
        claim=''
        if t['topic_id'] in reply['accepted']: claim=t['candidate_claim']
        elif t['topic_id'] in reply.get('edits',{}):
            claim=reply['edits'][t['topic_id']]
            need(isinstance(claim,str) and claim.strip() and claim in reply['message'],'修改必须来自本次真实原答，不能代写')
        reviewed.append({**t,'claim':claim or '待本人补充','owner_status':'confirmed' if claim else 'needs_decision'})
    write(Path(req['out'])/'owner-review.json',{'run_id':req['run_id'],'input_sha':req['input_sha'],'reply_sha':sha(raw),'reply_file':str(Path(a.reply).resolve()),'reply':reply,'topics':reviewed})
    print('本次原答已绑定；未确认题保留缺口。')
def compile_topic(t,materials):
    claim=t['claim']; confirmed=t['owner_status']=='confirmed'; out=[]
    fixed_hint='固定句式只承接本人已确认的判断；拍前仍核对适用条件，不把建议当实证。'
    fixed_payoff='解释本人判断的适用条件。没有相应记录时，不讲成已经证实的事实或客户案例。'
    old=t.get('old_scale',''); new=t.get('new_scale','')
    scales=confirmed and all(isinstance(v,str) and 2<=len(v)<=12 and v in claim for v in (old,new)) and old!=new
    for i in range(8):
        text=''; gap='请本人确认本题判断；没有确认先留空。'; mids=[]; basis='owner_judgment'; notice=''; direction=''; hint=fixed_hint
        if i==1 and confirmed: text=t['title']
        elif confirmed:
            if i==0:
                text=claim
                if not scales: hint='当前给判断式候选，没有明确尺度反转，不把它包装成已成立的反常识。'
            elif i in (2,6):
                kind='story' if i==2 else 'scene'
                matches=[m for m in materials if m['kind']==kind and set(m['concern_ids'])&set(t['concern_ids'])]
                if matches:
                    m=matches[0]; text=('有这样一段原始记录：' if i==2 else '先看这份已提供的材料：')+m['text']; mids=[m['id']]
                    basis='provided_material'; notice='原材料引用，仍需核对公开边界和事实；不是独立核验结论。'
                else:
                    proposed=t.get('illustrations',{})
                    if i==2:
                        basis='hypothetical'; notice='假设情境，非真人案例'
                        scenario=proposed.get('story_question') or ('假设你现在要决定这件事：'+t['title']+'你会先核对什么，再做决定？')
                        text='【'+notice+'】\n'+scenario
                        hint='这是用来引出本题的AI情境候选，不是本人经历、客户案例或观点证据。'
                    else:
                        basis='scene_plan'; notice='拍摄建议，尚未实拍'
                        opening=proposed.get('scene_opening') or ('先把这个问题写在纸上：'+t['title']+'这次先核对：'+claim)
                        direction=proposed.get('scene_direction') or '镜头展示自行写的问题卡，逐项标出待核条件；未提供实物时不演示设备效果。'
                        text='【'+notice+'】\n'+opening
                        hint='建议镜头：'+direction+' 这是待执行的拍法，不是现成现场或实测。'
            elif i==3:
                if scales: text='如果按“'+old+'”选，和按“'+new+'”选，你会先核对哪一个？'
                else:
                    text='先对照问题：'+t['title']+'\n再对照我的判断：'+claim
                    hint='没有明确的两种尺度，先给问题与判断的对照候选，不编两方输赢。'
            elif i==4: text='这道题，我的建议是：'+claim
            elif i==5: text='正在为这道题做决定的朋友，先听这一句：'+claim
            elif i==7: text='要判断“'+t['title'][:-1]+'”，还有哪些条件没问清？'
        need(len(re.sub(r'\s','',text))<=360,'原话或候选较长，请保留当前轮，先给完整短版，不擅自裁句')
        out.append({'method':str(i),'text':text or gap,'status':'candidate' if text else 'needs_material','hint':hint if text else gap,'payoff':fixed_payoff if text else '', 'source_ids':mids,'basis':basis if text else 'pending_confirmation','notice':notice,'scene_direction':direction,'can_use_as_evidence':False})
    return out
def export(a):
    req=read(a.request); verify_sources(req); out=Path(req['out']); review=read(out/'owner-review.json')
    need(review['run_id']==req['run_id'] and review['input_sha']==req['input_sha'],'确认不属于本轮')
    need(sha(Path(review['reply_file']).read_bytes())==review['reply_sha'],'本人原答已变化')
    reply=read(review['reply_file']);need(reply==review['reply'],'本人原答快照被改写')
    expected=[]
    for original in req['profile']['topics']:
        claim=original['candidate_claim'] if original['topic_id'] in reply['accepted'] else reply.get('edits',{}).get(original['topic_id'],'')
        expected.append({**original,'claim':claim or '待本人补充','owner_status':'confirmed' if claim else 'needs_decision'})
    need(review['topics']==expected,'已确认判断被改写；不能强化条件或另加因果')
    topics=[]
    for t in review['topics']:
        topics.append({'id':t['topic_id'],'topic_id':t['topic_id'],'title':t['title'],'claim':t['claim'],'owner_status':t['owner_status'],'customer_task':t['title'],'concern_ids':t['concern_ids'],'results':compile_topic(t,req['materials'])})
    p=req['profile']; version=sha(json.dumps(topics,ensure_ascii=False).encode())[:12]
    model={'version':version,'skill_version':'1.4.0','mode':p['mode'],'profile':{'id':str(p.get('profile_id') or req['run_id']),'version':str(p.get('profile_version','1')),'business':req['business'],'audience':req['audience']},'methods':[{'id':str(i),'name':m[0],'type':m[1],'use':m[2]} for i,m in enumerate(METHODS)],'topics':topics}
    result=out/'result'; need(not result.exists(),'结果已存在，保留旧版后另起新轮'); result.mkdir()
    template=(Path(__file__).resolve().parent.parent/'assets/template.html').read_text(encoding='utf-8-sig')
    template=template.replace('原话锁定，固定句式。拍前核对观点和事实。故事与现场缺素材时，先补素材。','原话锁定，候选补全。假设不是真人案例，拍摄建议不是实拍或效果证据。')
    template=template.replace('__MODEL_JSON__',json.dumps(model,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026'))
    for key,value in {'__BUSINESS__':req['business'],'__AUDIENCE__':req['audience'],'__MODE__':'虚构示例 · 原话锁定' if p['mode']=='fictional_demo' else '本人判断 · 拍前核对','__PROFILE_SUMMARY__':req['business']+'\n'+req['audience']}.items(): template=template.replace(key,html.escape(value))
    h=result/'蛋解开场八式.html';h.write_text(template,encoding='utf-8')
    lines=['# 蛋解开场八式','虚构示例' if p['mode']=='fictional_demo' else '本人已确认的建议，不代表外部核实']
    for t in topics:
        lines+=['\n## '+t['title']]
        for i,x in enumerate(t['results']):
            lines+=['\n### '+METHODS[i][0],('【待确认】' if x['status']=='needs_material' else '')+x['text']]
            if x['scene_direction']: lines+=['拍摄建议：'+x['scene_direction']]
    (result/'开场八式-学员结果.md').write_text('\n'.join(lines),encoding='utf-8'); write(result/'model.json',model)
    write(out/'export-receipt.json',{'run_id':req['run_id'],'input_sha':req['input_sha'],'source_sha':req['sources'],'reply_sha':review['reply_sha'],'html_sha':sha(h.read_bytes()),'scope':'确定句式及完整原句绑定；不证明原答真实、候选题适切或原生交互通过'})
    print(h)
def main():
    p=argparse.ArgumentParser(); subs=p.add_subparsers(dest='cmd',required=True)
    s=subs.add_parser('prepare');s.add_argument('--profile',required=True);s.add_argument('--out',required=True)
    s=subs.add_parser('confirm');s.add_argument('--request',required=True);s.add_argument('--reply',required=True)
    s=subs.add_parser('export');s.add_argument('--request',required=True)
    a=p.parse_args();globals()[a.cmd](a)
if __name__=='__main__':
    try: main()
    except (ValueError,KeyError,TypeError,OSError,json.JSONDecodeError) as e: raise SystemExit('未完成：'+str(e))
