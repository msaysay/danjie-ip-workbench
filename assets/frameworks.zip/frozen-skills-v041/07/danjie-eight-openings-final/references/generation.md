# 输入与候选编译合同 · 1.4.0

## profile.json
model只整理本次原卡，不填期望结果。
- profile_id、profile_version保留原标识；未知才建本次ID，version用字符串保持原显示。
- mode=fictional_demo或draft，虚构不可升级。
- business_ref、audience_ref：原卡完整文字字段引用。
- concerns=[{id,ref}]：有实质内容的原需求/顾虑。未知栏不冒充事实；十个题位可从已知顾虑拆不同决定，但不能换词凑十条事实。
- topics恰好十项，topic_id=t01..t10，title为一个具体问句，concern_ids指已读原顾虑，candidate_claim为待本人认可的一句建议。原材料不足可candidate_claim空，不编专业因果。
- old_scale、new_scale是可选的旧/新比较尺度，各2—12字，须逐字出现在本人最终确认的claim里；没有明确翻转就留空，不为凑当头一棒编原认知。这两项不作客户已如此想的事实。
- materials可空。每项{id,kind:story或scene,ref,concern_ids,public_confirmed:true}，实际有原件且确认可公开才放。题间不能借故事。
- 每题可含illustrations={story_question,scene_opening,scene_direction}，每个字段为120字内的AI候选文字。story_question从明确假设引出本题决定，不假扮过往；scene_opening是准备说的话，scene_direction是待执行的镜头，不能宣称已有实物或测试结果。三者不是source，不得存入materials或使用真实证据ID。省略时程序给同题通用候选。

引用ref={file:本次原件绝对路径,pointer:完整JSON字段路径,quote:该字段完整字符串}。
非JSON不传pointer，quote须是原文完整一行；不要截掉否定、条件和角色范围。文件SHA由prepare自动冻结。原卡有多段text数组时逐项引用，不能擅改原卡。完整字段引用仍需人工检查上下文、公开性，不是通用隐私或语义证明。

## 本人核对
prepare先冻结候选并给确认菜单，原生实际停问后才记录reply.json：
{message:本次实际完整原答,accepted:[t01等实际认可题号],edits:{t02:实际原答中修改的完整判断}}。
未认可的题不填写。accepted表示对该菜单题目与候选判断的认可；不同意题目/客户角色就先留空。edits不得由AI再改写。程序验证修改逐字出自message，但本人确实收到、看过和回答由原生流程另验，不能自填文件冒充。

## 八式由程序产生
0 当头一棒：本人确认的判断原文；旧/新尺度不明确时标为判断式，不硬造反常识，仍给候选。
1 追魂一问：本人认可的原问题，不另补前提。
2 引人入局：有story原件时完整引用；无原件用【假设情境，非真人案例】加本题illustrations.story_question。省略时程序给围绕原题的通用假设问句。
3 双锋对决：比较本人确认的两种尺度；无尺度时给题目与判断的对照，不虚构两方输赢。
4 一剑定局：固定建议引导加本人判断原文，不强化条件。
5 隔空点将：固定叫出正在做这道题决定的人，加本人判断原文，不造群体特征。
6 当场亮剑：有scene原件时完整引用；无原件用【拍摄建议，尚未实拍】加scene_opening，镜头方向放hint/scene_direction，不混成已发生的现场。省略时建议展示自写问题卡，不假称已有样品或设备。
7 欲擒故纵：固定追问本题还有哪些条件没问清，不编故事或成因。
每项结果含basis=owner_judgment/provided_material/hypothetical/scene_plan/pending_confirmation、notice、scene_direction及can_use_as_evidence=false。假设/拍法没有事实source_ids，性质标记置于text，复制自然保留；交接另保留结构字段。缺判断整题仍先确认，不能替本人点头。较长原话先给完整短版，不在成品偷偷截句。

固定句式不证明观点为真或传播有效；需要本人核对候选题与建议。程序只防确认后的自由添写，不替代真人事实核验。
