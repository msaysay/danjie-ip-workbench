# 双卡推导格式 0.7.0

三环节共用顶层：schema="qiankun-dual-card-1"、mode、business、A、B、topics、selected_topic、selection_note、input_note。

新增source_files={audience:本次客群卡绝对路径,persona:本次人设卡绝对路径}。两个原件必须不同且实际可读。脚本支持UTF-8 Markdown/TXT、JSON、HTML、DOCX；图片由宿主先实际看图整理，保留改编来源，不假称脚本读了原图。不能把同一段文字复制成两卡伪装来源。

A保留label、paying_role、decision、card_quote（客群卡逐字原文）。新增portrait数组，每项label、value、state=provided/unknown、quote。provided的quote必须在原客群卡，value不得补造其中没有的确定信息；unknown的value写未提供或具体缺口，quote为空。need和concern用本次卡片摘要，保留其未知/推演性质。

B每项id、label、relation、concern、basis。通常5—10类；确实不足5类时填写b_scope_note解释业务范围，不靠通用人名凑数。不能把B当成新精准用户。

C每题id、question、interested_people、interest_reason、related_ids（B编号数组，可空）、CB、BA、business_return、basis、card_basis、methods。

card_basis固定两项：role分别audience和persona，每项quote为对应原件逐字连续文字、reason说明这段原文如何支持该话题。两卡引用本身不能证明关联自然，必须由AI另核：该题是不是更广人群也会关心、是否仍在本人业务范围、是否能回应原客户问题。

C池由两卡共同推导，不按B切换筛掉其他题；related_ids只记录可用的讲述关系。可直接回A的题不强造B，CB说明不经B的连接，BA说明如何落到A。

第三环节仍只展开本次明确选中的一个话题，methods按数盘秘势反冲情排列，每式字段：key为一个字诀，angle为该式机制的一句话解释，opening为完整可口述开场，steps为1—5条具体展开步骤数组，materials为所依据或仍需补的真实材料说明，status="candidate"，gap=""。七式顺序固定数盘秘势反冲情。未选题methods=[]。没选时methods为空；生成第三环节时必须完成七个开场，不能编数据补齐，实在做不出来时说明仍未完成，不交假成品。原始来源路径只留后台，HTML不嵌入原卡全文。

顶层增加 related_voices 数组，按B的顺序每类恰好一条，不能遗漏。字段：role_id、scene、concern、line、bridge、basis（inferred或provided）、topic_ids（适合的C编号数组，可空）。provided还需source_quote等于line，且引文在本次原卡中。嘴替清单独立于所选C，第一环节B有几类，这里就几条；界面按当前C标注适配与否，不隐藏其他角色。不要求每个人都适合当前题，不强造连接。旧版每题voices字段弃用，避免少量角色覆盖全体的误解。

C每题新增 public_issue（公共议题）、outside_examples（至少两个非本业务的具体日常场景）。两者用于人工检查扩圈逻辑，程序只能检查存在，不能证明大众真感兴趣。第二环节展示全部related_voices；第三环节展示当前C的七字诀，可带入选中的适配嘴替；不在第二屏混排七字诀。

第三环节七式均有可口述的opening与对应angle。优先使用材料支持的表达方式，不为了凑某式编数字、内幕或名人。steps和materials作为折叠补充；同一选题的七个opening同时可见。确实无法成立时明确指出缺什么，不将未完成结果当作七式完成交付。

A.portrait每项可增diagram_value，为该维度已知内容的简短摘要，用于六边形节点；未知写未提供，不造数值评分。

related_voices每条新增speaker_role，必须等于role_id对应的B.label；pov_check非空，用一句话说明嘴替站在该角色哪项责任或需要上。它们留后台，不显示为学员提示。结构检查只能核对标签，仍须人工检查实际台词视角。

0.7：顶层industry_terms为2—10项，每项word必须逐字出现在quote内，quote在本次任一原卡；只选技术或具体服务词，不取钱/家庭/孩子等公共词。所有C.question和methods.opening不得出现本次专业词。数式填number_kind=hypothetical/input_fact/classification及number_basis；hypothetical的opening必须明示如果/假设/比如，input_fact另有source_quote在原卡，classification说明计数分类的范围。势式填borrow_kind=common_saying/public_source及borrow_quote，所引原句必须出现在opening；common_saying取脚本公共俗语表，public_source另需实际核对的http(s) source_url与source_quote。
