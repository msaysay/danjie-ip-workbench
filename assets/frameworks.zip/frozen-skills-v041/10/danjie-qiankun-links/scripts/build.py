#!/usr/bin/env python3
"""Render supplied reasoning, never invent seven generic questions."""
import json,sys,re,hashlib,zipfile
from html.parser import HTMLParser
import xml.etree.ElementTree as ET
from pathlib import Path
METHODS=list('数盘秘势反冲情')
def need(ok,msg):
 if not ok:raise ValueError(msg)
def nonempty(d,keys):
 for k in keys:need(isinstance(d.get(k),str) and d[k].strip(),'缺少 '+k)
def card_text(path):
 p=Path(path);need(p.is_file(),'缺原卡文件：'+str(p));raw=p.read_bytes()
 if p.suffix.lower()=='.docx':
  with zipfile.ZipFile(p) as z:root=ET.fromstring(z.read('word/document.xml'))
  return '\n'.join(''.join(t.text or '' for t in v.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t')) for v in root.iter('{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p'))
 text=raw.decode('utf-8-sig')
 if p.suffix.lower()=='.json':
  def strings(v):
   if isinstance(v,str):return [v]
   if isinstance(v,dict):return sum([strings(x) for x in v.values()],[])
   if isinstance(v,list):return sum([strings(x) for x in v],[])
   return []
  text='\n'.join(strings(json.loads(text)))
 elif p.suffix.lower()=='.html':
  class Parser(HTMLParser):
   def __init__(self):super().__init__();self.parts=[];self.skip=0
   def handle_starttag(self,tag,attrs):
    if tag in ['script','style']:self.skip+=1
   def handle_endtag(self,tag):
    if tag in ['script','style']:self.skip=max(0,self.skip-1)
   def handle_data(self,s):
    if not self.skip:self.parts.append(s)
  parser=Parser();parser.feed(text);text='\n'.join(parser.parts)
 else:need(p.suffix.lower() in ['.md','.txt'],'此格式需宿主实际读取后整理文字，不假称脚本已读')
 need(bool(text.strip()),'原卡无可读文字');return text
def validate(d):
 need(d.get('schema')=='qiankun-dual-card-1','模型格式不同');need(d.get('mode') in ['fictional_demo','user_provided'],'缺来源模式');nonempty(d,['business','input_note']);nonempty(d['A'],['label','paying_role','decision','card_quote','need','concern'])
 files=d.get('source_files',{});need(set(files)=={'audience','persona'},'C必须读取客群卡与人设卡两份原件');need(Path(files['audience']).resolve()!=Path(files['persona']).resolve(),'不能用同一原件冒充两卡');texts={k:card_text(v) for k,v in files.items()};need(texts['audience'].strip()!=texts['persona'].strip(),'不能复制同一段内容冒充两卡')
 terms=d.get('industry_terms',[]);need(2<=len(terms)<=10,'先从两卡提取2—10个实际业务专业词，用于检查C是否缩回小类目')
 for term in terms:
  nonempty(term,['word','quote']);need(term['word'] in term['quote'] and any(term['quote'] in txt for txt in texts.values()),'专业词必须引用本次原卡');need(term['word'] not in ['钱','孩子','家庭','工作','公司','客户','人','服务'],'不要把公共词当专业词')
 need(d['A']['card_quote'] in texts['audience'],'A依据不在原目标客群卡');need(bool(d['A'].get('portrait')),'A需要可读的客群画像，不只一行人群名')
 need(len(d['A']['portrait'])==6 and {r.get('label') for r in d['A']['portrait']}=={'基本轮廓','家庭结构','职业身份','收入与消费','住房与车辆','生活与购物'},'画像需要六个明确维度，未知也保留，不按数组位置猜')
 for row in d['A']['portrait']:
  nonempty(row,['label','value']);need(row.get('state') in ['provided','unknown'],'画像缺已提供/未知状态')
  if row['state']=='provided':need(bool(row.get('quote')) and row['quote'] in texts['audience'],'画像摘要须有客群卡原文依据')
  else:need(not row.get('quote'),'未知画像不伪造引文')
 bs=d['B'];need(bool(bs),'先从精准客户推导相关人群');ids=[b['id'] for b in bs];need(len(set(ids))==len(ids),'相关人群编号重复')
 need(len(bs)<=10,'相关人群通常5—10类，避免重复堆人');need(len(bs)>=5 or bool(d.get('b_scope_note')),'少于5类时说明范围，不凑人')
 for b in bs:
  nonempty(b,['id','label','relation','concern']);need(b.get('basis') in ['provided','inferred'],'相关人群需区分原卡和推演')
 ts=d['topics'];need(bool(ts),'先推导新话题，再进入七字诀');tids=[t['id'] for t in ts];need(len(tids)==len(set(tids)),'话题重复');need(d.get('selected_topic') is None or d['selected_topic'] in tids,'选中题不存在')
 if d.get('selected_topic'):nonempty(d,['selection_note'])
 for t in ts:
  nonempty(t,['id','question','public_issue','interested_people','interest_reason','CB','BA','business_return']);need(isinstance(t.get('outside_examples'),list) and len(t['outside_examples'])>=2 and all(isinstance(e,str) and e.strip() for e in t['outside_examples']),'C需要两个非本行业的具体生活或工作场景');need(isinstance(t.get('related_ids'),list) and set(t['related_ids'])<=set(ids),'关联人物编号不存在；C可以直接回A，不强造B');need(t['question'].endswith('？'),'兴趣话题应是一个具体问题');need(t.get('basis') in ['provided','inferred'],'话题需标来源或推演')
  basis=t.get('card_basis',[]);need(len(basis)==2 and {x.get('role') for x in basis}=={'audience','persona'},'每个C必须有两卡共同依据')
  for x in basis:nonempty(x,['quote','reason']);need(x['quote'] in texts[x['role']],'C引文不在本次对应原卡')
  need(not any(term['word'] in t['question'] for term in terms),'C仍含本业务专业词，请重推公共问题，不只是改行业操作题标题')
  need(t['interested_people'] not in ['大众','所有人','大家','泛人群'],'明确谁可能关心，而非写所有人')
  need(t['question'].rstrip('？') not in METHODS,'七字诀不是话题');ms=t.get('methods',[])
  if ms:
   need(t['id']==d.get('selected_topic'),'未选题不得预先批量套七法');need([m['key'] for m in ms]==METHODS,'第三环节须数盘秘势反冲情同题七式');need(all(m.get('status')=='candidate' and bool(m.get('opening','').strip()) for m in ms),'第三环节未完成：须七条完整开场，不以待补材料冒充完成')
   for m in ms:
    nonempty(m,['angle','materials']);need(m.get('status') in ['candidate','needs_material'],'讲法状态错误');need(isinstance(m.get('steps'),list) and all(isinstance(s,str) and s.strip() for s in m['steps']) and 1<=len(m['steps'])<=5,'需要具体展开顺序')
    if m['status']=='candidate':
     nonempty(m,['opening']);need(not any(term['word'] in m['opening'] for term in terms),'开场先讲选定公共题，业务术语放steps，不缩回行业教程');need(len(re.sub(r'\s','',m['opening']))<=90,'opening只写开场，不超过90个非空白字符；展开另放steps');need(not any(w in m['opening'] for w in ['客群卡','人设卡','本次两卡','model.json','selected_topic']),'口播开场不能出现制作上下文词')
    else:need(not m.get('opening'),'缺依据不能伪装可直接说');nonempty(m,['gap'])
   n=ms[0];nonempty(n,['number_kind','number_basis']);need(n['number_kind'] in ['hypothetical','input_fact','classification'],'数式需明确假设/输入事实/分类计数依据')
   if n['number_kind']=='hypothetical':need(any(w in n['opening'] for w in ['如果','假设','比如']),'假设数量开场须明示如果/假设/比如，不能冒充统计')
   if n['number_kind']=='input_fact':need(bool(n.get('source_quote')) and any(n['source_quote'] in txt for txt in texts.values()),'真实数字须有本次原卡逐字来源')
   borrow=ms[3];nonempty(borrow,['borrow_kind','borrow_quote']);need(borrow['borrow_quote'] in borrow['opening'],'借势引用需真实出现在开场里')
   if borrow['borrow_kind']=='common_saying':need(borrow['borrow_quote'] in ['家和万事兴','亲兄弟明算账','强扭的瓜不甜','站着说话不腰疼','己所不欲，勿施于人','众人拾柴火焰高','磨刀不误砍柴工','当局者迷，旁观者清','鞋合不合脚，只有自己知道'],'不要将自编句冒称老话；公共俗语用包内原句，其他来源须实际核查')
   else:need(borrow['borrow_kind']=='public_source' and re.match(r'^https?://',borrow.get('source_url','')) and bool(borrow.get('source_quote')),'具体借势对象须有实际核查的原句和来源链接')
   openings=[m['opening'] for m in ms if m['status']=='candidate'];need(len(set(openings))==len(openings),'七法不能复制同一句话')
 voices=d.get('related_voices',[]);need([v.get('role_id') for v in voices]==ids,'嘴替须按B顺序逐一覆盖全部相关人群，不遗漏、不重复')
 for voice in voices:
  nonempty(voice,['role_id','scene','concern','line','bridge','speaker_role','pov_check']);need(voice['speaker_role']==next(b['label'] for b in bs if b['id']==voice['role_id']),'嘴替说话人必须对应本条B身份');need(voice.get('basis') in ['provided','inferred'],'嘴替区分原话与假设表达');need(isinstance(voice.get('topic_ids'),list) and set(voice['topic_ids'])<=set(tids),'嘴替关联话题不存在')
  if voice['basis']=='provided':need(voice.get('source_quote')==voice['line'] and any(voice['line'] in txt for txt in texts.values()),'客户原话须能在本次原卡核对')
 return d
def render(src,out):
 d=validate(json.loads(Path(src).read_text(encoding='utf-8-sig')));dst=Path(out);need(not dst.exists(),'新结果另存，不覆盖旧版');dst.mkdir(parents=True)
 template=(Path(__file__).resolve().parents[1]/'assets/template.html').read_text(encoding='utf-8');frontend={k:v for k,v in d.items() if k!='source_files'};html=template.replace('__MODEL__',json.dumps(frontend,ensure_ascii=False).replace('</','<\\/'));name='乾坤大挪移-双卡推导-'+hashlib.sha256(html.encode()).hexdigest()[:8]+'.html';(dst/name).write_text(html,encoding='utf-8');(dst/'model.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');(dst/'source-receipt.json').write_text(json.dumps({k:{'path':str(Path(p).resolve()),'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for k,p in d['source_files'].items()},ensure_ascii=False,indent=2),encoding='utf-8')
 lines=['# 乾坤大挪移：先找话题，再设计讲法','虚构演示' if d['mode']=='fictional_demo' else '候选推导，待本人核对','\n## A 精准用户',d['A']['label']]
 for b in d['B']:
  lines+=['\n## B '+b['label'],b['relation']]
  for t in d['topics']:
   if b['id'] in t['related_ids']:lines+=['\n### 可能关联的话题 '+t['question']]
 lines+=['\n## C 两卡共同推导的独立话题池']
 for t in d['topics']:
  lines+=['\n### '+t['question'],'谁可能关心：'+t['interested_people'],'公共议题：'+t['public_issue'],'非本行业场景：'+'；'.join(t['outside_examples']),'为什么：'+t['interest_reason'],'回到业务：'+t['business_return']]+[x['role']+'原文：'+x['quote']+'；关联：'+x['reason'] for x in t['card_basis']]
 lines+=['\n## 第二环节：全部相关人嘴替']
 for v in d['related_voices']:lines+=['\n### '+next(b['label'] for b in d['B'] if b['id']==v['role_id']),'场景：'+v['scene'],'会考虑：'+v['concern'],'嘴替：'+v['line'],'假设表达，非客户原话' if v['basis']=='inferred' else '原卡引语','接回A：'+v['bridge']]
 for t in d['topics']:
  if t.get('methods'):
   lines+=['\n## 第三环节：同一选题七个开场——'+t['question']]
   for m in t['methods']:lines+=['\n### '+m['key'],m['opening'],m['angle'],*m['steps'],'材料：'+m['materials']]
 (dst/'推导与讲法.md').write_text('\n'.join(lines),encoding='utf-8');print((dst/name).resolve())
if __name__=='__main__':
 try:
  if len(sys.argv)!=3:raise ValueError('build.py MODEL.json NEW_RESULT_DIR')
  render(*sys.argv[1:])
 except (ValueError,OSError,KeyError,TypeError) as e:raise SystemExit('未完成：'+str(e))
