#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Render six complete interview PNG files with Pillow, without browser screenshots.

Pillow must already be installed. Fonts are read from the OS or --font; no network,
package install, model call, story rewriting, or source JSON mutation occurs.
"""
import argparse
import hashlib
import json
import math
import os
import pathlib
import re
import sys
import unicodedata
import zipfile
from render import student_document

VERSION = '0.4.3'
WIDTH = 1080
MAX_HEIGHT = 30000
NAMES = ['缘起', '悟道', '求索', '取舍', '破局', '见证']
GOLD = '#e6c474'
WHITE = '#f3f1e9'
MUTED = '#bbc3c2'


def line(value, **style):
    row = dict(text=str(value), size=31, lineHeight=48, weight=400, color=WHITE, gap=10)
    row.update(style)
    return row


def bullet(items, **style):
    return [line('• ' + str(v), **style) for v in (items or ['暂无新增项目'])]


def build_blocks(data, index):
    """Use the same student projection as HTML/MD and export.js; no story rewriting."""
    front = student_document(data)
    o = front['outlines'][index]
    blocks = []

    def add(title, rows, kind='card'):
        blocks.append(dict(title=title, rows=rows, kind=kind))

    hero = [line(front['title'], size=27, lineHeight=42, color=MUTED, gap=18),
            line(o['model'], size=64, lineHeight=88, weight=700, color=GOLD, gap=8),
            line(o['title'], size=43, lineHeight=62, weight=600, gap=18)]
    if front['demo_note']:
        hero.append(line(front['demo_note'], size=25, lineHeight=39, color=MUTED))
    add('', hero, 'hero')
    add('开场', [line(o['opening'])])
    for q in o['questions']:
        rows = [line(q['ask'], size=46, lineHeight=68, weight=700, gap=18)]
        rows.extend([line('给你看的，不用念', size=20, lineHeight=30, color=MUTED, gap=2), line(q['hint'], size=22, lineHeight=35, color=MUTED, gap=20)])
        for f in q['followups']:
            rows.extend([line(f['when'], size=21, lineHeight=33, color=MUTED, gap=2), line(f['ask'], size=34, lineHeight=53, weight=500, gap=22)])
        rows.extend([line('听到这些，就换下一题', size=19, lineHeight=30, color=MUTED, gap=2), line(q['enough'], size=21, lineHeight=34, color=MUTED)])
        add('主问 ' + q['id'][1:], rows, 'question')
    add('换个话题继续', [line(o['closing'])])
    return blocks


def font_candidates(explicit=None):
    if explicit:
        p = pathlib.Path(explicit).expanduser()
        if not p.is_file():
            raise ValueError('--font指定的字体文件不存在：' + str(p))
        return [p]
    fonts = [pathlib.Path('/System/Library/Fonts/PingFang.ttc'),
             pathlib.Path('/System/Library/Fonts/STHeiti Medium.ttc'),
             pathlib.Path('/System/Library/Fonts/STHeiti Light.ttc')]
    win = pathlib.Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts'
    fonts += [win / 'msyh.ttc', win / 'msyhbd.ttc', win / 'simhei.ttf', win / 'simsun.ttc']
    fonts += [pathlib.Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'),
              pathlib.Path('/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc'),
              pathlib.Path('/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc')]
    for root in [pathlib.Path('/System/Library/AssetsV2'), pathlib.Path('/usr/share/fonts'), pathlib.Path.home() / '.fonts', pathlib.Path.home() / '.local/share/fonts']:
        if root.exists():
            # Font files stay on the user's machine; none are copied into the Skill.
            for pat in ['*PingFang*.ttc', '*NotoSansCJK*.ttc', '*SourceHanSans*.otf']:
                fonts.extend(sorted(root.rglob(pat)))
    seen = set()
    return [p for p in fonts if p.is_file() and not (str(p) in seen or seen.add(str(p)))]


def mask_fingerprint(font, char):
    mask = font.getmask(char)
    return mask.size, bytes(mask)


def choose_font(ImageFont, characters, explicit=None, explicit_index=None):
    paths = font_candidates(explicit)
    if not paths:
        raise ValueError('未找到可用中文字体。请指定已有字体：--font /路径/中文字体.ttf；不会联网下载字体或使用方框代替。')
    wanted = sorted({c for c in characters if ord(c) > 127 and unicodedata.category(c) not in ['Cc', 'Cf'] and not unicodedata.category(c).startswith('M')})
    sentinel = '汉字访谈缘起悟道求索取舍破局见证'
    options, failed = [], []
    for path in paths:
        indices = [explicit_index] if explicit_index is not None else range(16 if path.suffix.lower() in ['.ttc', '.otc'] else 1)
        for index in indices:
            try:
                f = ImageFont.truetype(str(path), 31, index=index)
                name = ' '.join(f.getname())
                missing = mask_fingerprint(f, '\U0010ffff')
                if any(mask_fingerprint(f, ch) == missing for ch in sentinel):
                    failed.append(str(path) + ': 不覆盖中文'); continue
                absent = [ch for ch in wanted if mask_fingerprint(f, ch) == missing]
                if absent:
                    failed.append(str(path) + ': 缺少 ' + ', '.join(repr(c) + ' U+' + format(ord(c), '04X') for c in absent[:6])); continue
                # TTC collections can put Traditional Chinese or Japanese first.
                sc = any(mark in name.lower() for mark in [' sc', 'simplified', '简体', '微软雅黑'])
                options.append((not sc, paths.index(path), index, path, name))
            except (OSError, ValueError):
                if explicit_index is not None: failed.append(str(path) + ': 字体索引无法读取')
                break
        if options and explicit:
            break
    if not options:
        raise ValueError('中文字体或字形检查失败，未输出方框图片。请用--font指定覆盖全文的已有中文字体。' + (' 检查：' + '；'.join(failed[:4]) if failed else ''))
    options.sort(key=lambda x: x[:3])
    _, _, index, path, name = options[0]
    return dict(path=str(path), index=index, name=name, checked_non_ascii_characters=len(wanted))


class Fonts:
    def __init__(self, ImageFont, spec):
        self.ImageFont, self.spec, self.cache = ImageFont, spec, {}

    def get(self, size):
        if size not in self.cache:
            self.cache[size] = self.ImageFont.truetype(self.spec['path'], size, index=self.spec['index'])
        return self.cache[size]


def measure(value, font, stroke=0):
    return float(font.getlength(value)) + stroke * 2


def wrap_text(value, font, max_width, stroke=0):
    result = []
    closing = '，。！？；：、）》」』】〕〉,.!?;:)]'
    for para in str(value).replace('\r\n', '\n').replace('\r', '\n').split('\n'):
        if not para:
            result.append(''); continue
        current = ''
        for char in para:
            if current and measure(current + char, font, stroke) > max_width:
                if char in closing and len(current) > 1:
                    result.append(current[:-1]); current = current[-1] + char
                else:
                    result.append(current); current = char
            else:
                current += char
        if current:
            result.append(current)
    return result


def make_plan(blocks, fonts):
    cards, y, rows_count = [], 138, 0
    for block in blocks:
        rows = []
        for paragraph in block['rows']:
            stroke = 1 if paragraph['weight'] >= 600 else 0
            pieces = wrap_text(paragraph['text'], fonts.get(paragraph['size']), 908, stroke)
            # Newlines become row boundaries. No word or character is deleted.
            assert ''.join(pieces) == paragraph['text'].replace('\r\n', '\n').replace('\r', '\n').replace('\n', ''), '换行字符守恒失败'
            for i, value in enumerate(pieces):
                row = dict(paragraph, text=value, gap=paragraph['gap'] if i == len(pieces) - 1 else 0, stroke=stroke)
                if measure(value, fonts.get(row['size']), stroke) > 908.01:
                    raise ValueError('存在无法安全换行的文字；未截断内容。')
                rows.append(row)
        head = 28 + (53 if block['title'] else 0)
        height = head + sum(r['lineHeight'] + r['gap'] for r in rows) + 28
        cards.append(dict(title=block['title'], kind=block['kind'], rows=rows, x=58, y=y, width=964, height=height, text_x=86, text_y=y + head))
        y += height + 20; rows_count += len(rows)
    height = max(900, math.ceil(y + 106))
    if height > MAX_HEIGHT:
        raise ValueError('本份完整长图高度' + str(height) + '超过单张安全上限' + str(MAX_HEIGHT) + '像素，未拆分或截断。请先核对是否重复附入了极长资料。')
    return dict(width=WIDTH, height=height, cards=cards, source_rows=rows_count, rendered_rows=sum(len(c['rows']) for c in cards))


def draw_plan(Image, ImageDraw, plan, model, fonts, path):
    image = Image.new('RGB', (WIDTH, plan['height']), '#101414')
    draw = ImageDraw.Draw(image)
    # Quiet black/gold grain, generated locally, no screenshot / external assets.
    seed = 331
    for i in range(min(14000, math.ceil(WIDTH * plan['height'] / 1800))):
        seed = (seed * 1664525 + 1013904223) & 0xffffffff; x = seed % WIDTH
        seed = (seed * 1664525 + 1013904223) & 0xffffffff; y = seed % plan['height']
        draw.rectangle((x, y, x + i % 3, y + i % 2), fill='#24261f' if i % 9 == 0 else '#171b1b')
    def text(xy, value, size, color=WHITE, weight=400):
        draw.text(xy, value, font=fonts.get(size), fill=color, anchor='lt', stroke_width=1 if weight >= 600 else 0)
    text((62, 49), '蛋解课堂 · 六脉神剑', 26, GOLD, 600)
    title = model + ' ｜ 完整长图'
    text((WIDTH - 62 - measure(title, fonts.get(23)), 52), title, 23, MUTED)
    draw.line((62, 100, WIDTH - 62, 100), fill='#6d5b34')
    for card in plan['cards']:
        box = (card['x'], card['y'], card['x'] + card['width'], card['y'] + card['height'])
        draw.rounded_rectangle(box, radius=15, fill='#222019' if card['kind'] == 'hero' else '#181e1e', outline='#73613b' if card['kind'] == 'question' else '#3c4441', width=2 if card['kind'] == 'question' else 1)
        if card['kind'] == 'question':
            draw.rectangle((card['x'], card['y'] + 25, card['x'] + 3, card['y'] + 65), fill=GOLD)
        if card['title']:
            text((card['text_x'], card['y'] + 28), card['title'], 27, GOLD, 600)
        y = card['text_y']
        for row in card['rows']:
            text((card['text_x'], y), row['text'], row['size'], row['color'], row['weight'])
            y += row['lineHeight'] + row['gap']
        if y + 28 > card['y'] + card['height'] + .01:
            raise ValueError('卡片高度验证失败；未保存截断图片。')
    draw.line((62, plan['height'] - 77, WIDTH - 62, plan['height'] - 77), fill='#6d5b34')
    text((62, plan['height'] - 54), '蛋解课堂 · 六脉神剑', 21, MUTED)
    tail = model + '访谈大纲'
    text((WIDTH - 62 - measure(tail, fonts.get(21)), plan['height'] - 54), tail, 21, MUTED)
    image.save(path, format='PNG', optimize=False)
    image.close()
    with Image.open(path) as check:
        check.verify()
    with Image.open(path) as check:
        if check.size != (WIDTH, plan['height']):
            raise ValueError('PNG尺寸回读不一致。')


def safe_name(value):
    return re.sub(r'[\\/:*?"<>|\x00-\x1f]', '-', str(value)).rstrip('. ')[:52] or '访谈大纲'


def export(data, source_path, out, indices, Image, ImageDraw, ImageFont, pillow_version, font_path=None, font_index=None):
    if out.exists() and any(out.iterdir()):
        raise ValueError('输出目录已有内容，请指定新的空目录；不覆盖旧长图：' + str(out))
    if [o.get('model') for o in data.get('outlines', [])] != NAMES:
        raise ValueError('输入须为build.py生成的完整六份interview.json。')
    if data.get('schema_version') != '1.1':
        raise ValueError('interview.json须为schema_version 1.1。')
    if any([q.get('id') for q in o.get('questions', [])] != ['Q' + str(n) for n in range(1, 8)] for o in data['outlines']):
        raise ValueError('当前固定题库每份须完整Q1至Q7；输入缺题，不能绘成完整长图。')
    blocks = [(i, build_blocks(data, i)) for i in indices]
    characters = ''.join(b['title'] + ''.join(r['text'] for r in b['rows']) for _, bs in blocks for b in bs)
    characters += '蛋解课堂 · 六脉神剑 ｜ 完整长图蛋解访谈大纲'
    spec = choose_font(ImageFont, characters, font_path, font_index)
    fonts = Fonts(ImageFont, spec)
    plans = [(i, make_plan(bs, fonts)) for i, bs in blocks]
    out.mkdir(parents=True, exist_ok=True)
    images = []
    for i, plan in plans:
        name = safe_name(data['title']) + '-' + str(i + 1).zfill(2) + '-' + NAMES[i] + '.png'
        target = out / name
        draw_plan(Image, ImageDraw, plan, NAMES[i], fonts, target)
        images.append(dict(model=NAMES[i], index=i + 1, file=name, path=str(target.resolve()), width=WIDTH, height=plan['height'], bytes=target.stat().st_size,
                           sha256=hashlib.sha256(target.read_bytes()).hexdigest(), source_rows=plan['source_rows'], rendered_rows=plan['rendered_rows'], question_count=len(student_document(data)['outlines'][i]['questions']), followup_count=sum(len(q['followups']) for q in student_document(data)['outlines'][i]['questions']), backend_question_count=len(data['outlines'][i]['questions'])))
    zip_info = None
    if len(indices) == 6:
        zpath = out / (safe_name(data['title']) + '-六份完整长图.zip')
        with zipfile.ZipFile(zpath, 'w', compression=zipfile.ZIP_STORED) as archive:
            for item in images:
                archive.write(out / item['file'], item['file'])
        with zipfile.ZipFile(zpath) as archive:
            if archive.testzip() is not None or len(archive.infolist()) != 6:
                raise ValueError('ZIP回读校验失败，不能宣称六份已完整交付。')
        zip_info = dict(file=zpath.name, path=str(zpath.resolve()), bytes=zpath.stat().st_size, sha256=hashlib.sha256(zpath.read_bytes()).hexdigest(), image_count=6)
    receipt = dict(ok=True, export_version=VERSION, engine='Pillow', pillow_version=pillow_version, source_interview_json=str(source_path.resolve()),
                   source_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest(), font=spec, one_png_per_outline=True, images=images, zip=zip_info,
                   content_truth_verified=False, workbuddy_runtime_verified=False, note='本回执只核对文件绘制与回读；不是源卡事实、模型提取质量或WorkBuddy附件下载的验收。')
    (out / 'png-export-receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
    return receipt


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input', help='build.py生成的interview.json')
    ap.add_argument('--out', default='long-images', help='新的空输出目录')
    ap.add_argument('--index', type=int, choices=range(1, 7), help='只导出第1至6份之一；省略则六份PNG加ZIP')
    ap.add_argument('--font', help='已有中文TTF/OTF/TTC字体文件；不联网下载')
    ap.add_argument('--font-index', type=int, help='TTC字库索引；省略自动优先简体中文字体')
    args = ap.parse_args()
    try:
        try:
            import PIL
            from PIL import Image, ImageDraw, ImageFont
        except ImportError:
            raise ValueError('当前Python缺少Pillow，未生成PNG。请使用已有Pillow的Python环境；不会自动pip安装或联网。HTML及Markdown可继续使用。')
        if not hasattr(ImageFont.FreeTypeFont, 'getlength') or not hasattr(ImageDraw.ImageDraw, 'rounded_rectangle'):
            raise ValueError('当前Pillow ' + PIL.__version__ + ' 缺少所需排版API，请使用已有兼容Pillow的Python环境；不会自动安装或联网。')
        source = pathlib.Path(args.input)
        data = json.loads(source.read_text(encoding='utf-8-sig'))
        indices = [args.index - 1] if args.index else list(range(6))
        result = export(data, source, pathlib.Path(args.out), indices, Image, ImageDraw, ImageFont, PIL.__version__, args.font, args.font_index)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (ValueError, KeyError, TypeError, OSError, AssertionError) as exc:
        print(json.dumps(dict(ok=False, error=str(exc), note='未宣称完整导出；请检查输出目录，失败时不把已有文件当作六份完整结果。'), ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
