#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build six interview outlines from card facts and an audited neutral question bank."""
import argparse,copy,hashlib,json,pathlib,sys
import render as renderer
ROOT=pathlib.Path(__file__).resolve().parent.parent
GOALS={
 '缘起':'找到进入这一行的具体来路，以及它是否影响今天的做法。',
 '悟道':'还原旧判断、触发事实和认识如何改变，不要求编出大道理。',
 '求索':'围绕同一个真实问题，还原尝试、未达预期、修正与适用边界。',
 '取舍':'还原真实选项、判断、实际选择及代价，不预设道德优越。',
 '破局':'只聊本人创业经营遇到的坎、判断、已做动作和当前情况，不用客户交付难题替代。',
 '见证':'核对一个完成案例的原问题、本人和团队动作、实际变化、可核对材料及其他影响因素。'}
TITLES={'缘起':'一件走进这一行的事','悟道':'一次被现实改变的判断','求索':'同一个问题，怎样反复试','取舍':'一次真实选择与代价','破局':'自己的生意遇坎，怎样应对','见证':'一个能核对的客户过程'}
EDITS={
 '缘起':['具体入行场景','当时在意的事','实际入行动作','与今天做法有联系才保留'],
 '悟道':['旧认识','触发判断改变的具体事实','新认识','有真实改变才展示行动和观察'],
 '求索':['同一个问题','首次真实尝试','实际观察与调整','确有后续尝试才问变化','适用条件'],
 '取舍':['真实选项','各自吸引力','判断和选择','本人动作','愿公开的实际代价'],
 '破局':['自身经营困境','关键信号','已做的核查与判断','本人实际行动','当前情况及其他因素；没有转机也保留'],
 '见证':['客户原处境','本人和团队各做什么','实际变化或尚未知','可公开材料','其他影响因素与适用边界']}
def load_context(raw):
 if raw.get('schema_version')!='1.1':
  raise ValueError('context须为schema_version 1.1；请按context.md重新整理状态和无事件依据，不自动猜测迁移旧版资料')
 keys=['schema_version','mode','title','inputs','input_summary','sources','recommended_first']
 d={k:copy.deepcopy(raw[k]) for k in keys}
 d['outlines']=[]
 for x in raw['outlines']:
  o={k:copy.deepcopy(x[k]) for k in ['model','event_scope','status','event_anchor']}
  if 'absence_reason' in x:o['absence_reason']=copy.deepcopy(x['absence_reason'])
  d['outlines'].append(o)
 return d

def build(raw):
 c=load_context(raw);d=copy.deepcopy(c)
 bank_path=ROOT/'references/question-bank.json';bank=json.loads(bank_path.read_text(encoding='utf-8-sig'))
 business=d['input_summary']['business'];label=business.strip().rstrip('。')
 # Long industry descriptions stay in the card summary, not inside an awkward spoken question.
 if len(label)>20 or any(x in label for x in ['?','？','\n','\r']):label='这门生意'
 for o in d['outlines']:
  model=o['model'];state=o['status']
  renderer.validate_event_state(o,d['sources'])
  qs=copy.deepcopy(bank[model])
  for i,q in enumerate(qs):
   q['id']='Q'+str(i+1);q['ask']=q['ask'].replace('{business_label}',label)
   q['question_basis']='exploration';q['source_refs']=[]
  if state=='not_applicable':
   qs[0].update(ask='这个方向目前没有可用事件，你愿意先留存哪项过程记录？',capture='只确认愿意准备的取材记录，不要求今天有故事或结果。',followups=[{'when':'愿意安排记录','ask':'哪一项记录是你现在方便留存的？'},{'when':'没有记录或不想安排','ask':'那这一份先记为待补，可以吗？'}],stop_when='这类故事暂不展开；聊一件做过的小事，再换到其他话题，不结束整场。')
   if model=='见证':qs[0]['ask']='现在没有已完成案例，你愿意先留存哪项过程记录？'
   for q in qs[1:]:
    q['ask']=q['ask'].replace('仅在已确认本份真实事件后问：','')
    q['ask']=('仅在真实案例完成后问：' if model=='见证' else '仅在真实事件发生后问：')+q['ask']
  o.update(title=TITLES[model],goal=GOALS[model],audience_reason='面向'+d['input_summary']['audience']+'。本份取材重点：'+GOALS[model]+'这是采访设计的说明，不把它当成客户已陈述的顾虑。',interviewer_note=renderer.entry_gate(o)+'问题前的条件标签供采访者看，不必念给老板听。每次只选一条条件追问。',recording_minutes='约12—20分钟，可调整；取材不足时换角度或换话题。',questions=qs,recording_order='先核对资料中的事件与公开意愿，再按真实发生顺序聊。前提没有成立就停止该分支；没有这类经历就换个话题继续，不编未发生的事。',edit_order=EDITS[model],gaps=(['具体事件待访谈确定；未知不等于没有。'] if state=='discovery' else ['当前明确没有可用事件，只安排记录，不要求编出故事。'] if state=='not_applicable' else ['卡内记录仍需本人核对；未提供的细节或结果不自行补齐。']),materials=['如有且获准公开，可准备与本事件直接相关的同期去标识记录；没有原始记录就注明本人回忆，不制造证据。'],boundaries=d['input_summary']['public_boundaries']+['不预写老板回答，不把未知动作、动机或结果当事实。','想不起这类经历就换个角度；不愿谈这件事就换话题；没有改善不追成功。'])
 d['recommended_first']['reason']='结合当前卡内素材状态，建议先聊'+d['recommended_first']['model']+'；录制前仍须本人确认，不预测流量或成交。'
 d['generation_method']='neutral_question_bank_with_topic_switch_0.4.3'
 renderer.validate(d)
 return c,d,hashlib.sha256(bank_path.read_bytes()).hexdigest()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('--out',default='result');ap.add_argument('--validate-only',action='store_true');a=ap.parse_args()
 try:
  raw=json.loads(pathlib.Path(a.input).read_text(encoding='utf-8-sig'));c,d,h=build(raw)
  if not a.validate_only:
   out=pathlib.Path(a.out);renderer.render(d,out);(out/'context.json').write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8')
   receipt=json.loads((out/'validation.json').read_text());receipt.update(skill_version=renderer.STUDENT_VERSION,generation_method=d['generation_method'],question_bank_sha256=h,question_bank_count=6);(out/'validation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
  print(json.dumps({'ok':True,'outlines':6,'fixed_question_bank':True,'skill_version':renderer.STUDENT_VERSION,'long_image_export':True,'question_bank_sha256':h,'out':None if a.validate_only else str(pathlib.Path(a.out).resolve())},ensure_ascii=False))
 except (KeyError,ValueError,TypeError,OSError) as e:print('生成失败：'+str(e),file=sys.stderr);return 2
 return 0
if __name__=='__main__':sys.exit(main())
