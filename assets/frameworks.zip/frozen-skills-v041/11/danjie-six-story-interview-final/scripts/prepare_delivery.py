#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Assemble a student-only reply and native file list from verified real outputs.

Stdlib only. Reads PNG export receipts, explicit HTML paths and source JSON.
Does not generate images, change stories, overwrite source files, or register UI
attachments. The client agent must present the listed files and send the reply.
"""
import argparse
import hashlib
import html
from html.parser import HTMLParser
import json
import pathlib
import re
import shutil
import struct
import sys
import tempfile
import zipfile
import zlib

from render import STUDENT_VERSION, render as render_reading, student_document

VERSION = '0.4.3'
MODELS = ['缘起', '悟道', '求索', '取舍', '破局', '见证']


def need(ok, message):
    if not ok:
        raise ValueError(message)


def read_json(path):
    need(path.is_file(), '缺少文件：' + str(path))
    return json.loads(path.read_text(encoding='utf-8-sig'))


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def actual_file(path, description):
    p = pathlib.Path(path).expanduser().resolve()
    need(p.is_file(), '缺少' + description + '：' + str(p))
    return p, p.read_bytes()


def verify_png(data, expected_width, expected_height):
    need(data[:8] == b'\x89PNG\r\n\x1a\n', '文件不是有效PNG。')
    offset, kinds, dimensions = 8, [], None
    while offset < len(data):
        need(offset + 12 <= len(data), 'PNG数据不完整。')
        size = struct.unpack('>I', data[offset:offset + 4])[0]
        kind = data[offset + 4:offset + 8]
        end = offset + 12 + size
        need(end <= len(data), 'PNG分块不完整。')
        body = data[offset + 8:offset + 8 + size]
        checksum = struct.unpack('>I', data[offset + 8 + size:end])[0]
        need(zlib.crc32(kind + body) & 0xffffffff == checksum, 'PNG分块CRC不一致。')
        if not kinds:
            need(kind == b'IHDR' and size == 13, 'PNG缺少有效IHDR。')
            dimensions = struct.unpack('>II', body[:8])
        kinds.append(kind)
        offset = end
        if kind == b'IEND':
            need(size == 0 and offset == len(data), 'PNG结尾不完整或带额外数据。')
            break
    need(kinds and kinds[-1] == b'IEND' and b'IDAT' in kinds, 'PNG缺少图像数据或结尾。')
    need(dimensions == (expected_width, expected_height), 'PNG尺寸与回执不一致。')
    need(dimensions[0] == 1080 and 0 < dimensions[1] <= 30000, 'PNG尺寸超出本Skill单图范围。')


class FrontendData(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.in_data = False
        self.chunks = []
        self.count = 0

    def handle_starttag(self, tag, attrs):
        if tag == 'script' and dict(attrs).get('id') == 'interview-export-data':
            self.in_data = True
            self.count += 1

    def handle_endtag(self, tag):
        if tag == 'script':
            self.in_data = False

    def handle_data(self, data):
        if self.in_data:
            self.chunks.append(data)


def projection_difference(actual, expected, path='$'):
    """Return the first exact JSON field/type mismatch without exposing its text."""
    if type(actual) is not type(expected):
        return path + ' (type)'
    if isinstance(expected, dict):
        if set(actual) != set(expected):
            return path + ' (fields)'
        for key in expected:
            found = projection_difference(actual[key], expected[key], path + '.' + key)
            if found:
                return found
    elif isinstance(expected, list):
        if len(actual) != len(expected):
            return path + ' (length)'
        for index, (a, e) in enumerate(zip(actual, expected)):
            found = projection_difference(a, e, path + '[' + str(index) + ']')
            if found:
                return found
    elif actual != expected:
        return path
    return None


def verify_rendered_html(source, actual_html, expected_version):
    """Bind the delivered visible page and code to the current deterministic renderer."""
    with tempfile.TemporaryDirectory(prefix='danjie-delivery-') as directory:
        out = pathlib.Path(directory)
        render_reading(source, out)
        expected_html = (out / '蛋解六脉神剑访谈大纲.html').read_text(encoding='utf-8')
    if expected_version != VERSION:
        # Readback can align these two version labels only, never body or code.
        schema_label = '"frontend_schema":"' + VERSION + '"'
        code_label = "const VERSION = '" + VERSION + "';"
        need(expected_html.count(schema_label) == 1 and expected_html.count(code_label) == 1,
             '当前HTML版本标签不唯一，不能进行旧版回读。')
        expected_html = expected_html.replace(schema_label, '"frontend_schema":"' + expected_version + '"', 1)
        expected_html = expected_html.replace(code_label, "const VERSION = '" + expected_version + "';", 1)
    # Text mode writes native line endings on Windows; compare logical newlines.
    normalize = lambda value: value.replace('\r\n', '\n').replace('\r', '\n')
    need(normalize(actual_html) == normalize(expected_html),
         'HTML实际页面与当前源JSON渲染结果不一致，不能交付可见内容或代码被改写的阅读页。')


def verify_group(receipt_path, html_path, expected_version):
    receipt_path = pathlib.Path(receipt_path).expanduser().resolve()
    r = read_json(receipt_path)
    need(r.get('ok') is True, 'PNG回执没有完整成功：' + str(receipt_path))
    need(r.get('export_version') == expected_version, 'PNG版本不一致：' + str(receipt_path))
    need(r.get('one_png_per_outline') is True, '回执未确认每份单张PNG。')
    images = r.get('images')
    need(isinstance(images, list) and len(images) == 6, '每个业务必须有六张独立PNG，不能用ZIP或目录补位。')
    need([x.get('model') for x in images] == MODELS, 'PNG模型必须按缘起、悟道、求索、取舍、破局、见证齐全且不重复。')
    source_path, source_bytes = actual_file(r.get('source_interview_json', ''), '本组interview.json')
    need(sha256(source_bytes) == r.get('source_sha256'), '本组interview.json与PNG回执SHA不一致。')
    d = json.loads(source_bytes.decode('utf-8-sig'))
    title = d.get('title')
    need(isinstance(title, str) and title.strip(), '本组缺少已有业务标题。')
    need(d.get('mode') in ['real', 'fictional_demo'], '本组mode不明确，不能隐藏虚构标识。')
    hpath, hbytes = actual_file(html_path, 'HTML阅读页')
    need(hpath.parent == source_path.parent, 'HTML与本组源JSON不在同一结果目录，请核对显式输入路径。')
    parser = FrontendData()
    parser.feed(hbytes.decode('utf-8-sig'))
    need(parser.count == 1 and parser.chunks, 'HTML缺少唯一学员内容投影。')
    front = json.loads(''.join(parser.chunks))
    need(front.get('frontend_schema') == expected_version, 'HTML版本与本次交付版本不一致。')
    need(front.get('title') == title, 'HTML标题与本组图片源JSON不一致。')
    need([x.get('model') for x in front.get('outlines', [])] == MODELS, 'HTML没有齐全六脉内容。')
    need(STUDENT_VERSION == VERSION, '交付组装器与当前学员投影版本不一致。')
    expected_front = student_document(d)
    # A legacy receipt readback may align this version label only. Every title,
    # opening, question, condition, followup, closing and demo flag must still
    # exactly match the current projection of the bound source JSON.
    expected_front['frontend_schema'] = expected_version
    difference = projection_difference(front, expected_front)
    need(difference is None, 'HTML学员正文与当前源JSON投影不一致：' + str(difference))
    verify_rendered_html(d, hbytes.decode('utf-8-sig'), expected_version)
    pngs, png_bytes = [], {}
    for index, item in enumerate(images, 1):
        need(item.get('index') == index, 'PNG序号不连续。')
        path, data = actual_file(item.get('path', ''), item['model'] + 'PNG')
        need(path.parent == receipt_path.parent, 'PNG路径不属于当前回执目录：' + str(path))
        need(path.name == item.get('file'), 'PNG文件名与回执不一致。')
        need(len(data) == item.get('bytes'), item['model'] + 'PNG字节数与回执不一致。')
        need(sha256(data) == item.get('sha256'), item['model'] + 'PNG的SHA与回执不一致。')
        verify_png(data, item.get('width'), item.get('height'))
        pngs.append(dict(kind='png', model=item['model'], label=item['model'] + '长图', path=str(path)))
        png_bytes[path.name] = data
    need(len({p['path'] for p in pngs}) == 6, '六个模型没有对应六个独立PNG文件。')
    zinfo = r.get('zip')
    need(isinstance(zinfo, dict) and zinfo.get('image_count') == 6, '缺少已完成的六图ZIP回执。')
    zpath, zbytes = actual_file(zinfo.get('path', ''), '六图ZIP')
    need(zpath.parent == receipt_path.parent and zpath.name == zinfo.get('file'), 'ZIP路径或文件名与回执不一致。')
    need(len(zbytes) == zinfo.get('bytes') and sha256(zbytes) == zinfo.get('sha256'), 'ZIP字节数或SHA与回执不一致。')
    with zipfile.ZipFile(zpath) as archive:
        entries = archive.infolist()
        need(len(entries) == 6 and len({x.filename for x in entries}) == 6, 'ZIP不是六个独立文件。')
        need({x.filename for x in entries} == set(png_bytes), 'ZIP成员与六张实际PNG不一致。')
        need(all(not x.is_dir() and '/' not in x.filename and '\\' not in x.filename for x in entries), 'ZIP成员含不应交付的目录或路径。')
        for entry in entries:
            actual = png_bytes[entry.filename]
            need(entry.file_size == len(actual) and entry.CRC == zlib.crc32(actual) & 0xffffffff, 'ZIP内PNG的尺寸或CRC不一致。')
            need(archive.read(entry) == actual, 'ZIP内PNG与独立PNG字节不同。')
        need(archive.testzip() is None, 'ZIP回读CRC失败。')
    files = pngs + [dict(kind='zip', label='六张长图打包下载', path=str(zpath)), dict(kind='html', label='完整阅读页', path=str(hpath))]
    return dict(title=title.strip(), fictional_demo=d['mode'] == 'fictional_demo', files=files), dict(receipt=str(receipt_path), source=str(source_path), version=expected_version, images_checked=6, zip_crc_passed=True, files=[dict(path=x['path'], sha256=sha256(pathlib.Path(x['path']).read_bytes()), bytes=pathlib.Path(x['path']).stat().st_size) for x in files])


def markdown_text(value):
    text = html.escape(' '.join(str(value).splitlines()), quote=False)
    return re.sub(r'([\\`*_{}\[\]#|])', r'\\\1', text)


def file_link(label, path):
    # Native local-file links use exact filesystem paths, as does student-files.
    # Angle destinations support spaces; escape Markdown delimiters, not Unicode.
    target = pathlib.Path(path).resolve().as_posix()
    need(not any(ord(c) < 32 or ord(c) == 127 for c in target), '文件路径含控制字符，不能生成文字入口。')
    target = target.replace('\\', '\\\\').replace('<', '\\<').replace('>', '\\>')
    return '[' + markdown_text(label) + '](<' + target + '>)'


def assemble(groups, out, expected_version):
    need(groups, '至少需要一组真实PNG回执和HTML。')
    out = pathlib.Path(out).expanduser().resolve()
    need(not out.exists() or (out.is_dir() and not any(out.iterdir())), '交付目录已有内容，请指定新的空目录。')
    verified, audits, seen_receipts, seen_pngs = [], [], set(), set()
    # Verify every group before creating any successful reply or output directory.
    for receipt, html_path in groups:
        rp = str(pathlib.Path(receipt).expanduser().resolve())
        need(rp not in seen_receipts, '同一PNG回执重复输入，不能冒充多个业务。')
        group, audit = verify_group(receipt, html_path, expected_version)
        for f in group['files'][:6]:
            need(f['path'] not in seen_pngs, '不同业务重复使用同一PNG路径。')
            seen_pngs.add(f['path'])
        verified.append(group); audits.append(audit); seen_receipts.add(rp)
    need(len(seen_pngs) == 6 * len(groups), '独立PNG总数与业务组数不符。')
    # Byte-identical ASCII basenames avoid client URI encoding of Chinese filenames.
    # Keep every original file; native attachments and text links share these copies.
    out.mkdir(parents=True, exist_ok=True)
    aliases = []
    names = ['01-yuanqi.png', '02-wudao.png', '03-qiusuo.png',
             '04-qushe.png', '05-poju.png', '06-jianzheng.png',
             'six-interview-images.zip', 'index.html']
    for index, group in enumerate(verified, 1):
        folder = out / ('downloads-%02d' % index)
        folder.mkdir(exist_ok=False)
        for item, name in zip(group['files'], names):
            source = pathlib.Path(item['path'])
            destination = folder / name
            shutil.copy2(source, destination)
            need(sha256(source.read_bytes()) == sha256(destination.read_bytes()),
                 '下载副本与原文件不一致。')
            aliases.append(dict(source=str(source), download=str(destination),
                                sha256=sha256(destination.read_bytes())))
            if item['kind'] == 'html':
                for asset in ['style.css', 'texture.png', 'export.js']:
                    shutil.copy2(source.parent / asset, folder / asset)
            item['path'] = str(destination)
    (out / 'download-source-map.json').write_text(
        json.dumps(aliases, ensure_ascii=False, indent=2), encoding='utf-8')
    sections = []
    for group in verified:
        title = group['title'] + ('（虚构示例）' if group['fictional_demo'] else '')
        rows = ['### ' + markdown_text(title), '']
        rows.extend('- ' + file_link(f['label'], f['path']) for f in group['files'][:6])
        rows.extend(['', ' · '.join(file_link(f['label'], f['path']) for f in group['files'][6:])])
        sections.append('\n'.join(rows))
    reply = '\n\n'.join(sections) + '\n'
    out.mkdir(parents=True, exist_ok=True)
    reply_path = out / 'student_reply.md'
    list_path = out / 'student-files.json'
    reply_path.write_text(reply, encoding='utf-8')
    filelist = dict(groups=verified, files=[dict(label=g['title'] + '｜' + f['label'], kind=f['kind'], path=f['path']) for g in verified for f in g['files']])
    list_path.write_text(json.dumps(filelist, ensure_ascii=False, indent=2), encoding='utf-8')
    (out / 'delivery-validation.json').write_text(json.dumps(dict(ok=True, assembler_version=VERSION, expected_export_version=expected_version, groups=audits, group_count=len(groups), independent_png_count=len(seen_pngs), reply=str(reply_path), native_client_presentation_verified=False, note='只验证文件齐套和确定性交付文本，尚未验证模型最终采用或客户端实际呈现/保存。'), ensure_ascii=False, indent=2), encoding='utf-8')
    return reply_path, list_path


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--group', nargs=2, action='append', metavar=('PNG_RECEIPT', 'HTML'), required=True, help='一组真实png-export-receipt.json与实际HTML；多个业务重复此参数')
    ap.add_argument('--out', required=True, help='新的空交付目录')
    ap.add_argument('--expected-version', default=VERSION, help='默认严格本版；旧版回读仅对齐版本标签，全部正文仍须等于当前源JSON投影')
    args = ap.parse_args()
    try:
        reply, files = assemble(args.group, args.out, args.expected_version)
        print(json.dumps(dict(student_reply=str(reply), filelist=str(files)), ensure_ascii=False))
        return 0
    except (ValueError, KeyError, TypeError, OSError, UnicodeError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        print('未生成完整交付模板：' + str(exc), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
