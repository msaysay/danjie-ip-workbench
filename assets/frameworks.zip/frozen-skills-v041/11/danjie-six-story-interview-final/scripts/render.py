#!/usr/bin/env python3
"""Validate one six-outline JSON and render self-contained local reading files. Stdlib only."""
import argparse,html,json,pathlib,re,shutil,sys
NAMES=['缘起','悟道','求索','取舍','破局','见证']
SCOPES=['owner_origin','owner_belief_change','owner_exploration','owner_tradeoff','owner_business','customer_case']
LABEL={'ready':'已有事件，采访前须确认公开意愿','discovery':'待访谈发掘真实事件','responding':'正在应对，转机未确认','not_applicable':'已明确当前无事件，先补材料'}
def need(ok,msg):
 if not ok:raise ValueError(msg)
def text(v):return isinstance(v,str) and bool(v.strip())
def one_focus(s):
 patterns=[r'(哪个月|什么时间|哪段时间).*(哪个指标|什么口径|什么指标|记录)',r'(什么口径|哪个指标).*(记录|哪段时间|哪个月)',r'停了什么.*(启动|开始|又做)',r'发生了什么.*怎么做']
 return s.count('？')+s.count('?')<=1 and not any(re.search(p,s) for p in patterns)
def neutral_question(s):
 # Keep open prompts open; common hidden premises are rejected in both main and follow-up questions.
 return not (re.search(r'是[^？?]{0,80}还是',s) or any(v in s for v in ['具体好在哪','确认确实有效','除了习惯','除了喜欢','除了合规','除了满意']))
def validate_event_state(o,sources):
 """Check explicit state tags and quoted provenance, not natural-language truth."""
 state=o.get('status');model=o.get('model','未知模型');e=o.get('event_anchor',{})
 paired={'ready':'reported','responding':'reported','discovery':'pending','not_applicable':'none'}
 need(state in paired,'模型状态无效')
 need(e.get('status')==paired[state],model+'状态须配对：'+state+'/'+paired[state])
 reason=o.get('absence_reason')
 if state!='not_applicable':
  need(reason is None,model+'并非明确无事件，不能保留absence_reason；未知或拒答不等于没有')
  return
 need(isinstance(reason,dict),model+'缺少absence_reason；无事件须给出明确否定类型和来源原文，不依据未知、未记录或拒答推断')
 expected='explicit_no_completed_case' if model=='见证' else 'explicit_no_event'
 need(reason.get('kind')==expected,model+'absence_reason.kind须为'+expected+'；未知、未记录、拒答或不能公开不能充当无事件')
 ref=reason.get('source_ref');quote=reason.get('quote');source_by_id={s.get('id'):s for s in sources}
 need(text(ref) and ref in source_by_id,model+'无事件依据来源缺失或悬空')
 need(isinstance(e.get('source_refs'),list) and ref in e['source_refs'],model+'无事件依据须同时列入event_anchor.source_refs')
 need(text(quote) and quote in source_by_id[ref].get('summary',''),model+'无事件依据quote须逐字存在于所引sources.summary；不能补造或只写解释')
def validate(d):
 need(d.get('schema_version')=='1.1','schema_version应为1.1；旧context须按context.md重新整理，不自动猜测迁移')
 need(d.get('mode') in ['real','fictional_demo'],'mode无效')
 need(text(d.get('title')),'缺少title')
 inp=d.get('inputs',{})
 for k in ['persona','audience']:
  a=inp.get(k,{});need(all(text(a.get(v)) for v in ['id','version','file','status']),'输入卡信息缺失: '+k)
  need(a['status'] in ['read','missing'],'输入卡status无效')
 need(any(inp[k]['status']=='read' for k in inp),'两卡均未读，不能生成定制结果')
 ss=d.get('input_summary',{})
 for k in ['business','owner_role','audience','payer','decision_maker','user']:need(text(ss.get(k)),'缺少输入摘要: '+k)
 for k in ['concerns','public_boundaries','conflicts']:need(isinstance(ss.get(k),list),'缺少摘要列表: '+k)
 src=d.get('sources');need(isinstance(src,list) and src,'缺少sources')
 ids=[]
 for s in src:
  need(all(text(s.get(k)) for k in ['id','file','location','kind','summary']),'来源字段缺失')
  need(s['kind'] in ['persona','audience','user_statement'],'来源kind无效');ids.append(s['id'])
 need(len(ids)==len(set(ids)),'来源ID重复')
 def refs(a,required=False):
  need(isinstance(a,list),'source_refs必须为数组');need(all(x in ids for x in a),'存在悬空source_refs')
  if required:need(bool(a),'事实或来源型问题必须有source_refs')
 for c in ss['concerns']:
  need(text(c.get('text')) and c.get('status') in ['reported','candidate','unknown'],'顾虑状态无效');refs(c.get('source_refs'),c['status']!='unknown')
 rr=d.get('recommended_first',{});need(rr.get('model') in NAMES and text(rr.get('reason')),'推荐模型无效')
 a=d.get('outlines');need(isinstance(a,list) and [x.get('model') for x in a]==NAMES,'必须按顺序交付六个不同模型')
 for i,o in enumerate(a):
  need(o.get('event_scope')==SCOPES[i],o['model']+'事件范围错误')
  need(o.get('status') in LABEL,'模型状态无效')
  for k in ['title','audience_reason','goal','interviewer_note','recording_minutes','recording_order']:need(text(o.get(k)),'缺少字段: '+k)
  e=o.get('event_anchor',{});need(text(e.get('text')) and e.get('status') in ['reported','pending','none'],'事件锚点无效');refs(e.get('source_refs'),e['status']=='reported')
  validate_event_state(o,src)
  qs=o.get('questions');need(isinstance(qs,list) and 6<=len(qs)<=8,o['model']+'应有6—8个主问')
  need([q.get('id') for q in qs]==['Q'+str(j+1) for j in range(len(qs))],'题号必须连续')
  need(len({q.get('ask') for q in qs})==len(qs),'主问重复')
  if o['model']=='见证' and o['status']=='not_applicable':
   need(not re.search(r'有没有.*(客户|案例)',qs[0]['ask']),'已知无客户案例不能重问有没有')
   for q in qs[1:]:
    need(q['ask'].startswith('仅在真实案例完成后问：'),'无案例的后续题须明确仅在真实案例完成后问')
    need(not any(v in q['ask'] for v in ['你打算','你希望','你期待','你最想','你会负责']),'不能预测未来客户案例结果或动作')
  for q in qs:
   for k in ['ask','capture','stop_when','visual']:need(text(q.get(k)),'问题缺少字段: '+k)
   need(one_focus(q['ask']),'主问含多个问句: '+q['ask'])
   need(neutral_question(q['ask']),'主问带猜测选项或预设动机/改善: '+q['ask'])
   need(q.get('question_basis') in ['sourced','exploration'],'question_basis无效');refs(q.get('source_refs'),q['question_basis']=='sourced')
   ff=q.get('followups');need(isinstance(ff,list) and 1<=len(ff)<=3,'每题应有1—3个条件追问')
   for f in ff:
    need(text(f.get('when')) and text(f.get('ask')),'条件追问字段缺失')
    need(one_focus(f['ask']),'追问含多个问句')
    need(neutral_question(f['ask']),'追问带猜测选项或预设动机/改善: '+f['ask'])
  for k in ['edit_order','gaps','materials','boundaries']:need(isinstance(o.get(k),list) and all(text(v) for v in o[k]),'无效列表: '+k)
 return d
E=lambda v:html.escape(str(v),quote=True)
def p(v):return '<p>'+E(v).replace('\n','<br>')+'</p>'
def ul(a):return '<ul>'+''.join('<li>'+E(v)+'</li>' for v in a)+'</ul>' if a else '<p class="muted">暂无新增项目</p>'
def cardinfo(d):
 return '\n'.join({'persona':'人设卡','audience':'客群卡'}[k]+'：'+d['inputs'][k]['file']+' ｜ ID '+d['inputs'][k]['id']+' ｜ 版本 '+d['inputs'][k]['version']+' ｜ '+('已读取' if d['inputs'][k]['status']=='read' else '未提供') for k in ['persona','audience'])
def source_md(d):return '\n'.join('- '+x['id']+' ｜ '+x['file']+' ｜ '+x['location']+' ｜ '+x['summary'] for x in d['sources'])
def absence_text(o):
 r=o.get('absence_reason')
 return ('当前无事件依据：'+r['source_ref']+' ｜ 原文：'+r['quote']) if r else ''
def entry_gate(o):
 if o['status']=='discovery':return '先确认一件真实、可聊的事件。没有找到就换个角度帮他回忆；不愿聊这件事就换话题；后续“当时、后来、结果”问题仅在前序已确认事件后使用。'
 if o['status']=='not_applicable':return '当前没有可用事件。先安排取材，不把以下条件题当作已发生的事来问；仅在真实事件出现并确认可聊后继续。'
 if o['status']=='responding':return '这件事仍在应对。只问已发生的动作和当前进展；没有转机或结果就如实保留，不用讲成成功故事。'
 return '先核对卡中事件是否准确、本人是否愿意聊。若前提不成立，停下来澄清，不顺着预设继续问；不要求回答符合预想。'
STUDENT_VERSION='0.4.3'
def spoken_prompts():
 return json.loads((pathlib.Path(__file__).resolve().parent.parent/'references/spoken-prompts.json').read_text(encoding='utf-8'))
def _spoken_main(o,q):
 return spoken_prompts()['questions'][o['model']][int(q['id'][1:])-1]

def chat_words(value):
 for old,new in [('实际观察到','看到'),('实际相信的','原来相信的'),('判断依据','为什么这么想'),('哪项事实','哪件事'),('处境','情况'),('原判断','原来的想法'),('先只还原那一次','先说那一次'),('在哪段实际使用过程中看到的','什么时候看到的'),('实际','')]:
  value=value.replace(old,new)
 return value

def _spoken_followup(o,q,f):
 """Keep useful answer-trigger hints; remove repeated internal recording branches."""
 when,ask=f['when'],f['ask']
 if q['id']=='Q1' and ask==spoken_prompts()['transitions'][o['model']]:return None
 if q['id']!='Q1' and any(token in ask for token in ['依赖这一步的后续','依赖它的后续']):return None
 if '先记为待补' in ask:
  return {'when':'没有可聊的经历，或不想讲' if o['status']!='not_applicable' else '暂时没有，或不想留记录','ask':spoken_prompts()['transitions'][o['model']]}
 if '如实记为应对中' in ask:return {'when':'还没好转','ask':'现在最让你费心的，是哪件还没解决的事？'}
 if when=='本人明确没有参与':return {'when':'没有亲自参与','ask':'有没有你能确认、也愿意讲的团队过程？'}
 if when=='本人不愿回答是否参与':return {'when':'不想谈自己的参与','ask':'那我们只聊你愿意公开的团队过程，好吗？'}
 if '讲到客户难题但是否影响自己经营' in when:return {'when':'只聊到客户的难题','ask':'这件事有没有影响你自己的生意？'}
 if '只说得到外部帮助' in when:return {'when':'只说别人提供了帮助','ask':'你自己当时有没有采取过行动？'}
 # These hints describe an actual answer, rather than program state.
 when=when.replace('已确认','').replace('确认','').replace('已经','').replace('前题','').replace('但','，但')
 when=when.replace('背景讲得很大','背景太笼统').replace('愿意安排记录','愿意留记录').replace('一直说我们','一直说“我们”').replace('全用我们概括','只说“我们”').replace('作过决定，但没有说清内容','作过决定，但没讲清内容')
 return {'when':chat_words(when),'ask':chat_words(ask)}

def add_followup_coaching(o, questions):
 # Prompt alternatives are keyed to the fixed main question. They are not facts.
 bank=json.loads((pathlib.Path(__file__).resolve().parent.parent/'references/followup-coaching.json').read_text(encoding='utf-8'))
 rows=bank['见证-无完成案例' if o['status']=='not_applicable' else o['model']]
 for q in questions:
  row=rows[int(q['id'][1:])-1]
  when,pull,c1,a1,c2,a2,enough=row
  q['followups']=[{'when':'聊远了｜'+when,'ask':pull},{'when':'没讲具体｜'+c1,'ask':a1},{'when':'再问一句｜'+c2,'ask':a2}]+q['followups']
  q['enough']=enough
  for f in q['followups']:
   f['when']=chat_words(f['when']);f['ask']=chat_words(f['ask'])
 return questions

def student_outline(o):
 """Short spoken questions; prerequisites are separate interviewer hints."""
 bank=spoken_prompts();model=o['model']
 if o['status']=='not_applicable':
  opening='先聊聊最近做过的一件小事。'
  q=o['questions'][0]
  follows=[{'when':'愿意讲一件小事','ask':'就说最近那一次，你做了什么？'},{'when':'不方便讲工作细节','ask':'没关系，那换一个你方便讲的话题。'}]
  questions=[{'id':'Q1','ask':'最近工作中，有没有一件你亲手做过的小事？','hint':('先聊做过的小事，别问还没发生的结果。' if model=='见证' else '这类事没经历过，就换聊别的事。'),'followups':[f for f in follows if f]}]
 else:
  opening=bank['openings'][model]
  questions=[]
  for q in o['questions']:
   follows=[_spoken_followup(o,q,f) for f in q['followups']]
   if q['id']=='Q1':
    recall={'缘起':'不一定是大事。你还记得最早接触这一行时的一件小事吗？','悟道':'不一定是大变化。最近有没有一次，你发现事情跟原来想的不一样？','求索':'从最近说起，有没有哪个问题，你换过一种做法？','取舍':'从小事说起，最近有没有哪个决定让你犹豫过？','破局':'不一定是大危机。最近做生意，有没有哪件事让你犯过难？','见证':'不用讲最成功的。有没有一位已经做完服务、又方便讲的客户？'}
    follows += [{'when':'一时想不起来','ask':recall[model]},{'when':'确实没有这类经历，或这件事不方便讲','ask':bank['transitions'][model]}]
   questions.append({'id':q['id'],'ask':_spoken_main(o,q),'hint':bank['conditions'][model][int(q['id'][1:])-1],'followups':[f for f in follows if f]})
 opening+='想不起来就换个小事，不方便讲就换个话题。'
 questions=add_followup_coaching(o,questions)
 return {'model':model,'title':o['title'],'opening':opening,'questions':questions,'closing':('这段先记下来。还有哪件你想让客户了解的事？' if o['status']=='not_applicable' else bank['transitions'][model])}

def simplify_interviewer_notes(view):
 # Only interviewer-facing notes change; never rephrase the spoken question here.
 mapping=json.loads((pathlib.Path(__file__).resolve().parent.parent/'references/legacy-note-wording.json').read_text(encoding='utf-8'))
 for q in view['questions']:
  for f in q['followups']:
   f['when']=mapping.get(f['when'],f['when']).replace('聊远了｜','如果聊偏了：').replace('没讲具体｜','如果没讲具体：').replace('再问一句｜','如果还想多问一句：')
   if not f['when'].startswith('如果'):f['when']='如果'+f['when']
 return view

def student_document(d):
 return {'frontend_schema':STUDENT_VERSION,'title':d['title'],'demo_note':'虚构演示，不是真实学员或客户经历。' if d['mode']=='fictional_demo' else '', 'outlines':[simplify_interviewer_notes(student_outline(o)) for o in d['outlines']]}
def markdown(d,o):
 view=simplify_interviewer_notes(student_outline(o))
 s=['# '+d['title'],'','## '+view['model']+'｜'+view['title'],'']
 if d['mode']=='fictional_demo':s+=['> 虚构演示，不是真实学员或客户经历。','']
 s+=['### 开场',view['opening']]
 for q in view['questions']:
  s+=['','### '+q['id']+' '+q['ask']]
  s+=['> 提示（不念）：'+q['hint']]
  s+=['- **'+f['ask']+'**  — 提示：'+f['when'] for f in q['followups']]
  s+=['**聊清楚这些就够了：** '+q['enough']]
 s+=['','### 换个话题继续',view['closing'],''];return '\n'.join(s)
def render(d,out):
 out.mkdir(parents=True,exist_ok=True);assets=pathlib.Path(__file__).resolve().parent.parent/'assets'
 for n in ['style.css','texture.png','export.js']:shutil.copyfile(assets/n,out/n)
 nav='<nav>'+''.join('<a href="#m'+str(i)+'">'+n+'</a>' for i,n in enumerate(NAMES))+'</nav>'
 front=student_document(d)
 body='<main><header><div class="eyebrow">蛋解课堂 · 六脉神剑</div><h1>'+E(d['title'])+'</h1>'+(p(front['demo_note']) if front['demo_note'] else '')+nav+'<div class="reading-key"><strong>大字问句：直接问</strong><span>灰色小字：只给提问者看，不用念</span></div><div class="export-tools"><button type="button" data-export-all>下载六份长图</button></div></header>'
 for i,o in enumerate(d['outlines']):
  view=front['outlines'][i]
  body+='<section class="model" id="m'+str(i)+'"><div class="outline-title">'+E(front['title'])+'</div><div class="heading"><span class="num">0'+str(i+1)+'</span><h2>'+E(view['model']+'｜'+view['title'])+'</h2></div><button type="button" class="export-one" data-export-outline="'+str(i)+'">下载本份长图</button><div class="card"><h3>开场</h3>'+p(view['opening'])+'</div>'
  for q in view['questions']:
   body+='<article class="question"><div class="question-kicker">主问 '+E(q['id'][1:])+'</div><h3 class="ask-main">'+E(q['ask'])+'</h3><p class="interviewer-hint"><span>给你看的，不用念</span>'+E(q['hint'])+'</p><div class="follow-title">按回答选一句追问</div><div class="follow">'+''.join('<div class="follow-row"><div class="follow-trigger">'+E(f['when'])+'</div><p class="ask-follow">'+E(f['ask'])+'</p></div>' for f in q['followups'])+'</div><div class="stop"><span>听到这些，就换下一题</span>'+E(q['enough'])+'</div></article>'
  body+='<div class="card"><h3>换个话题继续</h3>'+p(view['closing'])+'</div></section>'
  (out/(f'{i+1:02d}-'+o['model']+'-访谈大纲.md')).write_text(markdown(d,o),encoding='utf-8')
 body+='</main>'
 # Inline data and code keep downloads usable from a local HTML file without fetch/CORS/CDNs.
 data_json=json.dumps(front,ensure_ascii=False,separators=(',',':')).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
 export_script=(assets/'export.js').read_text(encoding='utf-8')
 feedback='<aside class="export-feedback" id="export-feedback" hidden><button type="button" class="export-dismiss" id="export-dismiss" aria-label="收起下载提示">收起</button><p id="export-status" aria-live="polite" role="status"></p><div id="export-save"></div></aside>'
 scripts='<script type="application/json" id="interview-export-data">'+data_json+'</script><script>'+export_script+'</script><script>DanjieInterviewExport.mount(JSON.parse(document.getElementById("interview-export-data").textContent));</script>'
 (out/'蛋解六脉神剑访谈大纲.html').write_text('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+E(d['title'])+'</title><link rel="stylesheet" href="style.css"></head><body>'+body+feedback+scripts+'</body></html>',encoding='utf-8')
 (out/'interview.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
 overview='# '+front['title']+'\n\n'+('> '+front['demo_note']+'\n\n' if front['demo_note'] else '')+'\n'.join('- '+o['model']+'｜'+o['title'] for o in front['outlines'])+'\n'
 (out/'00-总览.md').write_text(overview,encoding='utf-8')
 (out/'validation.json').write_text(json.dumps({'structure_passed':True,'outline_count':6,'question_counts':{o['model']:len(o['questions']) for o in d['outlines']},'mode':d['mode'],'export_version':STUDENT_VERSION,'student_frontend':True,'backend_provenance_preserved':True,'long_image_export':{'engine':'offline_canvas','width':1080,'all_download':'single_zip','max_single_image_height':30000,'one_png_per_outline':True,'runtime_verified':False},'content_truth_verified':False,'note':'本地预览，待WorkBuddy原生生成与保存复测；结构校验不是事实核验或最终验收。'},ensure_ascii=False,indent=2),encoding='utf-8')
def main():
 a=argparse.ArgumentParser();a.add_argument('input');a.add_argument('--out',default='result');a.add_argument('--validate-only',action='store_true');args=a.parse_args()
 try:
  d=validate(json.loads(pathlib.Path(args.input).read_text(encoding='utf-8-sig')))
  if not args.validate_only:render(d,pathlib.Path(args.out))
  print(json.dumps({'ok':True,'outline_count':6,'out':None if args.validate_only else str(pathlib.Path(args.out).resolve())},ensure_ascii=False))
 except (ValueError,KeyError,TypeError,OSError) as e:print('生成失败：'+str(e),file=sys.stderr);return 2
 return 0
if __name__=='__main__':sys.exit(main())
