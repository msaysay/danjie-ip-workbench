/* 蛋解课堂：离线 Canvas 长图与 ZIP 导出。无网络请求、无外部图片、无截图依赖。 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.DanjieInterviewExport = api;
})(typeof globalThis === 'undefined' ? this : globalThis, function () {
  'use strict';
  const VERSION = '0.4.3';
  const WIDTH = 1080;
  const DEFAULT_MAX_HEIGHT = 30000;
  const FONT = '"PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC", sans-serif';
  const COLORS = {gold:'#e6c474',white:'#f3f1e9',muted:'#bbc3c2',faint:'#8d9795'};
  const S = (v) => v == null ? '' : String(v);
  const font = (size,weight) => `${weight || 400} ${size}px ${FONT}`;
  const cleanName = (v) => Array.from(S(v).replace(/[\\/:*?"<>|\u0000-\u001f]/g,'-').replace(/[. ]+$/g,'')).slice(0,52).join('') || '访谈大纲';
  const line = (value,style) => Object.assign({text:S(value),size:31,lineHeight:48,weight:400,color:COLORS.white,gap:10},style || {});
  const list = (items,style) => (items && items.length ? items : ['暂无新增项目']).map((v)=>line('• '+S(v),style));
  function makeBlocks(data,index) {
    if (!data || !Array.isArray(data.outlines) || !data.outlines[index]) throw new Error('未找到这份大纲的数据。');
    if(data.frontend_schema!==VERSION)throw new Error('请用本版Skill重新生成访谈大纲。');
    const o=data.outlines[index];
    const blocks=[];
    const add=(title,rows,kind)=>blocks.push({title,rows,kind:kind || 'card'});
    add('',[
      line(data.title,{size:27,lineHeight:42,color:COLORS.muted,gap:18}),
      line(o.model,{size:64,lineHeight:88,weight:700,color:COLORS.gold,gap:8}),
      line(o.title,{size:43,lineHeight:62,weight:600,gap:18}),
      ...(data.demo_note?[line(data.demo_note,{size:25,lineHeight:39,color:COLORS.muted})]:[])
    ],'hero');
    add('开场',[line(o.opening)]);
    o.questions.forEach((q)=>{
      const rows=[line(q.ask,{size:46,lineHeight:68,weight:700,gap:18})];
      rows.push(line('给你看的，不用念',{size:20,lineHeight:30,color:COLORS.muted,gap:2}),line(q.hint,{size:22,lineHeight:35,color:COLORS.muted,gap:20}));
      q.followups.forEach((f)=>rows.push(line(f.when,{size:21,lineHeight:33,color:COLORS.muted,gap:2}),line(f.ask,{size:34,lineHeight:53,weight:500,gap:22})));
      rows.push(line('听到这些，就换下一题',{size:19,lineHeight:30,color:COLORS.muted,gap:2}),line(q.enough,{size:21,lineHeight:34,color:COLORS.muted}));
      add('主问 '+q.id.slice(1),rows,'question');
    });
    add('换个话题继续',[line(o.closing)]);
    return blocks;
  }
  // Break by Unicode code point, preserving every character and explicit newline.
  // Prefer not to leave closing Chinese punctuation at the start of the next line.
  function wrapText(ctx,text,maxWidth) {
    if (!(maxWidth>0)) throw new Error('长图可用文字宽度无效。');
    const result=[];
    const paragraphs=S(text).replace(/\r\n?/g,'\n').split('\n');
    paragraphs.forEach((para)=>{
      if(!para){result.push('');return;}
      let current='';
      for(const ch of Array.from(para)) {
        if(current && ctx.measureText(current+ch).width>maxWidth) {
          if(/^[，。！？；：、）》」』】〕〉,.!?;:)]$/.test(ch) && Array.from(current).length>1) {
            const chars=Array.from(current),last=chars.pop();
            result.push(chars.join(''));current=last+ch;
          } else {result.push(current);current=ch;}
        } else current+=ch;
      }
      if(current) result.push(current);
    });
    return result;
  }
  function measureBlocks(blocks,ctx,contentWidth) {
    return blocks.map((b)=>{
      const rows=[];
      b.rows.forEach((p)=>{
        ctx.font=font(p.size,p.weight);
        const lines=wrapText(ctx,p.text,contentWidth);
        lines.forEach((t,i)=>rows.push(Object.assign({},p,{text:t,gap:i===lines.length-1?p.gap:0})));
      });
      return {title:b.title,kind:b.kind,rows};
    });
  }
  function makePlan(data,index,ctx,options) {
    const opts=options || {},width=opts.width || WIDTH,maxHeight=opts.maxHeight || DEFAULT_MAX_HEIGHT;
    if(width!==WIDTH) throw new Error('长图固定为1080像素宽，避免缩小后中文难读。');
    if(!Number.isFinite(maxHeight) || maxHeight<1800 || maxHeight>32000) throw new Error('分段高度须为1800至32000像素。');
    const margin=58,padding=28,top=138,bottom=106,gap=20;
    const outerWidth=width-margin*2,innerWidth=outerWidth-padding*2;
    const blocks=measureBlocks(makeBlocks(data,index),ctx,innerWidth);
    const pages=[];
    let page={cards:[],height:0},y=top;
    const titleHeight=(title)=>title?53:0;
    const newPage=()=>{if(page.cards.length){page.height=Math.ceil(y+bottom);pages.push(page);}page={cards:[],height:0};y=top;};
    blocks.forEach((b)=>{
      let offset=0,continued=false;
      const rowHeight=(r)=>r.lineHeight+r.gap;
      const whole=padding*2+titleHeight(b.title)+b.rows.reduce((n,r)=>n+rowHeight(r),0);
      if(y>top && whole<=maxHeight-top-bottom && y+whole+bottom>maxHeight) newPage();
      while(offset<b.rows.length) {
        const title=b.title+(continued?'（续）':''),head=padding+titleHeight(title),remaining=maxHeight-bottom-y-head-padding;
        if(remaining<100 && page.cards.length){newPage();continue;}
        let end=offset,used=0;
        while(end<b.rows.length && used+rowHeight(b.rows[end])<=remaining){used+=rowHeight(b.rows[end]);end++;}
        if(end===offset) throw new Error('单行文字超出分段高度，无法安全导出。');
        const height=head+used+padding;
        page.cards.push({x:margin,y,width:outerWidth,height,title,kind:b.kind,rows:b.rows.slice(offset,end),textX:margin+padding,textY:y+head});
        y+=height+gap;offset=end;
        if(offset<b.rows.length){continued=true;newPage();}
      }
    });
    newPage();
    pages.forEach((p,i)=>{p.part=i+1;p.totalParts=pages.length;p.height=Math.min(maxHeight,Math.max(900,p.height));});
    return {version:VERSION,width,maxHeight,model:data.outlines[index].model,index,title:data.title,pages,sourceRowCount:blocks.reduce((n,b)=>n+b.rows.length,0),renderedRowCount:pages.reduce((n,p)=>n+p.cards.reduce((a,c)=>a+c.rows.length,0),0)};
  }
  function roundRect(ctx,x,y,w,h,r) {
    const q=Math.min(r,w/2,h/2);ctx.beginPath();ctx.moveTo(x+q,y);ctx.lineTo(x+w-q,y);ctx.quadraticCurveTo(x+w,y,x+w,y+q);ctx.lineTo(x+w,y+h-q);ctx.quadraticCurveTo(x+w,y+h,x+w-q,y+h);ctx.lineTo(x+q,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-q);ctx.lineTo(x,y+q);ctx.quadraticCurveTo(x,y,x+q,y);ctx.closePath();
  }
  function drawBackground(ctx,w,h) {
    ctx.fillStyle='#101414';ctx.fillRect(0,0,w,h);
    const shade=ctx.createLinearGradient(0,0,w,h);shade.addColorStop(0,'#1b2020');shade.addColorStop(.45,'#101414');shade.addColorStop(1,'#28241a');ctx.fillStyle=shade;ctx.fillRect(0,0,w,h);
    // Deterministic ink-grain and quiet gold accents; never read remote / local image pixels.
    let seed=331;
    for(let i=0;i<Math.min(14000,Math.ceil(w*h/1800));i++){seed=(seed*1664525+1013904223)>>>0;const x=seed%w;seed=(seed*1664525+1013904223)>>>0;const y=seed%h;ctx.fillStyle=i%9===0?'rgba(230,196,116,.055)':'rgba(255,255,255,.014)';ctx.fillRect(x,y,1+(i%3),1+(i%2));}
    ctx.strokeStyle='rgba(230,196,116,.14)';ctx.lineWidth=1;
    for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(-100,h-38-i*19);ctx.bezierCurveTo(w*.3,h-200-i*22,w*.68,h+100-i*20,w+100,h-160-i*30);ctx.stroke();}
  }
  function drawPage(plan,pageIndex,canvas) {
    const p=plan.pages[pageIndex];if(!p) throw new Error('长图分段不存在。');
    canvas.width=plan.width;canvas.height=p.height;
    const ctx=canvas.getContext('2d');if(!ctx) throw new Error('当前预览器不支持Canvas绘图，请用系统浏览器打开HTML。');
    ctx.textBaseline='top';drawBackground(ctx,plan.width,p.height);
    ctx.fillStyle=COLORS.gold;ctx.font=font(26,600);ctx.fillText('蛋解课堂 · 六脉神剑',62,49);
    ctx.fillStyle=COLORS.muted;ctx.font=font(23,400);const part=p.totalParts>1?`连续长图 ${p.part} / ${p.totalParts}`:'完整长图';ctx.textAlign='right';ctx.fillText(plan.model+' ｜ '+part,plan.width-62,52);ctx.textAlign='left';
    ctx.fillStyle='#6d5b34';ctx.fillRect(62,100,plan.width-124,1);
    p.cards.forEach((card)=>{
      roundRect(ctx,card.x,card.y,card.width,card.height,15);ctx.fillStyle=card.kind==='hero'?'rgba(34,32,25,.96)':'rgba(24,30,30,.97)';ctx.fill();ctx.strokeStyle=card.kind==='question'?'#73613b':'#3c4441';ctx.lineWidth=card.kind==='question'?1.6:1;ctx.stroke();
      if(card.kind==='question'){ctx.fillStyle=COLORS.gold;ctx.fillRect(card.x,card.y+25,4,40);}
      if(card.title){ctx.font=font(27,600);ctx.fillStyle=COLORS.gold;ctx.fillText(card.title,card.textX,card.y+28);}
      let yy=card.textY;
      card.rows.forEach((r)=>{ctx.font=font(r.size,r.weight);ctx.fillStyle=r.color;ctx.fillText(r.text,card.textX,yy);yy+=r.lineHeight+r.gap;});
    });
    ctx.fillStyle='#6d5b34';ctx.fillRect(62,p.height-77,plan.width-124,1);
    ctx.font=font(21,400);ctx.fillStyle=COLORS.muted;ctx.fillText('蛋解课堂 · 六脉神剑',62,p.height-54);
    ctx.textAlign='right';ctx.fillText(p.totalParts>1?`第 ${p.part} 段 / 共 ${p.totalParts} 段`:plan.model+'访谈大纲',plan.width-62,p.height-54);ctx.textAlign='left';
    return canvas;
  }
  function defaultCanvasFactory(w,h){if(typeof document==='undefined') throw new Error('需要浏览器Canvas或显式canvasFactory。');const c=document.createElement('canvas');c.width=w;c.height=h;return c;}
  async function defaultEncodePng(canvas){
    if(typeof canvas.toBlob!=='function') throw new Error('当前预览器不支持PNG导出，请用系统浏览器打开HTML。');
    const blob=await new Promise((resolve,reject)=>{try{canvas.toBlob((v)=>v?resolve(v):reject(new Error('单张PNG编码失败；未拆分或截断，请关闭其他大图页面或用系统浏览器重试。')),'image/png');}catch(e){reject(e);}});
    return new Uint8Array(await blob.arrayBuffer());
  }
  function pngDimensions(bytes){
    if(!(bytes instanceof Uint8Array) || bytes.length<24 || [137,80,78,71,13,10,26,10].some((v,i)=>bytes[i]!==v)) throw new Error('PNG编码没有返回有效图片。');
    const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);return {width:v.getUint32(16),height:v.getUint32(20)};
  }
  async function createPngFiles(data,indices,options) {
    const opts=options||{},factory=opts.canvasFactory||defaultCanvasFactory,encode=opts.encodePng||defaultEncodePng;
    const selected=indices || data.outlines.map((_,i)=>i);
    if(!selected.length || selected.some((i)=>!Number.isInteger(i)||i<0||i>=data.outlines.length)) throw new Error('请选择有效的大纲。');
    const files=[];const progress=opts.onProgress||function(){};const pause=opts.yieldStep || (()=>new Promise((r)=>setTimeout(r,0)));
    for(let n=0;n<selected.length;n++) {
      const i=selected[n];let height=opts.maxHeight||DEFAULT_MAX_HEIGHT;let done=false;
      while(!done) {
        const measure=factory(WIDTH,1),ctx=measure.getContext('2d');
        if(!ctx)throw new Error('无法创建Canvas文字测量上下文。');
        const plan=makePlan(data,i,ctx,{width:WIDTH,maxHeight:height});measure.width=1;measure.height=1;
        if(plan.pages.length>1 && !opts.allowSegments)throw new Error('这份资料超过单张长图的安全高度；没有拆分或截断。请用系统浏览器重试，或先整理资料中的极长来源记录。');
        const pending=[];
        try {
          for(let j=0;j<plan.pages.length;j++) {
            progress({model:plan.model,outline:n+1,totalOutlines:selected.length,part:j+1,totalParts:plan.pages.length,phase:'render'});await pause();
            const c=factory(WIDTH,plan.pages[j].height);
            try {
              drawPage(plan,j,c);const encoded=await encode(c);const bytes=encoded instanceof Uint8Array?encoded:new Uint8Array(encoded);const dim=pngDimensions(bytes);
              if(dim.width!==WIDTH||dim.height!==plan.pages[j].height)throw new Error('PNG尺寸校验失败，未提供下载。');
              const name=cleanName(data.title)+'-'+String(i+1).padStart(2,'0')+'-'+plan.model+(plan.pages.length>1?'-第'+(j+1)+'段':'')+'.png';
              pending.push({name,bytes,width:dim.width,height:dim.height,outlineIndex:i,part:j+1,totalParts:plan.pages.length});
            } finally {c.width=1;c.height=1;}
          }
          files.push(...pending);done=true;
        } catch(e) {
          if(opts.allowSegments && height>4000 && !opts.noRetry){height=Math.max(4000,Math.floor(height/2));progress({model:plan.model,phase:'retry',maxHeight:height});await pause();}
          else throw e;
        }
      }
    }
    return files;
  }
  let crcTable;
  function crc32(bytes){
    if(!crcTable){crcTable=new Uint32Array(256);for(let i=0;i<256;i++){let c=i;for(let j=0;j<8;j++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);crcTable[i]=c>>>0;}}
    let c=0xffffffff;for(const b of bytes)c=crcTable[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;
  }
  function createZip(files,options){
    if(!Array.isArray(files)||!files.length||files.length>65535)throw new Error('ZIP文件数量无效。');
    const encoder=new TextEncoder(),date=(options&&options.date)||new Date();const year=Math.max(1980,Math.min(2107,date.getFullYear()));
    const dosDate=((year-1980)<<9)|((date.getMonth()+1)<<5)|date.getDate(),dosTime=(date.getHours()<<11)|(date.getMinutes()<<5)|Math.floor(date.getSeconds()/2);
    const local=[],central=[];let offset=0,centralSize=0;const names=new Set();
    const header=(size)=>{const bytes=new Uint8Array(size);return {bytes,view:new DataView(bytes.buffer)};};
    files.forEach((f)=>{
      if(!(f.bytes instanceof Uint8Array)||!f.bytes.length)throw new Error('ZIP中存在空文件。');
      const safeName=S(f.name).replace(/[\\/:*?"<>|\u0000-\u001f]/g,'-').replace(/[. ]+$/g,'');if(!safeName)throw new Error('ZIP文件名为空。');const name=encoder.encode(safeName);if(name.length>65535)throw new Error('ZIP文件名过长。');if(names.has(safeName))throw new Error('ZIP文件名重复。');names.add(safeName);
      const size=f.bytes.length,crc=crc32(f.bytes);if(size>0xffffffff || offset+30+name.length+size>0xffffffff)throw new Error('文件过大，超出此离线ZIP格式的限制。');
      const l=header(30);l.view.setUint32(0,0x04034b50,true);l.view.setUint16(4,20,true);l.view.setUint16(6,0x0800,true);l.view.setUint16(8,0,true);l.view.setUint16(10,dosTime,true);l.view.setUint16(12,dosDate,true);l.view.setUint32(14,crc,true);l.view.setUint32(18,size,true);l.view.setUint32(22,size,true);l.view.setUint16(26,name.length,true);local.push(l.bytes,name,f.bytes);
      const c=header(46);c.view.setUint32(0,0x02014b50,true);c.view.setUint16(4,20,true);c.view.setUint16(6,20,true);c.view.setUint16(8,0x0800,true);c.view.setUint16(10,0,true);c.view.setUint16(12,dosTime,true);c.view.setUint16(14,dosDate,true);c.view.setUint32(16,crc,true);c.view.setUint32(20,size,true);c.view.setUint32(24,size,true);c.view.setUint16(28,name.length,true);c.view.setUint32(42,offset,true);central.push(c.bytes,name);centralSize+=46+name.length;offset+=30+name.length+size;
    });
    const end=header(22);end.view.setUint32(0,0x06054b50,true);end.view.setUint16(8,files.length,true);end.view.setUint16(10,files.length,true);end.view.setUint32(12,centralSize,true);end.view.setUint32(16,offset,true);
    const total=offset+centralSize+22;if(total>0xffffffff)throw new Error('ZIP过大，无法在当前浏览器内安全打包。');
    const result=new Uint8Array(total);let at=0;[...local,...central,end.bytes].forEach((b)=>{result.set(b,at);at+=b.length;});return result;
  }
  function mount(data,options){
    if(typeof document==='undefined')throw new Error('mount只能在浏览器中运行。');
    const opts=options||{},buttons=Array.from(document.querySelectorAll('[data-export-outline], [data-export-all]')),status=document.getElementById('export-status'),saveArea=document.getElementById('export-save');
    const urls=[];let busy=false;
    const say=(message,error)=>{const panel=document.getElementById('export-feedback');if(panel)panel.hidden=false;if(status){status.textContent=message;status.setAttribute('role',error?'alert':'status');status.dataset.error=error?'true':'false';}};
    const clear=()=>{while(urls.length)URL.revokeObjectURL(urls.pop());if(saveArea)saveArea.replaceChildren();};
    async function run(indices){
      if(busy)return;busy=true;buttons.forEach((b)=>{b.disabled=true;b.setAttribute('aria-busy','true');});clear();
      try {
        say('正在排版长图，请保持此页打开……');
        if(document.fonts && document.fonts.ready)await document.fonts.ready;
        const files=await createPngFiles(data,indices,Object.assign({},opts,{onProgress:(p)=>say(`正在生成 ${p.model}（${p.outline}/${p.totalOutlines} 份）……`)}));
        say('长图已生成，正在准备保存文件……');await new Promise((r)=>setTimeout(r,0));
        const zip=indices.length>1 || (opts.allowSegments && files.length>1),name=zip?cleanName(data.title)+(indices.length>1?'-六份长图':'-'+data.outlines[indices[0]].model+'-连续长图')+'.zip':files[0].name;
        const bytes=zip?createZip(files):files[0].bytes,blob=new Blob([bytes],{type:zip?'application/zip':'image/png'}),url=URL.createObjectURL(blob);urls.push(url);
        const a=document.createElement('a');a.href=url;a.download=name;a.textContent='保存文件：'+name;a.className='save-file';
        if(saveArea)saveArea.append(a);else document.body.append(a);
        a.click();
        say(`已生成 ${files.length} 张长图，请检查下载记录。若未保存，点击下方“保存文件”。`);
        if(!zip && saveArea){const hint=document.createElement('span');hint.className='export-hint';hint.textContent='也可先预览图片，再使用浏览器的保存图片功能。';const view=document.createElement('button');view.type='button';view.className='export-secondary';view.textContent='预览长图';view.addEventListener('click',()=>{let img=saveArea.querySelector('img');if(img){img.hidden=!img.hidden;return;}img=document.createElement('img');img.src=url;img.alt=data.outlines[indices[0]].model+'完整访谈长图';img.className='export-preview';saveArea.append(img);});saveArea.append(hint,view);}
      } catch(e){say('长图未能完整生成，请重试或用系统浏览器打开本页后下载。',true);if(typeof console!=='undefined')console.error('Interview export failed',e);}
      finally{busy=false;buttons.forEach((b)=>{b.disabled=false;b.removeAttribute('aria-busy');});}
    }
    buttons.forEach((b)=>b.addEventListener('click',()=>run(b.hasAttribute('data-export-all')?data.outlines.map((_,i)=>i):[Number(b.dataset.exportOutline)])));
    window.addEventListener('beforeunload',clear);
    const dismiss=document.getElementById('export-dismiss');if(dismiss)dismiss.addEventListener('click',()=>{if(!busy){const panel=document.getElementById('export-feedback');if(panel)panel.hidden=true;}});
    if(status)status.textContent='请选择要下载的访谈大纲。';
    return {run,destroy:clear};
  }
  return {version:VERSION,makeBlocks,wrapText,makePlan,drawPage,createPngFiles,createZip,crc32,pngDimensions,mount};
});
