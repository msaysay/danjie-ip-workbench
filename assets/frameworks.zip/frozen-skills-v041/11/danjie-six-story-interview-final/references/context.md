# interview-context.json 输入合同（0.1.4）

只写一个JSON对象，不带Markdown围栏。字段来自本次卡片或用户明确补充，未知不能填成成绩或故事。

- schema_version: "1.1"。旧1.0输入须重新核对，不能仅改版本号或猜测补字段。
- mode: real 或 fictional_demo；虚构测试保留后者。
- title: 业务名称＋六脉神剑访谈大纲。
- inputs: {persona:{id,version,file,status},audience:{id,version,file,status}}。未知ID/版本写“未提供”，status=read/missing；两卡不能都missing。
- input_summary: {business,owner_role,audience,payer,decision_maker,user,concerns:[{text,status,source_refs}],public_boundaries:[],conflicts:[]}。前六项为文字；concerns.status=reported/candidate/unknown，AI推测不可写成reported。
- 角色分列：audience是内容面向谁；payer是付款主体（例如企业，而非它的负责人）；decision_maker是决定购买的人；user是实际使用或受益者。忠实保留“家人可能付款/共同决策”等原卡限定，未知写“未提供”，不能在audience里只写付款或决策标签代替目标客群。
- sources: [{id,file,location,kind,summary}]。kind=persona/audience/user_statement；ID唯一。summary忠实保留卡内原句及其上下文限定，不把转述升级为外部核实。付款、决策、使用角色分别引用对应原句，不合并成“付款与决策为负责人”。供无事件判断使用的完整原句须逐字保留于summary，不能为了通过校验编写新原句。
- recommended_first: {model,reason}。从六脉中选择较适合先聊的一份；不能预测流量。脚本会用中性理由替代自由理由。
- outlines: 按缘起、悟道、求索、取舍、破局、见证顺序六项。每项写 {model,event_scope,status,event_anchor:{text,status,source_refs}}；只有not_applicable额外写absence_reason。

六个event_scope依次为owner_origin、owner_belief_change、owner_exploration、owner_tradeoff、owner_business、customer_case。

## 状态必须配对

| outline.status | event_anchor.status | 用于什么情况 |
|---|---|---|
| ready | reported | 卡中有具体、可追问的真实事件；仍须本人核对公开意愿，不代表成功 |
| responding | reported | 自身经营困难仍在应对；只问已发生动作与当前进展，不写已解决 |
| discovery | pending | 事件尚待确定，卡未提供/未记录细节；不等于不存在 |
| not_applicable | none | 卡明确当前没有此类事件；见证明确没有已完成案例，并提供下述否定依据 |

reported与none必须有可解析source_refs。pending可以引用“不确定/待补”的卡片来源，但不能改成已有剧情。破局可发生在筹备期，未开业不等于从未遇过创业困境。

## 明确无事件的结构化依据

not_applicable/none必须提供：

```json
{
  "absence_reason": {
    "kind": "explicit_no_completed_case",
    "source_ref": "p01",
    "quote": "目前尚无已完成的客户案例。"
  }
}
```

- 见证kind只用explicit_no_completed_case；其余五份只用explicit_no_event。
- source_ref指向sources.id，同时列入event_anchor.source_refs。
- quote是源卡中明确否定的完整连续原句，逐字保留在该sources.summary内。保留“不是…而是…”等否定范围，不截取“没有”等几个字，不把卡片留空写成明确否定。
- 卡内仅写“未提供”“未记录”“暂未收集”“未知”时，用discovery/pending，不写absence_reason。
- 本人拒答、不愿公开或未获授权，只记public_boundaries并保留已知事实状态，不把有事件改成没有，也不对拒绝内容继续追问。没有具体事件信息则仍为discovery/pending；已有具体事件仍为reported。
- 其他状态不填absence_reason。脚本不会从行业、业务阶段或自然语言关键词自动猜出否定依据。

脚本只检查状态标签、来源编号及引文是否对应summary。它不能确认summary来自原卡，不能可靠理解任意原句的否定范围，也不能证明卡中自述属实。AI整理后仍逐项对照源卡，不能把结构通过称作事实核验。

## 固定题库与旧版兼容

不要添加questions、audience_reason、goal等自由问句字段；build.py会从已审中性题库生成，即使输入附带旧版问句也丢弃。个性化保留在业务、客群、事件、来源、状态和公开边界，不能私改固定问题来猜老板动机或成功结局。

0.1.3的schema_version 1.0不会自动迁移。应重新看源卡：保留已有身份/版本；未知改为discovery/pending；明确无事件时补完整原句及absence_reason；拒答只记边界，再写1.1。不要为通过脚本而自行补故事或否定引文。

角色与流程中的未知限定必须同时保留在decision_maker和sources：例如“公司负责人或业务/IT共同评估，具体组织流程尚待确认”，不能为缩短摘要删成“负责人决定”。来源原文中的“可能、共同、以…为准、尚待确认”等条件也照录，不把来源摘要改成比源卡更确定的结论。

“新业务”“没有完成案例”不能推断尚未开业、仍在筹备或从未经营。没有原卡明确说明时，经营阶段留未知；pending事件摘要只说该方向尚未提供具体经历，不添加阶段或剧情。
