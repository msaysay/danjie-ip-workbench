# 两卡承接

## 人设卡

支持 owner-ip-persona-card 的结构化字段，也支持学员普通文档：persona_id、persona_version、mode、priority_business、business_frame、owner_identity、owner_expertise、owner_judgments、speaking_style、trust_evidence、customer_events、ability_records、public_boundaries、accepted_speech_samples、source_index。

只取有来源的业务事实。行业名称不证明老板具体资历、故事、成绩和角色。称呼、语气可参考语言样本，不能模仿外部名人代替本人。

## 目标客群卡

支持 danjie-customer-profile-hy3 的 profile_id、profile_version、mode、customer_type、business、group_name、summary、dimensions、pairs、sources、unknowns，也支持同义文字。pairs里reported、candidate、unknown不能混用：candidate是尚待确认的内容关注方向，不能写“客户都怕……”。角色分清付款主体/决策者/使用者/受益者；例如阅读加盟的客户可能是校长而非家长，不能因项目叫阅读就改成向家长讲。

## 标准化输出输入摘要

inputs.persona 与 inputs.audience 各含 id、version、file、status。status为read或missing；id/version未知填“未提供”。input_summary含business、owner_role、audience、payer、decision_maker、user、concerns（每项text/status/source_refs）、public_boundaries、conflicts。sources每项id、file、location、kind、summary；kind=persona/audience/user_statement。

所有source_refs指向sources.id。输入卡内编号可通过location保留，如persona_2026 source_index E03、profile NC04 candidate；渲染后仍可追到原卡，不只留“根据资料”。涉及多个老板或不同业务，先确认本次组合。

模拟输入全部保留mode=fictional_demo；不能在演示中称“本人已确认”“真实学员跑通”。六份采访大纲中的发掘问题可以没有事件来源，明确question_basis=exploration，不因此为问题设定答案。

0.1.4中payer、decision_maker、user分列呈现。公司付款、负责人决策不能写成负责人个人付款；车主为主要决策者时也要保留原卡的家人付款或共同决定限定。audience仍写内容面向的完整客群，不能压缩为“付款与决策为某某”。sources按付款主体、决策者、使用者分别摘录原句并保留限定，不拼接成原卡没有的角色断言。

角色与流程中的未知限定必须同时保留在decision_maker和sources：例如“公司负责人或业务/IT共同评估，具体组织流程尚待确认”，不能为缩短摘要删成“负责人决定”。来源原文中的“可能、共同、以…为准、尚待确认”等条件也照录，不把来源摘要改成比源卡更确定的结论。

audience只写原卡明确的本次内容/获客对象。使用者、流程参与者或下游受益人不自动成为另一个内容目标；例如企业付费招聘时，候选人保留在user及决策自主权说明中，不能仅因参与流程就并列为企业获客内容的目标观众。

整理后逐项回到原卡检查payer、decision_maker、user是否各有来源原句（可合在一条来源中，须分别标明），缺一项就补来源再交付。location写原卡实际字段或段落标题，原卡没有ID时不生成类似卡片ID的定位前缀。无事件quote保留完整连续原句，包括同一句里的限制与后续分句。
