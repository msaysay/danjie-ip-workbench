# 当前版本输出与交付

事实输入合同见 context.md。AI只整理两卡为schema 1.1的 interview-context.json；questions由build.py生成，不由AI编写。SKILL.md是当前入口，不需要fork、args或子代理。用户发来两卡即可运行。

## 三步生成

1. build.py 输入context，输出同源 interview.json、context.json、HTML、六份Markdown和validation.json。
2. export_png.py 输入实际interview.json，输出六张独立完整PNG、六图ZIP及png-export-receipt.json。
3. prepare_delivery.py 输入真实PNG回执与同目录HTML，输出student-files.json、student_reply.md、download-source-map.json及兼容文件名下载副本。

实际参数格式以SKILL.md的三条命令为准。不要编辑interview.json或前台文件绕过校验。生成失败先对原卡修正context，不改固定题库。

## 可见内容

HTML、六份Markdown、Canvas和Pillow只消费render.py的student_document学员投影。内容包括业务标题、方向、虚构标识、开场、主问、条件追问、提醒和结束语。主问大号白色粗体，追问次一级白字；“如果聊偏了”“如果没讲具体”“如果还想多问一句”等条件和提示用小号灰字，提示不念。背景、金色栏目、字体与布局由包内模板固定。

后台固定题库的题数不等于学员实际看到的题数。一般事件主线可显示七个主问；卡片明确没有该类事件时，学员版只显示一条取材问题，随后换其他话题。不把“未提供经历”改为“没有经历”，不结束整场访谈。缺少完成案例时，见证也只是一条取材问题，不伪造案例。前台问题数以student_document和PNG回执的question_count为准，不从后台question数组推断。

学员页不展示输入文件名、ID、版本、状态、溯源、录制设计或校验信息。这些保留在后台JSON。虚构演示标识始终可见。没有独立事实证据就保留自述、未知、待确认及实际隐私边界。

## 长图与兼容下载

每个方向一张1080像素宽完整PNG，最多30000像素高。不得裁断、静默拆段、漏题或用截图拼贴代替。使用已有Pillow和本机中文字体，不自动安装依赖或下载字体。缺少依赖、字体或超限就如实说明，不能假称图片完成。

导图回执记录字体、尺寸、原行数与绘制行数、实际可见题数、SHA256和ZIP校验。回执验证的是生成文件，不证明客户端点击或保存成功。HTML按钮的blob下载可能受内置预览限制，因此六张原生PNG附件是必要交付。

组装器逐项核实六模型齐全、实际PNG和ZIP完整性、源JSON哈希、HTML正文及代码同源一致性。任何不一致都失败，不生成成功回复。download-source-map.json把原件与兼容文件名副本对应；副本必须逐字节等于原件。HTML副本与style.css、texture.png、export.js同目录保存。不要自行把清单里的下载路径改回旧中文文件名。

## 给学员交付什么

实际读取student-files.json，使用present_files或等价工具呈现六张PNG、六图ZIP和HTML。普通学员只要这些成果入口；后台JSON、输入卡与校验报告不作附件。工具不可用时提供真实文件链接。

最后读取student_reply.md作为回复，不另写“全部七题”、技术总结、过程回放或额外下一步建议。需要报告数量时读取实际question_count；不写未经检查的概括。没有实际保存证据，不说“已下载”。用户明确要求审计时，另给如实的核验记录，和学员交付分开。
