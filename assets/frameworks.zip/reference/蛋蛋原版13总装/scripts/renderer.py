# -*- coding: utf-8 -*-
from pathlib import Path
import base64,json,re,html,mimetypes
from urllib.parse import unquote

def data_url(p):return 'data:'+(mimetypes.guess_type(str(p))[0]or'application/octet-stream')+';base64,'+base64.b64encode(Path(p).read_bytes()).decode('ascii')
def inline_document(p,fallbacks=None):
 p=Path(p).resolve();base=p.parent;doc=p.read_text(encoding='utf-8-sig');fallbacks=fallbacks or {}
 def local(ref,at):
  if ref.startswith('data:')or ref.startswith('#'):return None
  if re.match(r'^[A-Za-z]+:',ref)or ref.startswith('//'):raise ValueError('页面含外部资源，需先由原模块生成离线结果')
  q=(at/unquote(ref.split('?')[0].split('#')[0])).resolve()
  if not q.is_relative_to(base):raise ValueError('页面资源越界：'+Path(ref).name)
  if not q.is_file():
   if q.name in fallbacks:return fallbacks[q.name]
   raise ValueError('页面资源缺失：'+Path(ref).name)
  return q
 def css(text,at):
  if '@import' in text:raise ValueError('页面CSS含外部导入，需先离线打包')
  def replace(m):
   ref=m[1].strip(' \"\'');q=local(ref,at)
   return 'url("'+(data_url(q)if q else ref)+'")'
  return re.sub(r'url\(([^)]+)\)',replace,text)
 def script(m):
  q=local(m[2],base)
  if q is None:raise ValueError('不支持数据URL脚本')
  raw=q.read_text(encoding='utf-8-sig').replace('</script','<\\/script')
  return '<script>'+raw+'</script>'
 doc=re.sub(r'<script\b([^>]*?)src=[\"\']([^\"\']+)[\"\'][^>]*>\s*</script>',script,doc,flags=re.I)
 def link(m):
  tag=m[0]
  if not re.search(r'rel=[\"\']stylesheet[\"\']',tag,re.I):return tag
  ref=re.search(r'href=[\"\']([^\"\']+)[\"\']',tag,re.I)
  if not ref:return tag
  q=local(ref[1],base)
  return '<style>'+css(q.read_text(encoding='utf-8-sig'),q.parent)+'</style>'
 doc=re.sub(r'<link\b[^>]*>',link,doc,flags=re.I)
 doc=re.sub(r'(<style[^>]*>)(.*?)(</style>)',lambda m:m[1]+css(m[2],base)+m[3],doc,flags=re.S|re.I)
 def image(m):
  q=local(m[2],base)
  return m[1]+(data_url(q)if q else m[2])+m[3]
 doc=re.sub(r'(<(?:img|source|video|audio)\b[^>]*?src=[\"\'])([^\"\']+)([\"\'])',image,doc,flags=re.I)
 doc=re.sub(r'<meta[^>]+http-equiv=[\"\']refresh[\"\'][^>]*>','',doc,flags=re.I)
 csp='<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; script-src \'unsafe-inline\'; img-src data:; font-src data:; media-src data:; connect-src \'none\'; frame-src \'none\'; form-action \'none\'; base-uri \'none\'">'
 # A document may omit head/body. Insert immediately after its opening html tag.
 if re.search(r'<head\b',doc,re.I):doc=re.sub(r'(<head[^>]*>)',lambda m:m[1]+csp,doc,count=1,flags=re.I)
 else:doc=re.sub(r'(<html[^>]*>)',lambda m:m[1]+csp,doc,count=1,flags=re.I)if '<html'in doc else csp+doc
 # srcdoc inherits the host base URL. Handle local fragment links inside the
 # embedded document rather than navigating to the WorkBuddy parent URL.
 bridge="""<script data-danjie-fragment-bridge>document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href^="#"]');if(!a)return;var id;try{id=decodeURIComponent(a.getAttribute('href').slice(1))}catch(_){return}var target=document.getElementById(id);if(target){e.preventDefault();target.scrollIntoView({block:'start',behavior:'smooth'})}},true);</script>"""
 doc=doc.replace('</body>',bridge+'</body>')if '</body>'in doc else doc+bridge
 return doc

def render_dashboard(skill,root,s,modules,state):
 root=Path(root);skill=Path(skill);items={};warnings=[]
 for tid in s['topics']:
  bystep={}
  for m in modules:
   key=str(m['id'])+':'+('shared'if m['id']in [1,8,9]else tid);r=s['artifacts'].get(key);status=state(root,s,m['id'],tid);document=None;render_error=''
   if r:
    page=r['files'].get('html')
    if page and (root/page['snapshot']).is_file():
     try:
      fallback={}
      if m['id']==11:
       original=skill/'assets/module11/style.css';present=(root/page['snapshot']).parent/'style.css'
       if not present.exists()or present.read_bytes()==original.read_bytes():fallback={n:skill/'assets/module11'/n for n in ['style.css','texture.png']}
      document=inline_document(root/page['snapshot'],fallback)
     except (ValueError,OSError)as e:
      render_error=str(e);warnings.append({'topic_id':tid,'step':m['id'],'error':render_error})
    elif r['files'].get('png'):
     img=root/r['files']['png']['snapshot'];document='<html lang="zh-CN"><meta name="viewport" content="width=device-width"><body style="margin:0;background:#090b0a"><img alt="本人的成果长图" style="width:100%;height:auto" src="'+data_url(img)+'"></body></html>'
   bystep[str(m['id'])]={'id':m['id'],'title':m['title'],'status':status,'document':document,'note':r.get('note','')if r else '', 'revision':r['revision']if r else 0,'render_error':render_error,'pending':s['pending'].get(key,{}).get('question','')}
  items[tid]=bystep
 from workbench import completion
 ready=completion(root,s)
 next_step=next((i for i in [1,8,2,3,4,5,6,7,9,10,11,12] if i in ready['missing_steps']),None)
 payload={'purpose':s.get('purpose','student_workflow'),'schema':'danjie-dashboard/0.4.1','project_id':s['project_id'],'name':s['name'],'business':s['business'],'student_ref':s['student_ref'],'mode':s['mode'],'topics':s['topics'],'active_topic':s['active_topic'],'items':items,'completion':ready,'next_task':{'step':next_step,'topic_id':s['active_topic']},'request_context':str(root/'project.json'),'updated_at':s['updated_at']}
 raw=json.dumps(payload,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
 if len(raw.encode())>90*1024*1024:raise ValueError('工作台超过90MB，请按选题拆成独立项目包，不静默丢弃成果')
 template=(skill/'assets/dashboard.html').read_text(encoding='utf-8');css=(skill/'assets/brand.css').read_text(encoding='utf-8');js=(skill/'assets/dashboard-v041.js').read_text(encoding='utf-8');tools=(skill/'assets/direct-tools.js').read_text(encoding='utf-8');toolcss=(skill/'assets/direct-tools.css').read_text(encoding='utf-8')
 values={'__BRAND_CSS__':css,'__TOOL_CSS__':toolcss,'__LOGO__':data_url(skill/'assets/logo.jpeg'),'__DATA__':raw,'__DASHBOARD_JS__':js,'__DIRECT_JS__':tools}
 out=re.sub(r'__(?:BRAND_CSS|TOOL_CSS|LOGO|DATA|DASHBOARD_JS|DIRECT_JS)__',lambda m:values[m[0]],template)
 (root/'工作台.html').write_text(out,encoding='utf-8');(root/'index.html').write_text(out,encoding='utf-8')
 report={'schema':'render-receipt/0.4.1','project_id':s['project_id'],'embedded_documents_current_topic':sum(bool(x['document'])for x in items[s['active_topic']].values()),'embedded_document_classes_project':sum(any(topic[str(m['id'])]['document']for topic in items.values())for m in modules),'warnings':warnings,'html_bytes':len(out.encode()),'native_client_verified':False,'rendered_from':'actual_registered_html_not_demo_answers'}
 (root/'render-receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');return report
