#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Portable per-learner artifact coordination. No model/API calls or global scans."""
from pathlib import Path,PurePosixPath
import argparse,base64,datetime,hashlib,html,json,os,re,shutil,uuid,zipfile
SKILL=Path(__file__).resolve().parent.parent
MODULES=json.loads((SKILL/'modules.json').read_text(encoding='utf-8'))
SHARED={1,8,9};SCHEMA='danjie-workbench/0.2.1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read_json(p):
 def unique(pairs):
  d={}
  for k,v in pairs:
   if k in d:raise ValueError('JSON存在重复字段：'+k)
   d[k]=v
  return d
 return json.loads(Path(p).read_text(encoding='utf-8-sig'),object_pairs_hook=unique)
def write_json(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(p)
def project_root(root):
 root=Path(root).expanduser()
 if not root.is_absolute():raise ValueError('请使用明确的项目绝对路径')
 return root.resolve()
def load(root):
 root=project_root(root);s=read_json(root/'project.json')
 if s.get('schema')!=SCHEMA:raise ValueError('项目格式不兼容，请保留原项目并按迁移流程处理')
 return root,s
def save(root,s):s['updated_at']=now();write_json(root/'project.json',s)
def key(step,topic):return str(step)+':'+('shared' if step in SHARED else topic)
def require_topic(topic):
 if not isinstance(topic,str)or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',topic):raise ValueError('选题ID只能用字母、数字、下划线或短横线')
def slot(s,step,topic='main'):return s['artifacts'].get(key(step,topic))
def dep_records(s,step,topic):return {str(d):slot(s,d,topic) for d in MODULES[step-1]['requires']}
def file_state(root,r):
 if not r:return 'missing'
 for f in r['files'].values():
  p=root/f['snapshot']
  if not p.is_file()or sha(p)!=f['sha256']:return 'changed'
  origin=Path(f['source'])
  # External originals may be absent on another computer; snapshots remain portable.
  if origin.is_file()and sha(origin)!=f['sha256']:return 'source_changed'
 if r.get('identity_conflicts'):return 'identity_conflict'
 if not handoff_ready(r['step'],r['files']):return 'view_only'
 if r['step']==3 and not selected_hook_ready(root,r):return 'awaiting_selection'
 if r['step']==10:
  if r.get('module_version')!='0.7.0' or not r.get('qiankun_validated'):return 'module_outdated'
  if r.get('qiankun_stage')=='awaiting_topic':return 'awaiting_topic'
 return 'imported' if r['origin']=='import' else 'generated'
def handoff_ready(step,files):
 if step==3:return 'counter_candidates' in files or 'selected_hook' in files
 return all(role in files for role in MODULES[step-1]['roles'])

def selected_hook_ready(root,r):
 f=r.get('files',{}).get('selected_hook')
 if not f:return False
 try:
  d=read_json(Path(root)/f['snapshot'])
  return d.get('card_type')=='danjie-opening-selection' and d.get('owner_confirmed') is True and bool(d.get('selected',{}).get('viewpoint'))
 except (ValueError,OSError):return False

def state(root,s,step,topic='main',seen=None):
 r=slot(s,step,topic)
 if not r:return 'waiting_answer' if key(step,topic) in s['pending'] else 'missing'
 f=file_state(root,r)
 if f not in ['imported','generated']:return f
 seen=set()if seen is None else set(seen)
 if step in seen:raise ValueError('依赖循环')
 seen.add(step)
 for d in MODULES[step-1]['requires']:
  parent=slot(s,d,topic)
  if not parent or state(root,s,d,topic,seen)not in ['imported','generated']:return 'dependency_missing'
  expected=r.get('parents',{}).get(str(d))
  if expected!=parent['revision']:return 'stale'
 for opt,ref in r.get('optional_parents',{}).items():
  parent=slot(s,int(opt),ref['topic_id'])
  if not parent or state(root,s,int(opt),ref['topic_id'],seen) not in ['imported','generated'] or parent['revision']!=ref['revision']:return 'stale'
 return f

def init(root,name,business,student,mode,purpose="student_workflow"):
 root=project_root(root)
 if mode not in ['real','fictional_demo']or not all(isinstance(x,str)and x.strip()for x in [name,business,student]):raise ValueError('需要明确项目名、业务、学员归属及真实/虚构模式')
 if root.exists()and any(root.iterdir()):raise ValueError('新项目目录须为空，已有项目请继续，不覆盖')
 if purpose not in ['student_workflow','teaching_demo'] or (purpose=='teaching_demo' and mode!='fictional_demo'):raise ValueError('课堂展示只允许虚构模式')
 root.mkdir(parents=True,exist_ok=True)
 s={'purpose':purpose,'schema':SCHEMA,'project_id':uuid.uuid4().hex,'name':name,'business':business,'student_ref':student,'mode':mode,'created_at':now(),'topics':{'main':{'title':'本次内容','created_at':now()}},'active_topic':'main','artifacts':{},'history':{},'pending':{},'feedback':[],'identity':{}}
 save(root,s);render(root,s);return {'project':str(root/'project.json'),'dashboard':str(root/'工作台.html')}

def topic(root,tid,title):
 require_topic(tid);root,s=load(root)
 if not title.strip():raise ValueError('选题标题不能为空')
 if tid in s['topics']and s['topics'][tid]['title']!=title:raise ValueError('已有选题题意不能静默改写；请使用新ID建立分支')
 s['topics'][tid]={'title':title,'created_at':now()};s['active_topic']=tid;save(root,s);render(root,s);return {'topic':tid}

def identity_info(d):
 if not isinstance(d,dict):return {}
 result={}
 for k in ['student_ref','student_id','learner_id','mode','profile_id','persona_id']:
  if isinstance(d.get(k),str):result[k]=d[k]
 for container in ['profile','profile_ref','persona','project','context']:
  x=d.get(container)
  if not isinstance(x,dict):continue
  for k in ['student_ref','student_id','learner_id','mode','profile_id','persona_id']:
   if isinstance(x.get(k),str):result.setdefault(k,x[k])
  if container=='profile'and isinstance(x.get('id'),str):result.setdefault('profile_id',x['id'])
  if container=='persona'and isinstance(x.get('id'),str):result.setdefault('persona_id',x['id'])
 return result

def register(root,s,step,topic,files,binding,review,origin='import',note=''):
 if not 1<=step<=12:raise ValueError('模块编号必须在1至12')
 require_topic(topic)
 if topic not in s['topics']:raise ValueError('先登记本条选题，再接成果')
 if not isinstance(binding,dict)or any(binding.get(k)!=s[k]for k in ['student_ref','business','mode']):raise ValueError('学员、业务或真实/虚构模式不匹配，拒绝串入')
 if not isinstance(review,dict)or review.get('same_business')is not True or not review.get('basis'):raise ValueError('需要宿主实际读资料后的业务归属依据，不凭文件名认领')
 if not isinstance(files,dict)or not files:raise ValueError('没有实际成果文件')
 # Adopting a candidate must not drop the existing reading page or its thirty candidates.
 if step==3 and 'selected_hook' in files and slot(s,step,topic):
  files=dict(files)
  for role,old in slot(s,step,topic)['files'].items():
   if role not in files:files[role]=str(root/old['snapshot'])
 if origin=='generation'and not handoff_ready(step,files):raise ValueError('生成登记缺少必要交接角色')
 if step==3 and origin=='generation' and 'counter_candidates' in files:
  d=read_json(files['counter_candidates'])
  if d.get('schema_version')!='danjie-opening-candidates-v080' or len(d.get('topics',[]))!=10:raise ValueError('当头一棒需本版十题三法模型')
  for row in d['topics']:
   approaches=row.get('approaches',{})
   if set(approaches)!={'necessary_condition','selection_standard','result_direction'} or any(not a.get('old_cognition') or not a.get('opening') for a in approaches.values()):raise ValueError('当头一棒候选缺题或缺方法')
  for dep,role,hashkey in [(1,'audience','customer_sha256'),(2,'topic_handoff','three_circle_sha256')]:
   parent=slot(s,dep,topic)
   if not parent or not parent['files'].get(role) or d.get('input_hashes',{}).get(hashkey)!=parent['files'][role]['sha256']:raise ValueError('当头一棒模型与本项目客群/三圈来源不一致')
 conflicts=[];raw=[];infos=[]
 for role,v in files.items():
  if not re.fullmatch('[a-z][a-z0-9_]{0,40}',role):raise ValueError('不支持的文件角色')
  p=Path(v).expanduser()
  if not p.is_absolute()or not p.is_file()or p.stat().st_size==0:raise ValueError('成果不存在、为空或不是明确的绝对路径：'+role)
  p=p.resolve()
  if p.stat().st_size>40*1024*1024:raise ValueError('单文件超过40MB，请单独处理并保留原件')
  if role=='html'and p.suffix.lower()not in ['.html','.htm']:raise ValueError('阅读页须为HTML')
  if p.suffix.lower()=='.json':
   info=identity_info(read_json(p));infos.append(info)
   if info.get('student_ref')and info['student_ref']!=s['student_ref']:conflicts.append('原件student_ref与当前学员归属不一致')
   for k in ['student_id','learner_id']:
    value=info.get(k);expected=s['identity'].get(k)
    known={s['student_ref'],*s['identity'].values(),info.get('profile_id'),info.get('persona_id')}
    if value and expected and value!=expected:conflicts.append('原件'+k+'与已登记来源身份不一致')
    elif value and not expected and step not in [1,8]and value not in known:conflicts.append('原件'+k+'尚无法与本项目来源对应，需先核对，不按称呼硬匹配')
   if s['mode']=='real'and info.get('mode')in ['fictional_demo','demo','simulated']:conflicts.append('虚构原件不能升为真实学员')
   for k in ['profile_id','persona_id']:
    expected=s['identity'].get(k)
    if expected and info.get(k)and expected!=info[k]:conflicts.append(k+'来源编号不一致，需要核对原卡，不能强行传给后续')
  raw.append((role,p))
 if conflicts:raise ValueError('；'.join(sorted(set(conflicts))))
 # Never register self-generated statuses as someone else's original content.
 for role,p in raw:
  if p.resolve()==(root/'project.json').resolve()or (p.suffix.lower()=='.json'and read_json(p).get('schema')in [SCHEMA,'danjie-ip-workbench/0.1.0']):raise ValueError('工作台状态不是原卡，不能登记为业务成果')
 qiankun_stage=None
 if step==10 and 'expansion' in files:
  model=read_json(files['expansion'])
  if model.get('schema')=='qiankun-dual-card-1' and model.get('industry_terms'):
   from qiankun_contract import validate_bound
   qiankun_stage=validate_bound(SKILL,root,s,model)
  elif origin=='generation':raise ValueError('第10项需新版0.7.0双卡模型，不能把旧版或占位JSON登记为已生成')
 previous=slot(s,step,topic);rev=(previous['revision']+1)if previous else 1
 target=root/'artifacts'/key(step,topic).replace(':','-')/('v'+str(rev))
 if target.exists():raise ValueError('版本目录已存在，保留现场并核对，不覆盖')
 record={'module_version':MODULES[step-1]['version'],'qiankun_validated':bool(qiankun_stage),'qiankun_stage':qiankun_stage,'step':step,'topic_id':'shared'if step in SHARED else topic,'revision':rev,'origin':origin,'review':review,'binding':binding,'note':note,'registered_at':now(),'files':{},'parents':{k:v['revision']for k,v in dep_records(s,step,topic).items()if v},'identity_conflicts':[]}
 record['optional_parents']={}
 for opt in review.get('used_optional_steps',[]):
  if opt not in MODULES[step-1].get('optional_requires',[]):raise ValueError('不是本模块可用的可选前置')
  parent=slot(s,opt,topic)
  if not parent or state(root,s,opt,topic) not in ['imported','generated']:raise ValueError('实际采用的可选前置未就绪')
  record['optional_parents'][str(opt)]={'topic_id':topic,'revision':parent['revision']}
 for role,p in raw:
  dst=target/role/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
  record['files'][role]={'source':str(p),'snapshot':str(dst.relative_to(root)),'sha256':sha(dst)}
  if role=='html':copy_local_assets(p,dst)
 if previous:s['history'].setdefault(key(step,topic),[]).append(previous)
 s['artifacts'][key(step,topic)]=record;s['pending'].pop(key(step,topic),None)
 if step in [1,8]:
  for info in infos:
   for k in ['profile_id','persona_id','student_id','learner_id']:
    if info.get(k):s['identity'].setdefault(k,info[k])
 return record

def copy_local_assets(source,dest):
 """Only traverse actual relative HTML resources inside its declared directory."""
 base=source.parent.resolve();queue=[(source,dest)];seen=set();total=0
 while queue:
  src,dst=queue.pop()
  if src in seen:continue
  seen.add(src)
  if len(seen)>200:raise ValueError('页面资源超过200项，先使用模块的独立结果包')
  text=src.read_text(encoding='utf-8-sig')if src.suffix.lower()in ['.html','.htm','.css']else ''
  refs=re.findall(r'(?:src|href)=[\"\']([^\"\']+)[\"\']',text)if src.suffix.lower()in ['.html','.htm']else re.findall(r'url\([\"\']?([^\)\"\']+)',text)
  for ref in refs:
   if ref.startswith(('http:','https:','data:','#','mailto:','javascript:'))or ref.startswith('/')or re.match(r'^[a-zA-Z]+:',ref):continue
   plain=ref.split('?')[0].split('#')[0]
   if not plain:continue
   from urllib.parse import unquote
   r=(src.parent/unquote(plain)).resolve()
   if not r.is_relative_to(base):raise ValueError('页面资源越过原成果目录，请先按原模块打包结果')
   # Links to other documents are not fetched as assets; only renderer resources.
   if not r.is_file():continue
   if r.suffix.lower()not in ['.js','.css','.png','.jpg','.jpeg','.webp','.gif','.svg','.woff','.woff2','.ttf']:continue
   out=dest.parent/r.relative_to(base);out.parent.mkdir(parents=True,exist_ok=True)
   total+=r.stat().st_size
   if total>50*1024*1024:raise ValueError('页面资源超过50MB，请单独保存')
   if not out.exists():shutil.copy2(r,out)
   if r.suffix.lower()=='.css':queue.append((r,out))

def import_manifest(root,manifest):
 root,s=load(root);m=read_json(manifest)
 if m.get('project')!={k:s[k]for k in ['student_ref','business','mode']}:raise ValueError('清单与当前项目归属不一致')
 items=m.get('artifacts')
 if not isinstance(items,list)or not items:raise ValueError('清单没有实际成果')
 # Preflight all declared paths before any copying; do not infer from filenames.
 for a in items:
  for v in a.get('files',{}).values():
   if not Path(v).is_absolute()or not Path(v).is_file():raise ValueError('清单文件缺失，尚未导入')
 results=[]
 for a in sorted(items,key=lambda x:x['step']):
  tid=a.get('topic_id','main')
  if tid not in s['topics']:
   require_topic(tid)
   if not a.get('topic_title'):raise ValueError('新选题缺标题')
   s['topics'][tid]={'title':a['topic_title'],'created_at':now()}
  r=register(root,s,a['step'],tid,a['files'],a.get('binding',m['project']),a.get('review',{}),'import',a.get('note','导入已有成果；不代表重新生成或本人重新确认'))
  save(root,s);results.append({'step':a['step'],'topic_id':tid,'status':state(root,s,a['step'],tid)})
 render(root,s);return {'imported':results,'dashboard':str(root/'工作台.html')}

def prepare(root,step,topic='main'):
 root,s=load(root);require_topic(topic)
 if s.get('purpose')=='teaching_demo':raise ValueError('课堂样例只供展示，不作为本人制作输入；请建立本人业务项目')
 if topic not in s['topics']:raise ValueError('选题未登记')
 deps=dep_records(s,step,topic)
 for d in MODULES[step-1]['requires']:
  if state(root,s,d,topic)not in ['imported','generated']:raise ValueError('前置缺失、变化或只有阅读页：'+MODULES[d-1]['title'])
 m=MODULES[step-1];archive=SKILL/m['archive']
 if sha(archive)!=m['sha256']:raise ValueError('内置模块与冻结清单不一致')
 dest=root/'runtime'/f'{step:02d}-{m["version"]}'
 with zipfile.ZipFile(archive)as z:
  entries=[]
  for info in z.infolist():
   rel=PurePosixPath(info.filename)
   if rel.is_absolute()or '..'in rel.parts or ((info.external_attr>>16)&0o170000)==0o120000:raise ValueError('不安全的压缩包路径')
   if info.is_dir():continue
   out=dest/Path(*rel.parts);raw=z.read(info)
   if out.exists()and out.read_bytes()!=raw:raise ValueError('运行模块已变化，不覆盖')
   entries.append((out,raw))
  for out,raw in entries:
   out.parent.mkdir(parents=True,exist_ok=True)
   if not out.exists():out.write_bytes(raw)
 inputs={d:{role:str(root/f['snapshot'])for role,f in r['files'].items()}for d,r in deps.items()}
 optional_inputs={d:{role:str(root/f['snapshot']) for role,f in slot(s,d,topic)['files'].items()} for d in m.get('optional_requires',[]) if slot(s,d,topic) and state(root,s,d,topic) in ['imported','generated']}
 return {'optional_inputs':optional_inputs,'module_root':str(dest/m['root']),'module_guide':str(dest/m['root']/'SKILL.md'),'inputs':inputs,'topic':s['topics'][topic],'workflow':('先A/B/C与全部B嘴替；未选C等待选择，选C后同题七式，不按B过滤C' if step==10 else '按原模块流程'),'warning':'读取实际原卡；保留本人确认，不由工作台补写事实；按原模块生成后再登记。'}

def pending(root,step,topic,question,source_state=None):
 root,s=load(root);require_topic(topic)
 if source_state and not Path(source_state).is_file():raise ValueError('原采访状态不存在')
 s['pending'][key(step,topic)]={'question':question,'module_state':source_state,'created_at':now()};save(root,s);render(root,s);return {'waiting_for_answer':True,'question':question}

def feedback(root,step,topic,message):
 root,s=load(root)
 if not message.strip():raise ValueError('修改需求不能为空')
 require_topic(topic);r=slot(s,step,topic)
 f={'id':uuid.uuid4().hex,'step':step,'topic_id':topic,'message':message,'based_on_revision':r['revision']if r else None,'status':'pending_review','created_at':now()};s['feedback'].append(f);save(root,s);render(root,s);return {'saved_feedback':f['id'],'meaning':'保存了修改需求，尚未重写内容'}

def complete(root,step,topic,request):
 root,s=load(root);d=read_json(request)
 for dep in MODULES[step-1]['requires']:
  if state(root,s,dep,topic)not in ['imported','generated']:raise ValueError('前置未就绪')
 r=register(root,s,step,topic,d['files'],d['binding'],d['review'],'generation',d.get('note',''))
 if not handoff_ready(step,r['files']):raise ValueError('生成登记缺少下游交接文件，请保留现场核对')
 save(root,s);render(root,s);return {'registered':key(step,topic),'status':state(root,s,step,topic),'dashboard':str(root/'工作台.html')}

def audit(root):
 root,s=load(root);rows=[]
 for tid in s['topics']:
  for m in MODULES:
   r=slot(s,m['id'],tid);f=r['files'].get('html') if r else None
   rows.append({'step':m['id'],'topic':tid,'title':m['title'],'bundled_version':m['version'],'reading_ready':bool(f and (root/f['snapshot']).is_file()),'state':state(root,s,m['id'],tid),'files':list(r['files']) if r else []})
 summary={tid:{'reading_pages':sum(x['reading_ready'] for x in rows if x['topic']==tid),'expected':12,'all_reading_pages':all(x['reading_ready'] for x in rows if x['topic']==tid)} for tid in s['topics']}
 result={'project':s['name'],'summary':summary,'items':rows,'completion':completion(root,s),'meaning':'阅读齐备不代表内容准确、本人确认、后续交接或客户端验收通过'}
 write_json(root/'assembly-audit.json',result);return result

def completion(root,s):
 """同一项目逐模块审计；不同topic仅作为显式分支，不跨人补位。"""
 from renderer import inline_document
 rows=[]
 for m in MODULES:
  candidates=[]
  for tid in s['topics']:
   r=slot(s,m['id'],tid)
   if not r or any(c['key']==key(m['id'],tid)for c in candidates):continue
   status_=state(root,s,m['id'],tid);page=r['files'].get('html');error='';readable=False
   if page and (root/page['snapshot']).is_file():
    try:
     fallback={n:SKILL/'assets/module11'/n for n in ['style.css','texture.png']}if m['id']==11 else {}
     inline_document(root/page['snapshot'],fallback);readable=True
    except (ValueError,OSError)as e:error=str(e)
   candidates.append({'key':key(m['id'],tid),'topic_id':tid,'revision':r['revision'],'status':status_,'reading_ready':readable,'render_error':error,'handoff_ready':handoff_ready(m['id'],r['files'])})
  ready=[c for c in candidates if c['reading_ready']and c['handoff_ready']and c['status']in ['imported','generated']]
  rows.append({'step':m['id'],'title':m['title'],'ready':bool(ready),'records':candidates,'reason':(''if ready else '缺少可浏览且前置/确认/交接均有效的本项目成果')})
 return {'scope':'same_project_all_twelve_modules_with_explicit_topic_branches','ready':all(x['ready']for x in rows),'ready_count':sum(x['ready']for x in rows),'expected':12,'missing_steps':[x['step']for x in rows if not x['ready']],'items':rows,'native_client_verified':False}

def next_task(root):
 root,s=load(root);report=completion(root,s)
 if report['ready']:return {'complete':True,'next':None,'instruction':'运行deliver取得完整阅读工作台；原生实点仍单独验收'}
 order=[1,8,2,3,4,5,6,7,9,10,11,12]
 missing=set(report['missing_steps'])
 for step in order:
  if step not in missing:continue
  tids=[s['active_topic']]+[t for t in s['topics']if t!=s['active_topic']]
  for tid in tids:
   r=slot(s,step,tid);status_=state(root,s,step,tid)
   if r and status_=='awaiting_selection':return {'complete':False,'step':step,'topic_id':tid,'action':'await_owner_selection','instruction':'展示原模块候选并等本人实际选择；不重新编造或代选'}
   if key(step,tid)in s['pending']:return {'complete':False,'step':step,'topic_id':tid,'action':'resume_pending','pending':s['pending'][key(step,tid)],'instruction':'从原模块持久pending继续；不重问、不替真人答'}
   if all(state(root,s,d,tid)in ['imported','generated']for d in MODULES[step-1]['requires']):
    return {'complete':False,'step':step,'topic_id':tid,'action':'read_existing_then_prepare_or_repair','status':status_,'instruction':'先核已有成果；缺交接先恢复原模块，否则prepare读取原说明与实际输入补跑，不交空按钮当完成'}
 return {'complete':False,'action':'resolve_upstream_conflict','missing_steps':report['missing_steps'],'instruction':'存在变化或来源冲突，核原卡与模块state；不能用别的人物或改状态强行完成'}

def deliver(root,scope='complete'):
 root,s=load(root);report=completion(root,s)
 write_json(root/'delivery-audit.json',report)
 if scope=='complete'and not report['ready']:raise ValueError('完整工作台未就绪，缺项：'+','.join(map(str,report['missing_steps']))+'；运行next补缺，不能把阶段页交成完整页')
 if scope not in ['complete','stage']:raise ValueError('交付范围无效')
 render(root,s)
 receipt={'scope':scope,'complete_reading_and_handoffs':report['ready'],'ready_count':report['ready_count'],'dashboard':str(root/'工作台.html'),'html_sha256':sha(root/'工作台.html'),'mode':s['mode'],'native_client_verified':False,'meaning':'完整指本项目12类实际阅读成果与交接有效，不代表外部事实、真人效果或WorkBuddy原生验收'}
 write_json(root/'delivery-receipt.json',receipt);return receipt

def inventory(root,source):
 root,s=load(root);source=Path(source).expanduser().resolve()
 if not source.is_dir():raise ValueError('请给本人明确指定的资料目录')
 rows=[]
 for p in source.rglob('*'):
  if not p.is_file() or p.suffix.lower() not in ['.json','.html','.md','.png','.docx','.txt']:continue
  if len(rows)>=3000:raise ValueError('目录过大，请缩小到本学员的成果目录')
  rows.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
 return {'project':s['name'],'source':str(source),'files':rows,'instruction':'逐份实际阅读核对归属、类型、题目和版本；只列文件，不自动认领或补写'}

def status(root):
 root,s=load(root);result={'project':s['name'],'student_ref':s['student_ref'],'business':s['business'],'mode':s['mode'],'topics':{},'pending':s['pending']}
 for tid in s['topics']:result['topics'][tid]=[{'step':m['id'],'title':m['title'],'status':state(root,s,m['id'],tid)}for m in MODULES]
 render(root,s);return result

# Renderer is imported only when needed and ships with this package.
def render(root,s):
 from renderer import render_dashboard
 return render_dashboard(SKILL,root,s,MODULES,state)

def main():
 a=argparse.ArgumentParser();sub=a.add_subparsers(dest='cmd',required=True)
 for command in ['init','topic','import','prepare','complete','pending','feedback','status','render','audit','inventory','next','deliver']:
  p=sub.add_parser(command);p.add_argument('--project',required=True)
  if command=='init':
   for k in ['name','business','student']:p.add_argument('--'+k,required=True)
   p.add_argument('--mode',choices=['real','fictional_demo'],required=True);p.add_argument('--purpose',choices=['student_workflow','teaching_demo'],default='student_workflow')
  if command=='topic':p.add_argument('--id',required=True);p.add_argument('--title',required=True)
  if command=='import':p.add_argument('--manifest',required=True)
  if command in ['prepare','complete','pending','feedback']:
   p.add_argument('--step',type=int,choices=range(1,13),required=True);p.add_argument('--topic',default='main')
  if command=='inventory':p.add_argument('--source',required=True)
  if command=='deliver':p.add_argument('--scope',choices=['complete','stage'],default='complete')
  if command=='complete':p.add_argument('--request',required=True)
  if command=='pending':p.add_argument('--question',required=True);p.add_argument('--module-state')
  if command=='feedback':p.add_argument('--message',required=True)
 x=a.parse_args()
 try:
  if x.cmd=='init':r=init(x.project,x.name,x.business,x.student,x.mode,x.purpose)
  elif x.cmd=='topic':r=topic(x.project,x.id,x.title)
  elif x.cmd=='import':r=import_manifest(x.project,x.manifest)
  elif x.cmd=='prepare':r=prepare(x.project,x.step,x.topic)
  elif x.cmd=='complete':r=complete(x.project,x.step,x.topic,x.request)
  elif x.cmd=='pending':r=pending(x.project,x.step,x.topic,x.question,x.module_state)
  elif x.cmd=='inventory':r=inventory(x.project,x.source)
  elif x.cmd=='audit':r=audit(x.project)
  elif x.cmd=='next':r=next_task(x.project)
  elif x.cmd=='deliver':r=deliver(x.project,x.scope)
  elif x.cmd=='feedback':r=feedback(x.project,x.step,x.topic,x.message)
  else:r=status(x.project)
  print(json.dumps(r,ensure_ascii=False,indent=2))
 except (ValueError,AssertionError,OSError)as e:
  print(json.dumps({'error':str(e),'completed':False},ensure_ascii=False));raise SystemExit(2)
if __name__=='__main__':main()
