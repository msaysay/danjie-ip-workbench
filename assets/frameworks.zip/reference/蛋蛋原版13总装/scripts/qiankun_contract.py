"""Use the frozen original module validator and bind its source bytes to this project."""
from pathlib import Path
import hashlib,zipfile,json

def validate_bound(skill,root,state,model):
 archive=Path(skill)/'packages/10.zip'
 expected_archive=json.loads((Path(skill)/'modules.json').read_text())[9]['sha256']
 if hashlib.sha256(archive.read_bytes()).hexdigest()!=expected_archive:raise ValueError('第10项冻结包已变，停止校验')
 with zipfile.ZipFile(archive) as z:
  scope={'__name__':'qiankun_original_validator','__file__':'frozen/scripts/build.py'}
  exec(compile(z.read('danjie-qiankun-links/scripts/build.py'), 'frozen-qiankun070-build.py','exec'),scope)
 scope['validate'](model)
 for step,role in [(1,'audience'),(8,'persona')]:
  parent=state['artifacts'].get(str(step)+':shared')
  if not parent or role not in parent['files']:raise ValueError('第10项缺本项目两卡')
  expected=parent['files'][role]['sha256']
  actual=hashlib.sha256(Path(model['source_files'][role]).read_bytes()).hexdigest()
  if actual!=expected:raise ValueError('第10项'+role+'原件与本项目原卡字节不一致，拒绝串卡')
 selected=model.get('selected_topic')
 if not selected:return 'awaiting_topic'
 target=next(t for t in model['topics'] if t['id']==selected)
 if not target.get('methods'):raise ValueError('选中C尚无七式，不登记为完成；保留现场并继续原模块')
 return 'seven_openings'
