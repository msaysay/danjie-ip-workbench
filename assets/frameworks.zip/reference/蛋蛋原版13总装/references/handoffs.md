# 十二项衔接合同

| 项 | 读取的本项目已有成果 | 必须登记的角色 |
|---|---|---|
| 01 客群 | 本次真实答复或本人指定已有卡 | audience：实际客群JSON |
| 02 三圈 | 01 audience | three_circle：三圈模型交付；topic_handoff：03-选题研究交接.json |
| 03 当头一棒 | 01 audience、02 topic_handoff | counter_candidates：10题×3种候选model；另登selected_hook：本人实际采用后由select导出的选择JSON |
| 04 以理服人 | 01 audience、03 selected_hook | proof：完整本次结构化建议/支撑资料，不是只读HTML |
| 05 亮出绝活 | 01 audience、02三圈、03 selected_hook、04 proof | ability：本次绝活后台JSON，另交本人可用HTML/TXT |
| 06 指条明路 | 01 audience、03 selected_hook、04 proof、05 ability | endings：实际本次结构化收尾卡 |
| 07 开场八式 | 01 audience及真实确认 | openings：本次八式结构化结果；不强借03代替本模块确认 |
| 08 人设 | 01 audience及本人采访 | persona：新版六维JSON，保存原答及原模块状态 |
| 09 简介 | 08 persona；有同本人05能力卡则可选读取 | bio：本次四行结果JSON/MD；缺项照模块追问 |
| 10 乾坤 | 01 audience、08 persona；先生成话题池，后由本人选C | expansion：0.7.0 model.json；HTML；来源回执（receipt） |
| 11 六脉 | 01 audience、08 persona | interview：本次interview.json；六PNG/ZIP/HTML各自正常交付 |
| 12 一题多讲 | 08 persona及明确中心问题 | wheel：本次结构化转盘结果；不必强制读02 |

为每项另登记html角色，网页工作台才能一键打开原阅读页。其他TXT、PNG、ZIP按真实文件路径补登记。登记工具仅证明文件/SHA存在；这些角色的内容与数据格式，必须由调用者按原模块及本项目资料实际核对。原模块拒收某格式时按其正常转录/适配流程处理，保留原件绑定，不修改其读取器放行。

既有资料导入不是重新生成或新客户端测试；note标明“导入已有成果”及来源版本。只要前置真实有效，可在新项目登记既有01或08，然后补齐依赖；没有01时不得凭人设推造客群。资料归属、同题选中态、授权、原话均不能由用户上传动作本身推定。

原模块采访可能已有独立state、原答、pending等文件，它们是采访的权威。工作台只记本项进度，不代替原模块状态，不将其机器回执当成新采访state。
