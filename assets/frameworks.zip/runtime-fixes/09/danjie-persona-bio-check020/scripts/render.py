#!/usr/bin/env python3
"""Offline, standard-library-only account bio exporter with source anchoring."""
import argparse
import hashlib
import html
import json
import re
from pathlib import Path

KINDS = ('position', 'trust', 'value', 'service')
LABELS = ('专业定位', '信任依据', '关注价值', '服务指引')
UNKNOWN = ('待补充', '待确认', '待核验', '暂不公开', '拒绝回答', '未知', '不知道')

def input_mode(persona):
    mode = persona.get('mode')
    demos = ('fictional_demo', 'fictional', '虚构演示', 'demo')
    if mode not in ('real',) + demos:
        raise ValueError('人设卡mode缺失或未识别，请依据原卡核对，不推定真人')
    if mode == 'real' and persona.get('status') == 'fictional_demo':
        raise ValueError('人设卡mode与虚构状态冲突，请核对原卡')
    return 'fictional_demo' if mode in demos else 'real'

def pointer_get(doc, pointer):
    if not isinstance(pointer, str) or not pointer.startswith('/'):
        raise ValueError('来源位置必须为有效JSON Pointer')
    obj = doc
    for key in pointer[1:].split('/'):
        key = key.replace('~1', '/').replace('~0', '~')
        obj = obj[int(key)] if isinstance(obj, list) else obj[key]
    return obj

VALUE_FIELDS = ('content_pillars', 'content', '持续内容')
VALUE_GAP = '你会持续分享什么，能帮目标客户解决什么问题？'


def original_md(persona):
    if 'source_md' not in persona:
        return None
    origin = persona['source_md']
    raw = Path(origin['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest() != origin['sha256']:
        raise ValueError('原始人设MD已变化，请重新核对来源')
    return {'path': origin['path'], 'sha256': origin['sha256'],
            'fulltext': raw.decode('utf-8')}


def value_sources(persona):
    """Supported typed fields only; this is not a natural-language classifier."""
    sources = {}
    for key in VALUE_FIELDS:
        value = persona.get(key)
        if isinstance(value, str) and value.strip():
            sources['/' + key] = value
        elif isinstance(value, list) and all(isinstance(item, str) for item in value):
            sources.update(('/' + key + '/' + str(i), item)
                           for i, item in enumerate(value) if item.strip())
    origin = original_md(persona)
    if origin is None:
        return sources
    # A normalized MD adapter cannot create a typed fact just by renaming P1/P6.
    sections = {}
    current = None
    for line in origin['fulltext'].splitlines():
        heading = re.fullmatch(r'#{1,6} +(.+?) *', line)
        if heading:
            current = heading.group(1) if heading.group(1) in VALUE_FIELDS else None
            if current is not None:
                sections.setdefault(current, [])
        elif current is not None and line.strip():
            sections[current].append(line.strip())
    allowed = {}
    for pointer, value in sources.items():
        key = pointer.split('/')[1]
        lines = sections.get(key, [])
        # Scalar equals the complete section; list elements equal original bullet lines.
        if pointer.count('/') == 1:
            exact = value == '\n'.join(lines)
        else:
            exact = value in [re.sub(r'^[-*] +', '', line) for line in lines]
        if exact:
            allowed[pointer] = value
    return allowed


def build(persona, draft):
    rows = draft.get('lines', [])
    if [r.get('kind') for r in rows] != list(KINDS):
        raise ValueError('简介必须按约定顺序包含四行')
    result, audit = [], []
    typed_value = value_sources(persona)
    for row, label in zip(rows, LABELS):
        parts = row.get('parts', [])
        if row['kind'] == 'value' and parts and any(part.get('pointer') not in typed_value for part in parts):
            # Preserve the attempted draft, but never publish another fact type as content value.
            result.append({'label': label, 'text': VALUE_GAP, 'missing': True})
            audit.append({'kind': 'value', 'gap': VALUE_GAP,
                          'reason': '原卡没有与本行引用对应的明确持续内容来源',
                          'attempted_row': row})
            continue
        if not parts:
            gap = row.get('gap', '').strip()
            if not gap or '\n' in gap:
                raise ValueError(label + '缺项时须给具体补充问题或缺口')
            result.append({'label': label, 'text': gap, 'missing': True})
            audit.append({'kind': row['kind'], 'gap': gap, 'reason': row.get('reason', '')})
            continue
        if row.get('gap'):
            raise ValueError(label + '不得同时声明完整与缺项')
        if row['kind'] == 'service' and (row.get('service_confirmed') is not True or row.get('entry_confirmed') is not True):
            raise ValueError('服务指引须已核对真实服务与公开入口')
        texts = []
        for part in parts:
            value = part.get('text', '').strip()
            if not value or '\n' in value or '\r' in value or any(x in value for x in UNKNOWN):
                raise ValueError(label + '包含空白、多行或未确认内容')
            if part.get('confirmed') is not True or part.get('public') is not True:
                raise ValueError(label + '包含未确认或未允许公开内容')
            source = pointer_get(persona, part.get('pointer'))
            if not isinstance(source, str) or value not in source:
                raise ValueError(label + '内容与原卡来源不匹配')
            if row['kind'] == 'trust' and any(note in value for note in ('以上为新增虚构', '以上均为新增虚构', '以上为虚构资历条件', '没有真实证明附件', '没有真实案例附件', '没有真实记录附件')):
                raise ValueError('信任行需提炼业务依据，资料性质说明留后台；虚构标识由导出器保留')
            texts.append(value)
        # Remove an exact repeated business prefix only when the first line
        # already says it and the remaining sourced phrase includes a next step.
        # This does not shorten or rewrite the entry itself.
        if (row['kind'] == 'service' and len(texts) > 1
                and parts[0].get('pointer') == '/business'
                and texts[0] in result[0]['text']
                and re.search(r'咨询|预约|报名|购买|合作', ''.join(texts[1:]))):
            texts = texts[1:]
        if row['kind'] == 'position' and len(texts) > 1:
            texts = [text for text, part in zip(texts, parts)
                     if not (part.get('pointer') == '/display_name' and text == persona.get('display_name'))]
        joiner = row.get('joiner', '｜')
        if joiner not in ('', '，', '｜', '；'):
            raise ValueError('连接符只能为约定标点，不能夹带新事实')
        result.append({'label': label, 'text': joiner.join(texts), 'missing': False})
        audit.append(row)
    return result, audit

def student_content(persona, draft):
    rows, audit = build(persona, draft)
    mode = input_mode(persona)
    demo = mode == 'fictional_demo'
    complete = all(not r['missing'] for r in rows)
    copy_text = '\n'.join(r['text'] for r in rows)
    md = '\n'.join((r['text'] if not r['missing'] else '[' + r['text'] + ']') + '  ' for r in rows) + '\n'
    if demo:
        md = '虚构演示\n\n' + md
        copy_text = '虚构演示\n' + copy_text
    blocks = ''.join('<section><small>' + html.escape(r['label']) + '</small><p' + (' class="gap"' if r['missing'] else '') + '>' + html.escape(r['text']) + '</p></section>' for r in rows)
    # textarea holds escaped plain text, never executable input. No remote dependencies.
    page = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'"><title>账号简介</title><style>body{margin:0;background:#151515;color:#fff;font:18px/1.7 system-ui,sans-serif}main{max-width:700px;padding:32px 22px;margin:auto}h1{color:#ffd54a;font-size:30px}section{padding:14px 18px;background:#252525;border-radius:12px;margin:12px 0}small{color:#ffd54a;font-size:14px}p{margin:5px 0;overflow-wrap:anywhere;white-space:pre-wrap}.gap{color:#b9e9c6}button{padding:12px 24px;border:0;border-radius:8px;background:#ffd54a;font-size:17px}button:disabled{background:#777;color:#eee}textarea{position:fixed;left:-9999px}#status{font-size:14px;color:#b9e9c6}</style><main><h1>你的账号简介</h1>''' + ('<p class="gap">虚构演示</p>' if demo else '') + blocks + '<button id="copy"' + ('' if complete else ' disabled') + '>' + ('复制或选中简介' if complete else '补齐后可复制完整简介') + '</button><p id="status" role="status"></p><textarea id="bio" hidden readonly aria-label="完整简介文字">' + html.escape(copy_text) + '''</textarea></main><script>document.getElementById('copy').addEventListener('click',async()=>{const b=document.getElementById('bio'),s=document.getElementById('status');try{if(!navigator.clipboard||!window.isSecureContext)throw Error('unsupported');await navigator.clipboard.writeText(b.value);s.textContent='已复制'}catch(e){b.hidden=false;b.focus();b.select();b.setSelectionRange(0,b.value.length);s.textContent='未自动复制；已选中完整简介，请按 ⌘C（Mac）或 Ctrl+C（Windows）'}});</script></html>'''
    css = (Path(__file__).resolve().parents[1] / 'assets/style.css').read_text(encoding='utf-8')
    page = re.sub(r'<style>.*?</style>', lambda _: '<style>' + css + '</style>', page, count=1, flags=re.S)
    page = page.replace('<main><h1>你的账号简介</h1>', '<main><header><span>蛋解课堂</span><span>账号装修 · 四行简介</span></header><h1>你的四行账号简介</h1><p class="intro">我是谁 · 凭什么信我 · 为什么关注我 · 怎么开始</p>')
    page = page.replace('<title>账号简介</title>', '<title>' + html.escape(str(persona.get('display_name', '我的'))) + '的账号简介</title>')
    page = page.replace('<h1>你的四行账号简介</h1>', '<h1>' + html.escape(str(persona.get('display_name', '我的'))) + '的四行简介</h1>')
    page = page.replace('</textarea></main>', '</textarea><footer>蛋解创业</footer></main>')
    return md, page, {'mode': mode, 'complete': complete, 'audit': audit}

def public_names(persona, draft):
    md, _, _ = student_content(persona, draft)
    name = re.sub(r'[^\w\u4e00-\u9fff-]', '', str(persona.get('display_name', '我的')))[:24] or '我的'
    stem = name + '-账号简介-' + hashlib.sha256(md.encode('utf-8')).hexdigest()[:8]
    return (stem + '.html', stem + '.md')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def student_reply(md, out, names):
    # A single deterministic student-facing exit: result and two actual file links.
    return md.rstrip() + '\n\n[打开账号简介](<' + str(out / names[0]) + '>)\n\n[复制文字版](<' + str(out / names[1]) + '>)\n'


def public_entries(out, names):
    return [{'path': str(out / name), 'sha256': digest((out / name).read_bytes()),
             'bytes': (out / name).stat().st_size} for name in names]


def verify_delivery(out):
    out = Path(out).resolve()
    internal = out / '_internal'
    if internal.is_symlink():
        raise ValueError('内部目录不能是替代链接')
    record = json.loads((internal / '后台来源核对.json').read_text(encoding='utf-8'))
    source_bytes = Path(record['source_path']).read_bytes()
    draft_bytes = (internal / '后台简介.json').read_bytes()
    if digest(source_bytes) != record['source_sha256'] or digest(draft_bytes) != record['draft_sha256']:
        raise ValueError('输入资料已变化，请重新核对后另存简介')
    persona, draft = json.loads(source_bytes), json.loads(draft_bytes)
    names = public_names(persona, draft)
    if {p.name for p in out.iterdir()} != set(names) | {'_internal'} or any((out / n).is_symlink() for n in names):
        raise ValueError('交付文件与本轮人设内容不匹配')
    md, page, meta = student_content(persona, draft)
    if record.get('original_md') != original_md(persona):
        raise ValueError('后台原MD记录与当前原始资料不一致')
    if record['source'] != persona or record['lines'] != meta['audit']:
        raise ValueError('后台记录与本次输入不一致')
    for name, expected in ((names[0], page), (names[1], md)):
        if (out / name).read_bytes() != expected.encode('utf-8'):
            raise ValueError('实际简介与当前人设生成结果不一致，不能交付')
    entries = public_entries(out, names)
    if json.loads((internal / 'student-files.json').read_text(encoding='utf-8')) != entries:
        raise ValueError('公开文件清单不匹配；只允许简介HTML与文字版')
    reply = student_reply(md, out, names)
    if (internal / 'student_reply.md').read_bytes() != reply.encode('utf-8'):
        raise ValueError('交付正文不是本次四行简介与两个真实入口')
    return reply


def export(persona_path, draft_path, out):
    if Path(out).is_symlink():
        raise ValueError('请使用独立新输出目录')
    persona_path, draft_path, out = Path(persona_path).resolve(), Path(draft_path).resolve(), Path(out).resolve()
    persona_bytes, draft_bytes = persona_path.read_bytes(), draft_path.read_bytes()
    persona, draft = json.loads(persona_bytes), json.loads(draft_bytes)
    names = public_names(persona, draft)
    md, page, meta = student_content(persona, draft)
    if out.exists() and (out.is_symlink() or any(p.name != '_internal' for p in out.iterdir())):
        raise ValueError('输出已有文件，请换独立新目录；核对资料只放内部资料区')
    internal = out / '_internal'
    if internal.is_symlink():
        raise ValueError('内部资料区不能是替代链接')
    if internal.exists() and any(p.name != '后台简介.json' or p.is_symlink() for p in internal.iterdir()):
        raise ValueError('输出已有核对记录，请换独立新目录')
    internal.mkdir(parents=True, exist_ok=True)
    for name, value in ((names[0], page), (names[1], md)):
        (out / name).write_bytes(value.encode('utf-8'))
    (internal / '后台简介.json').write_bytes(draft_bytes)
    record = {'version':'0.2.1', 'normalized_mode':meta['mode'], 'complete':meta['complete'],
              'source_sha256':digest(persona_bytes), 'draft_sha256':digest(draft_bytes),
              'source_path':str(persona_path), 'source':persona, 'original_md':original_md(persona), 'lines':meta['audit'],
              'limitation':'仅引用与结构核对，不自动保证语义、事实或公开授权；原生采纳与过程旁白未验证'}
    (internal / '后台来源核对.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    (internal / 'student-files.json').write_text(json.dumps(public_entries(out, names), ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    reply = student_reply(md, out, names)
    (internal / 'student_reply.md').write_bytes(reply.encode('utf-8'))
    verify_delivery(out)
    (internal / 'delivery-validation.json').write_text(json.dumps({'version':'0.2.1','source_sha256':digest(persona_bytes),
        'draft_sha256':digest(draft_bytes),'public_files':public_entries(out, names),'reply_sha256':digest(reply.encode('utf-8')),
        'scope':'本地确定性出口绑定，非原生采纳或旁白验收'}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return reply


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--persona', type=Path)
    ap.add_argument('--draft', type=Path)
    ap.add_argument('--out', type=Path)
    ap.add_argument('--verify-delivery', type=Path)
    args = ap.parse_args()
    try:
        if args.verify_delivery is not None:
            if any(x is not None for x in (args.persona, args.draft, args.out)):
                ap.error('核对已有交付时不同时传生成参数')
            reply = verify_delivery(args.verify_delivery)
        else:
            if any(x is None for x in (args.persona, args.draft, args.out)):
                ap.error('需要人设、后台简介与独立输出目录')
            reply = export(args.persona, args.draft, args.out)
        print(reply, end='')
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        import sys
        print('未完成：' + str(error), file=sys.stderr)
        raise SystemExit(2)


if __name__ == '__main__':
    main()
